document.addEventListener('DOMContentLoaded', function () {
    const links = document.querySelectorAll('.nav-links a');
    links.forEach((link) => {
        link.addEventListener('click', function (event) {
            const href = link.getAttribute('href');
            if (!href || href === '#') {
                event.preventDefault();
            }
        });
    });
});
