from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from .forms import LoginForm, RegistrationForm


def register(request):
	if request.user.is_authenticated:
		return redirect('dashboard')
	form = RegistrationForm(request.POST or None)
	if request.method == 'POST' and form.is_valid():
		user = form.save()
		login(request, user)
		messages.success(request, 'Your DREAM HOME account is ready.')
		return redirect('dashboard')
	return render(request, 'accounts/register.html', {'form': form})


def login_view(request):
	if request.user.is_authenticated:
		return redirect('dashboard')
	form = LoginForm(request, data=request.POST or None)
	if request.method == 'POST' and form.is_valid():
		user = authenticate(
			request,
			username=form.cleaned_data['username'],
			password=form.cleaned_data['password'],
		)
		if user is not None:
			login(request, user)
			return redirect('dashboard')
	return render(request, 'accounts/login.html', {'form': form})


@login_required
def logout_view(request):
	if request.method == 'POST':
		logout(request)
		messages.success(request, 'You have been logged out securely.')
		return redirect('home')
	return redirect('dashboard')


@login_required
def profile(request):
	return render(request, 'accounts/profile.html')


@login_required
def dashboard(request):
	design_count = 0
	try:
		from designs.persistence import DesignPersistenceService
		design_count = len(DesignPersistenceService().list_designs(str(request.user.pk)))
	except Exception:
		messages.warning(request, 'Saved designs are temporarily unavailable.')
	return render(request, 'dashboard/dashboard.html', {'design_count': design_count})

# Create your views here.
