"""Validation and normalization for AI-produced house requirements."""

from __future__ import annotations

from typing import Any, Mapping, TypedDict


SUPPORTED_STYLES = {'modern', 'traditional', 'minimalist', 'contemporary', 'other'}
ROOM_FIELDS = ('bedrooms', 'bathrooms', 'kitchen', 'living_room', 'dining_room')
FEATURE_FIELDS = (
    'balcony',
    'utility_room',
    'work_study_room',
    'prayer_room',
    'storage_room',
    'garden_open_space',
)


class HouseRequirements(TypedDict):
    plot: dict[str, float | str]
    rooms: dict[str, int]
    parking: int
    floors: int
    features: dict[str, bool]
    style: str
    style_other: str
    budget: float | None
    additional_requirements: str


class SchemaError(ValueError):
    """Raised when structured requirements are missing or invalid."""


def _mapping(value: Any, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise SchemaError(f'{field} must be an object')
    return value


def _number(value: Any, field: str, minimum: float = 0) -> float:
    if isinstance(value, bool) or value is None:
        raise SchemaError(f'{field} must be numeric')
    try:
        number = float(value)
    except (TypeError, ValueError) as error:
        raise SchemaError(f'{field} must be numeric') from error
    if number < minimum:
        raise SchemaError(f'{field} must be at least {minimum:g}')
    return number


def _count(value: Any, field: str, minimum: int = 0) -> int:
    number = _number(value, field, minimum)
    if number != int(number):
        raise SchemaError(f'{field} must be a whole number')
    return int(number)


def _boolean(value: Any, field: str) -> bool:
    if not isinstance(value, bool):
        raise SchemaError(f'{field} must be boolean')
    return value


def _required(mapping: Mapping[str, Any], field: str) -> Any:
    if field not in mapping or mapping[field] in (None, ''):
        raise SchemaError(f'{field} is required')
    return mapping[field]


def normalize_requirements(raw: Mapping[str, Any]) -> HouseRequirements:
    """Normalize flat or engine-shaped data into the form consumed by the engine."""
    if not isinstance(raw, Mapping):
        raise SchemaError('requirements must be a JSON object')

    plot_source = raw.get('plot', raw)
    rooms_source = raw.get('rooms', raw)
    features_source = raw.get('features', raw)
    plot = _mapping(plot_source, 'plot')
    rooms = _mapping(rooms_source, 'rooms')
    features = _mapping(features_source, 'features')

    width = _number(_required(plot, 'width') if 'plot' in raw else _required(raw, 'plot_width'), 'plot.width', 0.01)
    length = _number(_required(plot, 'length') if 'plot' in raw else _required(raw, 'plot_length'), 'plot.length', 0.01)
    unit = str(plot.get('unit', raw.get('unit', 'ft'))).strip().lower()
    if unit != 'ft':
        raise SchemaError('only feet (ft) are currently supported')

    normalized_rooms: dict[str, int] = {}
    for field in ROOM_FIELDS:
        if field in rooms:
            normalized_rooms[field] = _count(rooms[field], f'rooms.{field}')
        elif field in ('bedrooms', 'bathrooms'):
            raise SchemaError(f'{field} is required')
        else:
            normalized_rooms[field] = 1

    normalized_features = {
        field: _boolean(features[field], f'features.{field}') if field in features else False
        for field in FEATURE_FIELDS
    }
    parking = _count(raw.get('parking', 0), 'parking')
    floors = _count(raw.get('floors', 1), 'floors', 1)
    style = str(raw.get('style', 'modern')).strip().lower()
    if style not in SUPPORTED_STYLES:
        raise SchemaError(f'unsupported style: {style or "(empty)"}')
    style_other = str(raw.get('style_other', '') or '').strip()
    if style == 'other' and not style_other:
        raise SchemaError('style_other is required when style is other')
    budget_value = raw.get('budget')
    budget = None if budget_value in (None, '') else _number(budget_value, 'budget')

    return {
        'plot': {'width': width, 'length': length, 'unit': unit},
        'rooms': normalized_rooms,
        'parking': parking,
        'floors': floors,
        'features': normalized_features,
        'style': style,
        'style_other': style_other,
        'budget': budget,
        'additional_requirements': str(raw.get('additional_requirements', '') or '').strip(),
    }