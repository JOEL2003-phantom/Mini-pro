from django.contrib import admin
from django.urls import include, path

from accounts.views import dashboard
from designs.views import home

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')),
    path('dashboard/', dashboard, name='dashboard'),
    path('', home, name='home'),
    path('', include(('designs.urls', 'designs'), namespace='designs')),
]
