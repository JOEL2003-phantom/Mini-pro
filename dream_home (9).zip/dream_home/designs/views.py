from uuid import uuid4
import logging
import json

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render
from django.http import HttpResponse, JsonResponse

from .forms import HouseRequirementsForm, PlotDimensionsForm, preferences_to_initial
from .persistence import DesignPersistenceService
from design_engine.services import generate_design
from design_engine.editing import evaluate_layout, normalize_layout_for_editor
from design_engine.export import layout_to_svg
from ai_engine.service import apply_feasibility_decision, parse_house_requirements
from ai_engine.parser import (
    OllamaConnectionError,
    OllamaAPIError,
    InvalidRequirementsError,
    OllamaModelNotFoundError,
    OllamaResponseError,
    OllamaTimeoutError,
    ParserError,
)


logger = logging.getLogger(__name__)


def home(request):
    return render(request, 'home.html')


@login_required
def library(request):
    designs = []
    try:
        designs = DesignPersistenceService().list_designs(str(request.user.pk))
    except Exception:
        messages.warning(request, 'Saved designs are temporarily unavailable.')
    return render(request, 'designs/library.html', {'designs': designs})


@login_required
def new_design(request):
    form = HouseRequirementsForm(request.POST or None)
    natural_language = request.POST.get('natural_language', '') if request.method == 'POST' else ''
    interpreted_requirements = None
    interpretation_error = None

    if request.method == 'POST' and request.POST.get('action') == 'interpret':
        try:
            interpreted_requirements = parse_house_requirements(natural_language)
            form = HouseRequirementsForm(initial=preferences_to_initial(interpreted_requirements))
        except ParserError as error:
            logger.exception('Dream Home AI request failed while interpreting requirements')
            if isinstance(error, OllamaConnectionError):
                interpretation_error = 'Cannot connect to the local AI service.'
            elif isinstance(error, OllamaTimeoutError):
                interpretation_error = 'The local AI model is taking too long to respond. Please try again.'
            elif isinstance(error, OllamaModelNotFoundError):
                interpretation_error = 'The configured local AI model was not found.'
            elif isinstance(error, OllamaResponseError):
                interpretation_error = 'The AI returned an invalid requirement format.'
            elif isinstance(error, InvalidRequirementsError):
                interpretation_error = 'The AI returned invalid structured requirements.'
            elif isinstance(error, OllamaAPIError):
                interpretation_error = 'The local AI service returned an error. Please try again.'
            else:
                interpretation_error = str(error) or 'AI processing failed while interpreting the brief.'
        except Exception:
            logger.exception('Unexpected exception while interpreting requirements')
            interpretation_error = 'AI processing failed. Check the server log for details.'
        return render(request, 'designs/new.html', {
            'form': form,
            'natural_language': natural_language,
            'interpreted_requirements': interpreted_requirements,
            'interpretation_error': interpretation_error,
        })

    if request.method == 'POST' and form.is_valid():
        preferences = form.to_preferences()
        design_name = form.cleaned_data['design_name'].strip()
        if not design_name:
            design_name = f"{preferences['rooms']['bedrooms']} Bedroom Dream Home"
        design = {
            'user_id': str(request.user.pk),
            'design_id': uuid4().hex,
            'design_name': design_name,
            'plot': preferences['plot'],
            'preferences': preferences,
            'layout': None,
            'score': None,
        }
        try:
            DesignPersistenceService().create_design(design)
        except Exception:
            logger.exception(
                'Failed to save design requirements for authenticated user %s',
                request.user.pk,
            )
            form.add_error(None, 'Your requirements could not be saved. Please try again.')
        else:
            messages.success(request, 'Your house requirements have been saved.')
            return redirect('designs:review', design_id=design['design_id'])
    return render(request, 'designs/new.html', {
        'form': form,
        'natural_language': natural_language,
        'interpreted_requirements': interpreted_requirements,
        'interpretation_error': interpretation_error,
    })


@login_required
def review_design(request, design_id):
    try:
        design = DesignPersistenceService().get_design(str(request.user.pk), design_id)
    except Exception:
        messages.error(request, 'The saved requirements could not be loaded right now.')
        return redirect('dashboard')
    if design is None:
        messages.error(request, 'That design could not be found in your workspace.')
        return redirect('dashboard')
    result = _generation_result(design)
    if result.get('success') and not design.get('generated_plans') and not design.get('current_layout') and not design.get('layout'):
        generated_plans = result.get('plans', [])
        try:
            DesignPersistenceService().update_design(
                str(request.user.pk), design_id, {'generated_plans': generated_plans}
            )
        except Exception:
            logger.exception('Failed to persist generated plans for design %s', design_id)
    return _render_review(request, design, result)


def _generation_result(design):
    current_layout = design.get('current_layout') or design.get('layout')
    if current_layout:
        layout = current_layout
        return {
            'success': True,
            'feasibility': {'status': 'feasible', 'requires_user_decision': False, 'issues': [], 'suggestions': []},
            'recommended_layout': layout,
            'alternatives': [],
            'candidates': [layout],
            'plans': [layout],
            'generation_summary': {},
        }
    if design.get('generated_plans'):
        plans = design['generated_plans']
        return {
            'success': True,
            'feasibility': {'status': 'feasible', 'requires_user_decision': False, 'issues': [], 'suggestions': []},
            'recommended_layout': plans[0],
            'alternatives': plans[1:],
            'candidates': plans,
            'plans': plans,
            'generation_summary': {'candidate_count': len(plans), 'selected_plan_count': len(plans)},
        }
    if design.get('preferences'):
        return generate_design(design['preferences'])
    return {'success': False, 'errors': ['No requirements are available yet.'], 'plans': []}


def _render_review(request, design, result, **context):
    preferences = design.get('preferences', {})
    context.setdefault('design', design)
    context.setdefault('result', result)
    context.setdefault('requirements_form', HouseRequirementsForm(
        initial=preferences_to_initial(preferences, design.get('design_name', ''))
    ))
    context.setdefault('plot_form', PlotDimensionsForm(initial=preferences_to_initial(preferences)))
    return render(request, 'designs/review.html', context)


@login_required
def decide_design(request, design_id):
    if request.method != 'POST':
        return redirect('designs:review', design_id=design_id)
    design = _owned_design(design_id, request.user.pk)
    if design is None:
        messages.error(request, 'That design could not be found in your workspace.')
        return redirect('dashboard')

    decision = request.POST.get('decision', '')
    updated_requirements = None
    if decision == 'adjust_requirements':
        form = HouseRequirementsForm(request.POST)
        if not form.is_valid():
            return _render_review(request, design, _generation_result(design), requirements_form=form)
        updated_requirements = form.to_preferences()
    elif decision == 'change_plot':
        form = PlotDimensionsForm(request.POST)
        if not form.is_valid():
            return _render_review(request, design, _generation_result(design), plot_form=form)
        updated_requirements = form.to_plot(design['preferences'])

    result = apply_feasibility_decision(
        design['preferences'],
        decision,
        updated_requirements=updated_requirements,
    )
    next_requirements = result.get('requirements', updated_requirements or design['preferences'])
    updates = {
        'preferences': next_requirements,
        'plot': next_requirements['plot'],
        'layout': None,
        'score': None,
    }
    try:
        updated = DesignPersistenceService().update_design(
            str(request.user.pk), design_id, updates
        )
    except Exception:
        logger.exception('Failed to update requirements for design %s', design_id)
        messages.error(request, 'Your updated requirements could not be saved right now.')
        return _render_review(request, design, result)
    design = updated or {**design, **updates}
    if result.get('success'):
        return redirect('designs:visualize', design_id=design_id)
    return _render_review(request, design, result)


@login_required
def visualize_design(request, design_id):
    try:
        design = DesignPersistenceService().get_design(str(request.user.pk), design_id)
    except Exception:
        messages.error(request, 'The design could not be loaded right now.')
        return redirect('dashboard')
    if design is None:
        messages.error(request, 'That design could not be found in your workspace.')
        return redirect('dashboard')

    result = _generation_result(design)
    if not result.get('success'):
        return render(request, 'designs/visualize.html', {'design': design, 'result': result})
    recommended = normalize_layout_for_editor(result.get('recommended_layout'))
    result['recommended_layout'] = recommended
    for index, plan in enumerate(result.get('alternatives', [])):
        result['alternatives'][index] = normalize_layout_for_editor(plan)
    return render(
        request,
        'designs/visualize.html',
        {'design': design, 'result': result},
    )


@login_required
def select_plan(request, design_id):
    if request.method != 'POST':
        return redirect('designs:visualize', design_id=design_id)
    design = _owned_design(design_id, request.user.pk)
    if design is None:
        return HttpResponse('Design not found.', status=404)
    plans = design.get('generated_plans') or []
    if not plans and design.get('preferences'):
        # Legacy records predate generated_plans; establish history once before selection.
        plans = generate_design(design['preferences']).get('plans', [])
    plan_id = request.POST.get('plan_id', '').strip()
    plan_index = None
    if not plan_id:
        try:
            plan_index = int(request.POST.get('plan_index', '0'))
            plan_id = plans[plan_index].get('candidate_id', '')
        except (TypeError, ValueError, IndexError):
            plan_id = ''
    layout = next((plan for plan in plans if plan_id and plan.get('candidate_id') == plan_id), None)
    if layout is None and plan_index is not None:
        layout = plans[plan_index] if 0 <= plan_index < len(plans) else None
    if layout is None:
        return HttpResponse('That floor plan is not available.', status=400)
    layout = normalize_layout_for_editor(layout)
    updated = DesignPersistenceService().update_design(
        str(request.user.pk), design_id,
        {
            'generated_plans': plans,
            'selected_plan_id': plan_id,
            'current_layout': layout,
            'layout': layout,
            'score': layout.get('score'),
        },
    )
    if updated is None:
        return HttpResponse('Design not found.', status=404)
    return redirect('designs:visualize', design_id=design_id)


@login_required
def export_design_svg(request, design_id):
    try:
        design = _owned_design(design_id, request.user.pk)
        if design is None:
            return HttpResponse('Design not found.', status=404)
        layout = design.get('current_layout') or design.get('layout')
        if not layout and design.get('preferences'):
            result = generate_design(design['preferences'])
            if not result.get('success'):
                return HttpResponse('No valid layout is available for export.', status=400)
            layout = result['recommended_layout']
        if not layout:
            return HttpResponse('No generated layout is available for export.', status=400)
        layout = normalize_layout_for_editor(layout)
        response = HttpResponse(layout_to_svg(layout, design['design_name']), content_type='image/svg+xml')
        response['Content-Disposition'] = f'attachment; filename="{design["design_id"]}.svg"'
        return response
    except Exception:
        logger.exception('Failed to export design %s for user %s', design_id, request.user.pk)
        return HttpResponse('The design could not be exported right now.', status=503)


@login_required
def delete_design(request, design_id):
    if request.method != 'POST':
        return redirect('designs:library')
    if DesignPersistenceService().delete_design(str(request.user.pk), design_id):
        messages.success(request, 'Design deleted successfully.')
    else:
        messages.error(request, 'That design could not be found in your workspace.')
    return redirect('designs:library')


def _owned_design(design_id, user_id):
    return DesignPersistenceService().get_design(str(user_id), design_id)


@login_required
def validate_edited_layout(request, design_id):
    if request.method != 'POST':
        return json_response({'success': False, 'errors': ['POST is required.']}, status=405)
    try:
        design = _owned_design(design_id, request.user.pk)
        payload = json.loads(request.body or '{}')
        evaluation = evaluate_layout(design['preferences'], payload['layout']) if design else None
    except (KeyError, TypeError, ValueError, json.JSONDecodeError):
        return json_response({'success': False, 'errors': ['The edited layout payload is invalid.']}, status=400)
    except Exception:
        logger.exception('Failed to validate edited design %s for user %s', design_id, request.user.pk)
        return json_response({'success': False, 'errors': ['The layout could not be validated right now.']}, status=503)
    if design is None:
        return json_response({'success': False, 'errors': ['Design not found.']}, status=404)
    return json_response({'success': True, **evaluation})


@login_required
def save_edited_layout(request, design_id):
    if request.method != 'POST':
        return json_response({'success': False, 'errors': ['POST is required.']}, status=405)
    try:
        design = _owned_design(design_id, request.user.pk)
        payload = json.loads(request.body or '{}')
        layout = normalize_layout_for_editor(payload['layout'])
        evaluation = evaluate_layout(design['preferences'], layout) if design else None
    except (KeyError, TypeError, ValueError, json.JSONDecodeError):
        return json_response({'success': False, 'errors': ['The edited layout payload is invalid.']}, status=400)
    except Exception:
        logger.exception('Failed to save edited design %s for user %s', design_id, request.user.pk)
        return json_response({'success': False, 'errors': ['The design could not be saved right now.']}, status=503)
    if design is None:
        return json_response({'success': False, 'errors': ['Design not found.']}, status=404)
    if evaluation is None:
        return json_response({'success': False, 'errors': ['The layout could not be evaluated right now.']}, status=400)
    errors = evaluation.get('errors', []) or []
    warnings = evaluation.get('warnings', []) or []
    if errors and not warnings:
        return json_response({'success': False, 'errors': errors, 'warnings': warnings, 'saved_with_warnings': False, **evaluation}, status=400)
    try:
        updates = {'layout': layout, 'current_layout': layout, 'score': evaluation.get('score'), 'validation': {'valid': evaluation.get('valid', False), 'errors': errors, 'warnings': warnings}}
        updated = DesignPersistenceService().update_design(
            str(request.user.pk), design_id,
            updates,
        )
    except Exception:
        logger.exception('Failed to persist edited design %s for user %s', design_id, request.user.pk)
        return json_response({'success': False, 'errors': ['The design could not be saved right now.']}, status=503)
    persisted_layout = layout
    if isinstance(updated, dict):
        persisted_layout = updated.get('layout') if updated.get('layout') is not None else updated.get('current_layout') if updated.get('current_layout') is not None else layout
    response = {
        'success': updated is not None,
        'layout': persisted_layout,
        'saved_with_warnings': bool(warnings),
        **evaluation,
    }
    return json_response(response)


@login_required
def regenerate_design(request, design_id):
    if request.method != 'POST':
        return json_response({'success': False, 'errors': ['POST is required.']}, status=405)
    design = _owned_design(design_id, request.user.pk)
    if design is None:
        return json_response({'success': False, 'errors': ['Design not found.']}, status=404)
    result = generate_design(design.get('preferences', {}))
    if not result.get('success'):
        return json_response(result, status=400)
    layout = result['recommended_layout']
    try:
        updated = DesignPersistenceService().update_design(
            str(request.user.pk), design_id, {'layout': layout, 'score': layout.get('score')}
        )
    except Exception:
        logger.exception('Failed to persist regenerated design %s for user %s', design_id, request.user.pk)
        return json_response({'success': False, 'errors': ['The regenerated design could not be saved right now.']}, status=503)
    return json_response({'success': updated is not None, 'layout': layout, 'score': layout.get('score')})


def json_response(data, status=200):
    return JsonResponse(data, status=status)
