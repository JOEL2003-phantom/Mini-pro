"""Explainable soft metrics and weighted layout scoring."""

from math import hypot
from typing import Any

from .analyzer import PlanningSpec
from .rules import ADJACENCY_RULES, ROOM_RULES, SCORE_WEIGHTS


def _distance(first: dict[str, Any], second: dict[str, Any]) -> float:
    first_right = first['x'] + first['width']
    second_right = second['x'] + second['width']
    first_top = first['y'] + first['height']
    second_top = second['y'] + second['height']
    horizontal = max(second['x'] - first_right, first['x'] - second_right, 0)
    vertical = max(second['y'] - first_top, first['y'] - second_top, 0)
    return hypot(horizontal, vertical)


def adjacency_score(layout: dict[str, Any]) -> tuple[float, dict[str, list[str]]]:
    rooms = layout['rooms']
    by_type: dict[str, list[dict[str, Any]]] = {}
    for room in rooms:
        by_type.setdefault(room['type'], []).append(room)
    scores = []
    adjacency: dict[str, list[str]] = {room['id']: [] for room in rooms}
    for room in rooms:
        for preferred_type in ADJACENCY_RULES.get(room['type'], {}):
            for other in by_type.get(preferred_type, []):
                distance = _distance(room, other)
                scores.append(100 if distance == 0 else 80 if distance <= 5 else 55 if distance <= 12 else 25)
                if distance <= 12:
                    adjacency[room['id']].append(other['id'])
    return (sum(scores) / len(scores) if scores else 100.0), adjacency


def _privacy_score(layout: dict[str, Any]) -> float:
    public = [room for room in layout['rooms'] if room['type'] in {'living', 'dining', 'kitchen'}]
    private = [room for room in layout['rooms'] if room['type'] in {'bedroom', 'prayer', 'study'}]
    if not public or not private:
        return 100.0
    distances = [_distance(room, public_room) for room in private for public_room in public]
    return min(100.0, 45.0 + (sum(distances) / len(distances)) * 4)


def _proportion_score(layout: dict[str, Any]) -> float:
    scores = []
    for room in layout['rooms']:
        ratio = max(room['width'], room['height']) / min(room['width'], room['height'])
        preferred = ROOM_RULES.get(room['type'], {}).get('preferred_aspect', 1.0)
        normalized_preferred = max(preferred, 1 / preferred)
        deviation = abs(ratio - normalized_preferred)
        scores.append(max(0.0, 100.0 - deviation * 35))
    return sum(scores) / len(scores) if scores else 100.0


def _open_space_score(layout: dict[str, Any], spec: PlanningSpec) -> float:
    required = spec.features.get('garden_open_space', False)
    spaces = layout.get('open_spaces', [])
    if required and not spaces:
        return 0.0
    if not spaces:
        return 100.0
    open_area = sum(space['area'] for space in spaces)
    return min(100.0, open_area / (spec.plot_width * spec.plot_length) * 500)


def _parking_score(layout: dict[str, Any], spec: PlanningSpec) -> float:
    spaces = layout.get('parking', [])
    if len(spaces) != spec.parking_count:
        return 0.0
    if not spaces:
        return 100.0
    return 100.0 if all(space['y'] == 0 for space in spaces) else 70.0


def _style_score(layout: dict[str, Any], spec: PlanningSpec) -> float:
    zones = [room.get('zone') for room in layout['rooms']]
    public_count = zones.count('public')
    if spec.style in {'modern', 'minimalist'}:
        return min(100.0, 70.0 + public_count * 8)
    if spec.style in {'traditional', 'contemporary'}:
        return 78.0
    return 70.0


def _bathroom_relationship_score(layout: dict[str, Any]) -> float:
    bathrooms = [room for room in layout['rooms'] if room['type'] == 'bathroom']
    if not bathrooms:
        return 100.0
    attached = [room for room in bathrooms if room.get('bathroom_kind') == 'attached']
    valid_attached = [room for room in attached if room.get('attached_to')]
    common = [room for room in bathrooms if room.get('bathroom_kind') == 'common']
    return min(100.0, (len(valid_attached) / max(len(attached), 1) * 70) + (70 if common else 30))


def _natural_light_score(layout: dict[str, Any]) -> float:
    rooms = [room for room in layout['rooms'] if room['type'] not in {'storage', 'utility'}]
    if not rooms:
        return 100.0
    lit = {window.get('room_id') for window in layout.get('windows', [])}
    return len([room for room in rooms if room['id'] in lit]) / len(rooms) * 100


def _coherence_score(layout: dict[str, Any]) -> float:
    corridors = layout.get('circulation', {}).get('corridors', [])
    stairs = layout.get('stairs', [])
    return min(100.0, 60.0 + (20.0 if corridors else 0.0) + (20.0 if stairs or len({room.get('floor', 1) for room in layout['rooms']}) == 1 else 0.0))


def _furniture_fit_score(layout: dict[str, Any]) -> float:
    rooms = {room['id']: room for room in layout.get('rooms', [])}
    furniture = layout.get('furniture', [])
    if not furniture:
        return 100.0
    fitted = sum(1 for item in furniture if item.get('room_id') in rooms and all((
        item.get('x', 0) >= rooms[item['room_id']]['x'],
        item.get('y', 0) >= rooms[item['room_id']]['y'],
        item.get('x', 0) + item.get('width', 0) <= rooms[item['room_id']]['x'] + rooms[item['room_id']]['width'],
        item.get('y', 0) + item.get('height', 0) <= rooms[item['room_id']]['y'] + rooms[item['room_id']]['height'],
    )))
    return fitted / len(furniture) * 100


def _door_usability_score(layout: dict[str, Any]) -> float:
    doors = layout.get('doors', [])
    if not doors:
        return 0.0
    usable = sum(1 for door in doors if door.get('width', 0) >= 2.0 and door.get('swing_arc'))
    return usable / len(doors) * 100


def _floor_connectivity_score(layout: dict[str, Any]) -> float:
    floors = {room.get('floor', 1) for room in layout.get('rooms', [])}
    if len(floors) <= 1:
        return 100.0
    return 100.0 if any(stair.get('connects_floors') == list(range(1, max(floors) + 1)) for stair in layout.get('stairs', [])) else 0.0


def _room_size_balance_score(layout: dict[str, Any]) -> float:
    scores = []
    for room in layout.get('rooms', []):
        rule = ROOM_RULES.get(room.get('type'), {})
        target = rule.get('preferred_area', room.get('area', 0))
        if target:
            scores.append(max(0.0, 100.0 - abs(room['area'] - target) / target * 100))
    return sum(scores) / len(scores) if scores else 100.0


def _entrance_quality_score(layout: dict[str, Any]) -> float:
    entrances = layout.get('entrances', [])
    if not entrances:
        return 0.0
    target = next((room for room in layout.get('rooms', []) if room['id'] == entrances[0].get('connects_to')), None)
    return 100.0 if target and target.get('type') in {'living', 'dining'} else 35.0


def _staircase_quality_score(layout: dict[str, Any]) -> float:
    floors = {room.get('floor', 1) for room in layout.get('rooms', [])}
    if len(floors) <= 1:
        return 100.0
    stairs = layout.get('stairs', [])
    if not stairs:
        return 0.0
    stair = stairs[0]
    return 100.0 if stair.get('core') and stair.get('connects_to') == 'circulation' else 55.0


def calculate_metrics(layout: dict[str, Any], spec: PlanningSpec) -> dict[str, float]:
    adjacency, _ = adjacency_score(layout)
    available_area = spec.plot_width * spec.plot_length - sum(
        item['area'] for item in [*layout.get('parking', []), *layout.get('open_spaces', [])]
    )
    room_area = sum(room['area'] for room in layout['rooms'])
    efficiency = min(100.0, room_area / max(available_area, 1) * 100)
    connected = sum(
        1 for room in layout['rooms']
        if layout.get('connectivity', {}).get(room['id']) or layout['adjacency'].get(room['id'])
    )
    circulation = connected / len(layout['rooms']) * 100 if layout['rooms'] else 0.0
    privacy = _privacy_score(layout)
    return {
        'requirement_satisfaction': 100.0,
        'adjacency': adjacency,
        'space_efficiency': efficiency,
        'circulation': circulation,
        'proportion': _proportion_score(layout),
        'privacy': privacy,
        'open_space': _open_space_score(layout, spec),
        'parking': _parking_score(layout, spec),
        'preference_match': _style_score(layout, spec),
        'bathroom_relationship': _bathroom_relationship_score(layout),
        'natural_light': _natural_light_score(layout),
        'architectural_coherence': _coherence_score(layout),
        'furniture_fit': _furniture_fit_score(layout),
        'door_usability': _door_usability_score(layout),
        'floor_connectivity': _floor_connectivity_score(layout),
        'room_size_balance': _room_size_balance_score(layout),
        'entrance_quality': _entrance_quality_score(layout),
        'staircase_quality': _staircase_quality_score(layout),
    }


def score_layout(layout: dict[str, Any], spec: PlanningSpec) -> tuple[float, dict[str, float]]:
    metrics = calculate_metrics(layout, spec)
    weight_total = sum(SCORE_WEIGHTS.values()) or 1.0
    breakdown = {name: round(metrics[name] * weight / weight_total, 2) for name, weight in SCORE_WEIGHTS.items()}
    return round(sum(breakdown.values()), 2), breakdown