import json
from datetime import datetime
from unittest.mock import Mock, patch

from django.contrib.auth import get_user_model
from django.test import SimpleTestCase, TestCase, override_settings
from django.urls import reverse

from .persistence import (
	DesignPersistenceService,
	DesignValidationError,
	get_mongodb_client,
	validate_design_document,
	verify_mongodb_connection,
)


def make_design():
	return {
		'user_id': 'user-1',
		'design_id': 'design-1',
		'design_name': 'Courtyard concept',
		'plot': {'width': 30, 'length': 40, 'unit': 'feet'},
		'preferences': {'bedrooms': 3, 'floors': 1, 'style': 'modern'},
		'layout': {
			'rooms': [
				{
					'id': 'room-1',
					'name': 'Living room',
					'type': 'living_room',
					'x': 0,
					'y': 0,
					'width': 12,
					'height': 14,
					'doors': [],
					'windows': [],
					'adjacency': [],
				}
			],
			'doors': [],
			'windows': [],
			'adjacency': [],
			'plot_boundary': {'width': 30, 'length': 40},
			'score': None,
			'validation': {},
		},
	}


class InMemoryCursor(list):
	def sort(self, field, direction):
		return InMemoryCursor(sorted(self, key=lambda item: item[field], reverse=direction < 0))


class InMemoryCollection:
	def __init__(self):
		self.documents = []

	def insert_one(self, document):
		self.documents.append(document.copy())

	def find_one(self, query, projection=None):
		for document in self.documents:
			if all(document.get(key) == value for key, value in query.items()):
				return {key: value for key, value in document.items() if key != '_id'}
		return None

	def find(self, query, projection=None):
		return InMemoryCursor(
			[
				{key: value for key, value in document.items() if key != '_id'}
				for document in self.documents
				if all(document.get(key) == value for key, value in query.items())
			]
		)

	def replace_one(self, query, replacement):
		for index, document in enumerate(self.documents):
			if all(document.get(key) == value for key, value in query.items()):
				self.documents[index] = replacement.copy()
				return

	def delete_one(self, query):
		for index, document in enumerate(self.documents):
			if all(document.get(key) == value for key, value in query.items()):
				self.documents.pop(index)
				return Mock(deleted_count=1)
		return Mock(deleted_count=0)


class DesignPersistenceTests(SimpleTestCase):
	def setUp(self):
		self.collection = InMemoryCollection()
		self.service = DesignPersistenceService(self.collection)

	def test_create_and_retrieve_design(self):
		created = self.service.create_design(make_design())
		retrieved = self.service.get_design('user-1', 'design-1')

		self.assertEqual(retrieved['design_name'], 'Courtyard concept')
		self.assertEqual(retrieved['plot']['width'], 30)
		self.assertIsInstance(created['created_at'], datetime)

	def test_update_design(self):
		self.service.create_design(make_design())
		updated = self.service.update_design('user-1', 'design-1', {'design_name': 'Updated concept'})

		self.assertEqual(updated['design_name'], 'Updated concept')
		self.assertEqual(self.service.get_design('user-1', 'design-1')['design_name'], 'Updated concept')

	def test_delete_design(self):
		self.service.create_design(make_design())

		self.assertTrue(self.service.delete_design('user-1', 'design-1'))
		self.assertIsNone(self.service.get_design('user-1', 'design-1'))

	def test_lists_only_designs_for_user(self):
		self.service.create_design(make_design())
		other = make_design()
		other['user_id'] = 'user-2'
		other['design_id'] = 'design-2'
		self.service.create_design(other)

		designs = self.service.list_designs('user-1')

		self.assertEqual([design['design_id'] for design in designs], ['design-1'])

	def test_rejects_invalid_geometry_and_missing_identifiers(self):
		invalid = make_design()
		invalid['layout']['rooms'][0]['width'] = -1
		with self.assertRaises(DesignValidationError):
			validate_design_document(invalid)

		invalid = make_design()
		invalid.pop('design_id')
		with self.assertRaises(DesignValidationError):
			validate_design_document(invalid)


class MongoConfigurationTests(SimpleTestCase):
	@patch('designs.persistence.MongoClient')
	def test_client_uses_configured_uri(self, mongo_client):
		with patch('designs.persistence._mongo_client', None):
			get_mongodb_client()
		mongo_client.assert_called_once()

	@patch('designs.persistence.get_mongodb_client')
	def test_connection_verification_pings_server(self, get_client):
		verify_mongodb_connection()
		get_client.return_value.admin.command.assert_called_once_with('ping')


class HouseRequirementsFormTests(SimpleTestCase):
	def test_valid_requirements_are_structured(self):
		from .forms import HouseRequirementsForm

		form = HouseRequirementsForm({
			'plot_width': '30',
			'plot_length': '50',
			'unit': 'ft',
			'bedrooms': '3',
			'bathrooms': '2',
			'kitchen': '1',
			'living_room': '1',
			'dining_room': '1',
			'parking': '1',
			'floors': '1',
			'style': 'modern',
			'budget': '3000000',
			'additional_requirements': 'More natural light',
		})

		self.assertTrue(form.is_valid())
		preferences = form.to_preferences()
		self.assertEqual(preferences['plot'], {'width': 30.0, 'length': 50.0, 'unit': 'ft'})
		self.assertEqual(preferences['rooms']['bedrooms'], 3)
		self.assertEqual(preferences['budget'], 3000000.0)

	def test_non_positive_plot_dimensions_are_rejected(self):
		from .forms import HouseRequirementsForm

		for field, value in (('plot_width', '0'), ('plot_length', '-5')):
			data = {'plot_width': '30', 'plot_length': '50', 'unit': 'ft', field: value}
			form = HouseRequirementsForm(data)
			self.assertFalse(form.is_valid())

	def test_invalid_counts_and_style_are_rejected(self):
		from .forms import HouseRequirementsForm

		form = HouseRequirementsForm({
			'plot_width': '30', 'plot_length': '50', 'unit': 'ft',
			'bedrooms': '-1', 'bathrooms': '2', 'kitchen': '1',
			'living_room': '1', 'dining_room': '1', 'parking': '1', 'floors': '1',
			'style': 'unsupported',
		})

		self.assertFalse(form.is_valid())

	def test_other_style_requires_description(self):
		from .forms import HouseRequirementsForm

		form = HouseRequirementsForm({
			'plot_width': '30', 'plot_length': '50', 'unit': 'ft',
			'bedrooms': '3', 'bathrooms': '2', 'kitchen': '1',
			'living_room': '1', 'dining_room': '1', 'parking': '1', 'floors': '1',
			'style': 'other',
		})

		self.assertFalse(form.is_valid())
		self.assertIn('style_other', form.errors)


@override_settings(PASSWORD_HASHERS=['django.contrib.auth.hashers.MD5PasswordHasher'])
class HouseRequirementsViewTests(TestCase):
	def setUp(self):
		self.user = get_user_model().objects.create_user(
			username='designer', email='designer@example.com', password='StrongPassword!123'
		)
		self.client.force_login(self.user)
		self.valid_data = {
			'design_name': 'Sunny courtyard home',
			'plot_width': '30', 'plot_length': '50', 'unit': 'ft',
			'bedrooms': '3', 'bathrooms': '2', 'kitchen': '1',
			'living_room': '1', 'dining_room': '1', 'parking': '1', 'floors': '1',
			'balcony': 'on', 'storage_room': 'on', 'style': 'modern',
			'budget': '3000000', 'additional_requirements': 'More natural light',
		}

	@staticmethod
	def service_mock():
		from unittest.mock import Mock
		return Mock()

	def test_authenticated_form_page_loads(self):
		response = self.client.get(reverse('designs:new'))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Tell us about your dream home.')

	@patch('designs.views.DesignPersistenceService')
	def test_authenticated_library_renders_saved_designs(self, service_class):
		saved = make_design()
		saved['user_id'] = str(self.user.pk)
		service_class.return_value.list_designs.return_value = [saved]

		response = self.client.get(reverse('designs:library'))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Design Library')
		self.assertContains(response, 'Courtyard concept')
		self.assertContains(response, reverse('designs:review', args=['design-1']))
		self.assertContains(response, reverse('designs:delete_design', args=['design-1']))

	@patch('designs.views.DesignPersistenceService')
	def test_authenticated_user_can_delete_a_design(self, service_class):
		service_class.return_value.delete_design.return_value = True

		response = self.client.post(reverse('designs:delete_design', args=['design-1']))

		self.assertEqual(response.status_code, 302)
		self.assertRedirects(response, reverse('designs:library'))

	@patch('designs.views.evaluate_layout')
	@patch('designs.views.DesignPersistenceService')
	def test_save_layout_allows_warnings_without_failing(self, service_class, evaluate_layout_mock):
		design = make_design()
		design['user_id'] = str(self.user.pk)
		design['design_id'] = 'design-1'
		service_class.return_value.get_design.return_value = design
		service_class.return_value.update_design.return_value = {
			**design,
			'layout': {'rooms': []},
			'current_layout': {'rooms': []},
			'score': None,
		}
		evaluate_layout_mock.return_value = {
			'valid': False,
			'errors': ['Room overlap detected'],
			'warnings': ['Minor adjustment recommended'],
			'score': None,
		}

		response = self.client.post(
			reverse('designs:save_layout', args=['design-1']),
			data=json.dumps({'layout': {'rooms': []}}),
			content_type='application/json',
		)

		self.assertEqual(response.status_code, 200)
		payload = json.loads(response.content.decode())
		self.assertTrue(payload['success'])
		self.assertTrue(payload['saved_with_warnings'])
		self.assertIn('Room overlap detected', payload['errors'])
		self.assertIn('Minor adjustment recommended', payload['warnings'])
		self.assertEqual(payload['layout']['rooms'], [])

	def test_anonymous_library_access_redirects_to_login(self):
		self.client.logout()

		response = self.client.get(reverse('designs:library'))

		self.assertRedirects(
			response,
			f'{reverse("accounts:login")}?next={reverse("designs:library")}',
		)

	def test_anonymous_form_access_redirects_to_login(self):
		self.client.logout()

		response = self.client.get(reverse('designs:new'))

		self.assertRedirects(
			response,
			f'{reverse("accounts:login")}?next={reverse("designs:new")}',
		)

	@patch('designs.views.DesignPersistenceService')
	def test_valid_submission_saves_structured_owned_record(self, service_class):
		service = self.service_mock()
		service_class.return_value = service

		response = self.client.post(reverse('designs:new'), self.valid_data)

		saved = service.create_design.call_args.args[0]
		self.assertEqual(response.status_code, 302)
		self.assertEqual(response.url, reverse('designs:review', args=[saved['design_id']]))
		self.assertEqual(saved['user_id'], str(self.user.pk))
		self.assertEqual(saved['plot'], {'width': 30.0, 'length': 50.0, 'unit': 'ft'})
		self.assertEqual(saved['preferences']['rooms']['bedrooms'], 3)
		self.assertEqual(saved['preferences']['style'], 'modern')
		self.assertEqual(saved['preferences']['budget'], 3000000.0)
		self.assertTrue(saved['preferences']['features']['balcony'])
		self.assertIsNone(saved['layout'])
		self.assertIsNone(saved['score'])

	@patch('designs.views.DesignPersistenceService')
	def test_review_displays_saved_requirements_without_layout(self, service_class):
		service_class.return_value.get_design.return_value = {
			'design_id': 'design-1',
			'design_name': 'Sunny courtyard home',
			'plot': {'width': 30.0, 'length': 50.0, 'unit': 'ft'},
			'preferences': {
				'rooms': {'bedrooms': 3, 'bathrooms': 2, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
				'style': 'modern', 'style_other': '', 'budget': 3000000.0,
				'features': {'balcony': True}, 'additional_requirements': 'More natural light',
			},
			'layout': None,
		}

		response = self.client.get(reverse('designs:review', args=['design-1']))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Sunny courtyard home')
		self.assertContains(response, '30.0 × 50.0 ft')
		self.assertContains(response, 'More natural light')
		self.assertContains(response, reverse('designs:visualize', args=['design-1']))

	@patch('designs.views.DesignPersistenceService')
	def test_browser_user_id_cannot_override_authenticated_owner(self, service_class):
		service = self.service_mock()
		service_class.return_value = service
		data = {**self.valid_data, 'user_id': 'another-user'}

		self.client.post(reverse('designs:new'), data)

		saved = service.create_design.call_args.args[0]
		self.assertEqual(saved['user_id'], str(self.user.pk))
		self.assertNotEqual(saved['user_id'], 'another-user')

	@patch('designs.views.DesignPersistenceService')
	def test_persistence_failure_returns_friendly_form_error(self, service_class):
		service_class.return_value.create_design.side_effect = RuntimeError('database unavailable')

		response = self.client.post(reverse('designs:new'), self.valid_data)

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Your requirements could not be saved. Please try again.')

	@patch('designs.views.parse_house_requirements')
	def test_natural_language_interpretation_populates_editable_form(self, parse_requirements):
		parse_requirements.return_value = {
			'plot': {'width': 30.0, 'length': 40.0, 'unit': 'ft'},
			'rooms': {'bedrooms': 4, 'bathrooms': 3, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
			'parking': 2, 'floors': 1,
			'features': {'balcony': True, 'garden_open_space': True},
			'style': 'modern', 'style_other': '', 'budget': None, 'additional_requirements': '',
		}

		response = self.client.post(reverse('designs:new'), {
			'action': 'interpret',
			'natural_language': 'A four bedroom house on a 30 by 40 foot plot',
		})

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Requirements understood.')
		self.assertContains(response, 'value="30.0"')
		self.assertContains(response, 'value="4"')
		parse_requirements.assert_called_once()


@override_settings(PASSWORD_HASHERS=['django.contrib.auth.hashers.MD5PasswordHasher'])
class VisualizationViewTests(TestCase):
	def setUp(self):
		self.user = get_user_model().objects.create_user(
			username='visualizer', email='visualizer@example.com', password='StrongPassword!123'
		)
		self.client.force_login(self.user)
		self.design = {
			'user_id': str(self.user.pk),
			'design_id': 'design-visual-1',
			'design_name': 'Visualization sample',
			'plot': {'width': 30.0, 'length': 50.0, 'unit': 'ft'},
			'preferences': {
				'plot': {'width': 30.0, 'length': 50.0, 'unit': 'ft'},
				'rooms': {'bedrooms': 3, 'bathrooms': 2, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
				'parking': 1, 'floors': 1, 'features': {'garden_open_space': True},
				'style': 'modern', 'budget': 3000000.0, 'additional_requirements': '',
			},
			'layout': None,
		}

	@patch('designs.views.DesignPersistenceService')
	def test_visualization_renders_phase_five_layout_data(self, service_class):
		service_class.return_value.get_design.return_value = self.design

		response = self.client.get(reverse('designs:visualize', args=[self.design['design_id']]))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'recommended-layout')
		self.assertContains(response, 'Your selected plan for')
		self.assertContains(response, 'Valid layout')

	def test_anonymous_visualization_access_redirects_to_login(self):
		self.client.logout()

		response = self.client.get(reverse('designs:visualize', args=[self.design['design_id']]))

		self.assertRedirects(
			response,
			f'{reverse("accounts:login")}?next={reverse("designs:visualize", args=[self.design["design_id"]])}',
		)

	@patch('designs.views.DesignPersistenceService')
	def test_design_lookup_is_scoped_to_authenticated_user(self, service_class):
		service_class.return_value.get_design.return_value = None

		response = self.client.get(reverse('designs:visualize', args=['belongs-to-someone-else']))

		self.assertRedirects(response, reverse('dashboard'))
		service_class.return_value.get_design.assert_called_once_with(str(self.user.pk), 'belongs-to-someone-else')

	@patch('designs.views.DesignPersistenceService')
	def test_generation_failure_shows_empty_state_without_svg(self, service_class):
		bad_design = {**self.design, 'preferences': {'plot': {'width': 0, 'length': 50, 'unit': 'ft'}, 'rooms': {}}}
		service_class.return_value.get_design.return_value = bad_design

		response = self.client.get(reverse('designs:visualize', args=[self.design['design_id']]))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'No generated layout is available yet.')
		self.assertNotContains(response, 'recommended-layout')

	@patch('designs.views.generate_design')
	@patch('designs.views.DesignPersistenceService')
	def test_infeasible_review_shows_user_decision_options(self, service_class, generate):
		service_class.return_value.get_design.return_value = self.design
		generate.return_value = {
			'success': False,
			'errors': ['The requested house program cannot reasonably be accommodated.'],
			'feasibility': {
				'status': 'infeasible', 'requires_user_decision': True,
				'issues': ['The requested house program cannot reasonably be accommodated.'],
				'options': [],
			},
			'plans': [],
		}

		response = self.client.get(reverse('designs:review', args=[self.design['design_id']]))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Your requirements need more space.')
		self.assertContains(response, 'Adjust requirements')
		self.assertContains(response, 'Consider two floors')
		self.assertContains(response, 'Change plot dimensions')
		self.assertNotContains(response, 'View generated floor plans')

	@patch('designs.views.apply_feasibility_decision')
	@patch('designs.views.DesignPersistenceService')
	def test_two_floor_choice_preserves_requirements_and_redirects_when_feasible(self, service_class, apply_decision):
		service_class.return_value.get_design.return_value = self.design
		service_class.return_value.update_design.return_value = self.design
		layout = {'plot': self.design['plot'], 'rooms': [], 'score': {'total': 80}}
		apply_decision.return_value = {
			'success': True, 'requirements': {**self.design['preferences'], 'floors': 2},
			'recommended_layout': layout, 'plans': [layout],
		}

		response = self.client.post(
			reverse('designs:decision', args=[self.design['design_id']]),
			{'decision': 'add_floor'},
		)

		self.assertRedirects(response, reverse('designs:visualize', args=[self.design['design_id']]))
		apply_decision.assert_called_once_with(self.design['preferences'], 'add_floor', updated_requirements=None)
		updates = service_class.return_value.update_design.call_args.args[2]
		self.assertEqual(updates['preferences']['floors'], 2)
		self.assertEqual(updates['preferences']['rooms'], self.design['preferences']['rooms'])
		self.assertIsNone(updates['layout'])

	@patch('designs.views.generate_design')
	@patch('designs.views.DesignPersistenceService')
	def test_visualizer_exposes_multiple_plan_gallery_data(self, service_class, generate):
		service_class.return_value.get_design.return_value = self.design
		plans = [
			{'plot': self.design['plot'], 'rooms': [], 'score': {'total': 90}, 'validation': {'valid': True}},
			{'plot': self.design['plot'], 'rooms': [], 'score': {'total': 82}, 'validation': {'valid': True}},
		]
		generate.return_value = {
			'success': True, 'recommended_layout': plans[0], 'alternatives': [plans[1]],
			'plans': plans, 'candidates': plans,
		}

		response = self.client.get(reverse('designs:visualize', args=[self.design['design_id']]))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'plan-gallery-data')
		self.assertContains(response, 'plan-gallery-grid')
		from pathlib import Path
		self.assertIn('Select Plan', Path('static/js/plan_gallery.js').read_text())

	@patch('designs.views.apply_feasibility_decision')
	@patch('designs.views.DesignPersistenceService')
	def test_change_plot_choice_updates_only_plot_dimensions(self, service_class, apply_decision):
		service_class.return_value.get_design.return_value = self.design
		service_class.return_value.update_design.return_value = self.design
		updated = {**self.design['preferences'], 'plot': {'width': 50.0, 'length': 60.0, 'unit': 'ft'}}
		apply_decision.return_value = {'success': True, 'requirements': updated, 'recommended_layout': {'score': {'total': 75}}}

		response = self.client.post(
			reverse('designs:decision', args=[self.design['design_id']]),
			{'decision': 'change_plot', 'plot_width': '50', 'plot_length': '60'},
		)

		self.assertRedirects(response, reverse('designs:visualize', args=[self.design['design_id']]))
		changed = apply_decision.call_args.kwargs['updated_requirements']
		self.assertEqual(changed['plot']['width'], 50.0)
		self.assertEqual(changed['rooms'], self.design['preferences']['rooms'])

	@patch('designs.views.generate_design')
	@patch('designs.views.DesignPersistenceService')
	def test_plan_selection_persists_the_selected_plan(self, service_class, generate):
		service_class.return_value.get_design.return_value = self.design
		plans = [
			{'plot': self.design['plot'], 'rooms': [], 'score': {'total': 90}},
			{'plot': self.design['plot'], 'rooms': [], 'score': {'total': 82}},
		]
		generate.return_value = {'success': True, 'plans': plans}
		service_class.return_value.update_design.return_value = self.design

		response = self.client.post(
			reverse('designs:select_plan', args=[self.design['design_id']]),
			{'plan_index': '1'},
		)

		self.assertRedirects(response, reverse('designs:visualize', args=[self.design['design_id']]))
		selected = service_class.return_value.update_design.call_args.args[2]['layout']
		self.assertEqual(selected['plot']['width'], plans[1]['plot']['width'])
		self.assertEqual(selected['plot']['length'], plans[1]['plot']['length'])
		self.assertEqual(selected['plot']['id'], 'plot')
		self.assertIn('walls', selected)
		self.assertTrue(selected['walls'])
		self.assertEqual(selected['score'], plans[1]['score'])

	@patch('designs.views.DesignPersistenceService')
	def test_svg_export_is_owned_and_structured(self, service_class):
		layout = {
			'plot': self.design['plot'],
			'rooms': [{'id': 'living_1', 'name': 'Living room', 'type': 'living', 'x': 0, 'y': 0, 'width': 10, 'height': 10, 'area': 100}],
			'parking': [], 'open_spaces': [], 'doors': [], 'windows': [],
			'score': {'total': 82}, 'validation': {'valid': True},
		}
		design = {**self.design, 'layout': layout}
		service_class.return_value.get_design.return_value = design

		response = self.client.get(reverse('designs:export_svg', args=[self.design['design_id']]))

		self.assertEqual(response.status_code, 200)
		self.assertEqual(response['Content-Type'], 'image/svg+xml')
		self.assertIn('Living room', response.content.decode())
		self.assertIn('DREAM HOME', response.content.decode())

	def test_anonymous_export_is_protected(self):
		self.client.logout()

		response = self.client.get(reverse('designs:export_svg', args=[self.design['design_id']]))

		self.assertEqual(response.status_code, 302)

	@patch('designs.views.evaluate_layout')
	@patch('designs.views.DesignPersistenceService')
	def test_validate_endpoint_recalculates_edited_layout(self, service_class, evaluate):
		service_class.return_value.get_design.return_value = self.design
		evaluate.return_value = {'valid': True, 'errors': [], 'warnings': [], 'score': {'total': 80, 'breakdown': {}}}

		response = self.client.post(
			reverse('designs:validate', args=[self.design['design_id']]),
			data={'layout': {'plot': self.design['plot'], 'rooms': []}},
			content_type='application/json',
		)

		self.assertEqual(response.status_code, 200)
		self.assertTrue(response.json()['valid'])
		evaluate.assert_called_once()
		service_class.return_value.get_design.assert_called_once_with(str(self.user.pk), self.design['design_id'])

	@patch('designs.views.evaluate_layout')
	@patch('designs.views.DesignPersistenceService')
	def test_save_endpoint_requires_valid_layout_and_preserves_owner(self, service_class, evaluate):
		service_class.return_value.get_design.return_value = self.design
		evaluate.return_value = {'valid': True, 'errors': [], 'warnings': [], 'score': {'total': 84, 'breakdown': {}}}
		service_class.return_value.update_design.return_value = {**self.design, 'layout': {'rooms': []}}

		response = self.client.post(
			reverse('designs:save_layout', args=[self.design['design_id']]),
			data={'layout': {'plot': self.design['plot'], 'rooms': []}},
			content_type='application/json',
		)

		self.assertEqual(response.status_code, 200)
		service_class.return_value.update_design.assert_called_once()
		self.assertEqual(service_class.return_value.update_design.call_args.args[0], str(self.user.pk))

	@patch('designs.views.evaluate_layout')
	@patch('designs.views.DesignPersistenceService')
	def test_save_endpoint_persists_current_editor_layout(self, service_class, evaluate):
		service_class.return_value.get_design.return_value = self.design
		custom_layout = {'plot': self.design['plot'], 'rooms': [{'id': 'room-1', 'name': 'Living room', 'type': 'living', 'x': 12, 'y': 18, 'width': 10, 'height': 10, 'area': 100}]}
		evaluate.return_value = {'valid': True, 'errors': [], 'warnings': [], 'score': {'total': 91, 'breakdown': {}}}
		service_class.return_value.update_design.return_value = {**self.design, 'layout': custom_layout, 'current_layout': custom_layout}

		response = self.client.post(
			reverse('designs:save_layout', args=[self.design['design_id']]),
			data={'layout': custom_layout},
			content_type='application/json',
		)

		self.assertEqual(response.status_code, 200)
		payload = service_class.return_value.update_design.call_args.args[2]
		self.assertEqual(payload['layout']['plot']['width'], custom_layout['plot']['width'])
		self.assertEqual(payload['layout']['plot']['length'], custom_layout['plot']['length'])
		self.assertEqual(payload['layout']['plot']['id'], 'plot')
		self.assertEqual(payload['layout']['rooms'][0]['id'], custom_layout['rooms'][0]['id'])
		self.assertIn('walls', payload['layout'])
		self.assertTrue(payload['layout']['walls'])
		self.assertEqual(payload['current_layout']['rooms'][0]['id'], custom_layout['rooms'][0]['id'])

	@patch('designs.views.evaluate_layout')
	@patch('designs.views.DesignPersistenceService')
	def test_save_endpoint_rejects_invalid_layout(self, service_class, evaluate):
		service_class.return_value.get_design.return_value = self.design
		evaluate.return_value = {'valid': False, 'errors': ['Room overlaps another room.'], 'warnings': [], 'score': None}

		response = self.client.post(
			reverse('designs:save_layout', args=[self.design['design_id']]),
			data={'layout': {'plot': self.design['plot'], 'rooms': []}},
			content_type='application/json',
		)

		self.assertEqual(response.status_code, 400)
		service_class.return_value.update_design.assert_not_called()

	@patch('designs.views.generate_design')
	@patch('designs.views.DesignPersistenceService')
	def test_regenerate_endpoint_uses_existing_engine_and_owner(self, service_class, generate):
		service_class.return_value.get_design.return_value = self.design
		layout = {'plot': self.design['plot'], 'rooms': [], 'score': {'total': 70}, 'validation': {'valid': True}}
		generate.return_value = {'success': True, 'recommended_layout': layout}
		service_class.return_value.update_design.return_value = self.design

		response = self.client.post(reverse('designs:regenerate', args=[self.design['design_id']]))

		self.assertEqual(response.status_code, 200)
		generate.assert_called_once_with(self.design['preferences'])
		self.assertEqual(service_class.return_value.update_design.call_args.args[0], str(self.user.pk))


class SvgTemplateContractTests(SimpleTestCase):
	def test_visualizer_template_contains_independent_svg_groups(self):
		from pathlib import Path

		renderer = Path('static/js/floor_plan.js').read_text()
		for group in ('plot', 'walls', 'rooms', 'doors', 'windows', 'dimensions', 'annotations'):
			self.assertIn(f"id: '{group}'", renderer)

	def test_renderer_supports_structured_architecture_and_multiple_floors(self):
		from pathlib import Path

		renderer = Path('static/js/floor_plan.js').read_text()
		for marker in ('renderWall', 'renderStructuredFurniture', 'renderStairs', 'floor-tabs', 'currentFloor'):
			self.assertIn(marker, renderer)
