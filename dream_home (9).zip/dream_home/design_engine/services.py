"""Public Phase 5 design-engine service interface."""

from typing import Any

from .analyzer import RequirementError, analyze_requirements
from .diversity import select_diverse_layouts
from .generator import GenerationError, generate_candidates


FEASIBILITY_OPTIONS = [
    {'id': 'adjust_requirements', 'label': 'Adjust requirements'},
    {'id': 'add_floor', 'label': 'Consider another floor'},
    {'id': 'change_plot', 'label': 'Change plot dimensions'},
]


def _feasible_result() -> dict[str, Any]:
    return {
        'status': 'feasible',
        'requires_user_decision': False,
        'issues': [],
        'suggestions': [],
    }


def _infeasible_result(issue: str) -> dict[str, Any]:
    return {
        'status': 'infeasible',
        'requires_user_decision': True,
        'issues': [issue],
        'options': FEASIBILITY_OPTIONS,
    }


def generate_design(
    requirements: dict[str, Any],
    candidate_count: int = 6,
    seed: int = 0,
    architectural_intent: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Generate, validate, score, and rank deterministic structured layouts."""
    try:
        spec = analyze_requirements(requirements)
        candidates = generate_candidates(
            spec,
            candidate_count=candidate_count,
            seed=seed,
            architectural_intent=architectural_intent,
        )
    except (RequirementError, GenerationError) as error:
        result = {'success': False, 'errors': [str(error)], 'warnings': [], 'candidates': []}
        if isinstance(error, GenerationError):
            result['feasibility'] = _infeasible_result(str(error))
        return result
    valid = [candidate for candidate in candidates if candidate['validation']['valid']]
    selected = select_diverse_layouts(valid, limit=candidate_count)
    if not selected:
        issue = 'The requested house program cannot reasonably be accommodated within the specified plot and floor configuration.'
        return {
            'success': False,
            'errors': [issue],
            'warnings': [],
            'candidates': candidates,
            'plans': [],
            'feasibility': _infeasible_result(issue),
        }
    return {
        'success': True,
        'feasibility': _feasible_result(),
        'recommended_layout': selected[0],
        'alternatives': selected[1:],
        'candidates': candidates,
        'plans': selected,
        'generation_summary': {
            'candidate_count': len(candidates), 'valid_candidate_count': len(valid),
            'selected_plan_count': len(selected),
            'unit': spec.unit, 'floors': spec.floors, 'style': spec.style,
        },
    }


def resolve_feasibility_decision(
    requirements: dict[str, Any],
    decision: str,
    updated_requirements: dict[str, Any] | None = None,
    candidate_count: int = 6,
    seed: int = 0,
) -> dict[str, Any]:
    """Apply only an explicit user decision, then rerun the unchanged engine."""
    if decision == 'adjust_requirements':
        if updated_requirements is None:
            return {'success': False, 'errors': ['Updated requirements are required for this option.']}
        next_requirements = updated_requirements
    elif decision == 'add_floor':
        next_requirements = {**requirements, 'floors': int(requirements.get('floors', 1)) + 1}
    elif decision == 'change_plot':
        if not updated_requirements or 'plot' not in updated_requirements:
            return {'success': False, 'errors': ['Updated plot dimensions are required for this option.']}
        next_requirements = updated_requirements
    else:
        return {'success': False, 'errors': ['A valid feasibility decision is required.']}

    result = generate_design(next_requirements, candidate_count=candidate_count, seed=seed)
    result['original_requirements'] = requirements
    result['requirements'] = next_requirements
    return result