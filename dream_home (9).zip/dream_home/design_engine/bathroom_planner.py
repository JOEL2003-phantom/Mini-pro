"""Deterministic bathroom relationship planning for residential layouts."""

from typing import Any


def assign_bathrooms(requirements: list[Any]) -> dict[str, dict[str, Any]]:
    """Assign the first available bathrooms to bedrooms, with remaining baths common."""
    bedrooms = [item for item in requirements if item.room_type == 'bedroom']
    bathrooms = [item for item in requirements if item.room_type == 'bathroom']
    assignments: dict[str, dict[str, Any]] = {}
    attached_count = min(max(len(bathrooms) - 1, 0), len(bedrooms))
    # Keep a serviceable common-bathroom core on larger upper-floor programs;
    # every bedroom does not need an ensuite to satisfy the residential brief.
    if len(bedrooms) >= 4 and len(bathrooms) >= 3:
        attached_count = 1
    for index, bathroom in enumerate(bathrooms):
        if index < attached_count:
            bedroom = bedrooms[index]
            assignments[bathroom.id] = {
                'kind': 'attached',
                'attached_to': bedroom.id,
                'access': 'private',
            }
        else:
            assignments[bathroom.id] = {
                'kind': 'common',
                'attached_to': None,
                'access': 'circulation',
            }
    return assignments


def apply_bathroom_relationships(
    rooms: list[dict[str, Any]], assignments: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """Copy relationship metadata onto generated room records."""
    for room in rooms:
        if room.get('type') != 'bathroom':
            continue
        relationship = assignments.get(room.get('id'), {'kind': 'common', 'attached_to': None, 'access': 'circulation'})
        room['bathroom_kind'] = relationship['kind']
        room['attached_to'] = relationship['attached_to']
        room['access'] = relationship['access']
        if relationship['kind'] == 'attached':
            room['zone'] = 'private'
    return rooms


def validate_bathroom_relationships(rooms: list[dict[str, Any]]) -> list[str]:
    errors = []
    by_id = {room.get('id'): room for room in rooms}
    for bathroom in (room for room in rooms if room.get('type') == 'bathroom'):
        if bathroom.get('bathroom_kind') != 'attached':
            continue
        target = by_id.get(bathroom.get('attached_to'))
        if target is None:
            errors.append(f"attached bathroom {bathroom.get('id', '?')} has no target bedroom")
            continue
        if target.get('floor', 1) != bathroom.get('floor', 1):
            errors.append(f"attached bathroom {bathroom.get('id', '?')} is on a different floor")
            continue
        touches = (
            abs(bathroom['x'] + bathroom['width'] - target['x']) < 0.01
            or abs(target['x'] + target['width'] - bathroom['x']) < 0.01
            or abs(bathroom['y'] + bathroom['height'] - target['y']) < 0.01
            or abs(target['y'] + target['height'] - bathroom['y']) < 0.01
        )
        if not touches:
            errors.append(f"attached bathroom {bathroom.get('id', '?')} is not adjacent to {target.get('id', '?')}")
    return errors
