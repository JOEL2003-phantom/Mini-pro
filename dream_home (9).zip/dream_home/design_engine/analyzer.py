"""Normalize Phase 4 preferences into an engine-owned planning specification."""

from dataclasses import dataclass
from typing import Any


class RequirementError(ValueError):
    """Raised when requirements cannot be normalized for planning."""


@dataclass(frozen=True)
class RoomRequirement:
    id: str
    name: str
    room_type: str


@dataclass(frozen=True)
class PlanningSpec:
    plot_width: float
    plot_length: float
    unit: str
    rooms: tuple[RoomRequirement, ...]
    parking_count: int
    floors: int
    features: dict[str, bool]
    style: str
    style_other: str
    budget: float | None
    additional_requirements: str

    @property
    def plot(self) -> dict[str, float | str]:
        return {'width': self.plot_width, 'length': self.plot_length, 'unit': self.unit}

    @property
    def room_counts(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for room in self.rooms:
            counts[room.room_type] = counts.get(room.room_type, 0) + 1
        return counts


ROOM_COUNT_FIELDS = (
    ('bedrooms', 'bedroom', 'Bedroom'),
    ('bathrooms', 'bathroom', 'Bathroom'),
    ('kitchen', 'kitchen', 'Kitchen'),
    ('living_room', 'living', 'Living room'),
    ('dining_room', 'dining', 'Dining room'),
)

OPTIONAL_ROOM_FEATURES = (
    ('utility_room', 'utility', 'Utility room'),
    ('work_study_room', 'study', 'Study room'),
    ('prayer_room', 'prayer', 'Prayer room'),
    ('storage_room', 'storage', 'Storage room'),
    ('balcony', 'balcony', 'Balcony'),
)


def _number(value: Any, field: str, minimum: float = 0) -> float:
    if isinstance(value, bool):
        raise RequirementError(f'{field} must be numeric')
    try:
        number = float(value)
    except (TypeError, ValueError) as error:
        raise RequirementError(f'{field} must be numeric') from error
    if number < minimum:
        raise RequirementError(f'{field} must be at least {minimum}')
    return number


def _count(value: Any, field: str, minimum: int = 0) -> int:
    number = _number(value, field, minimum)
    if number != int(number):
        raise RequirementError(f'{field} must be a whole number')
    return int(number)


def analyze_requirements(requirements: dict[str, Any]) -> PlanningSpec:
    if not isinstance(requirements, dict):
        raise RequirementError('requirements must be an object')
    plot = requirements.get('plot')
    rooms = requirements.get('rooms')
    if not isinstance(plot, dict):
        raise RequirementError('plot requirements are required')
    if not isinstance(rooms, dict):
        raise RequirementError('room requirements are required')

    width = _number(plot.get('width'), 'plot.width', 0.01)
    length = _number(plot.get('length'), 'plot.length', 0.01)
    unit = str(plot.get('unit', 'ft')).strip().lower()
    if unit != 'ft':
        raise RequirementError('only feet (ft) are currently supported')

    room_instances: list[RoomRequirement] = []
    for field, room_type, label in ROOM_COUNT_FIELDS:
        count = _count(rooms.get(field, 0), f'rooms.{field}')
        for index in range(1, count + 1):
            room_instances.append(RoomRequirement(f'{room_type}_{index}', f'{label} {index}', room_type))
    features = requirements.get('features', {})
    if not isinstance(features, dict):
        raise RequirementError('features must be an object')
    for field, room_type, label in OPTIONAL_ROOM_FEATURES:
        if features.get(field, False):
            room_instances.append(RoomRequirement(f'{room_type}_1', label, room_type))

    parking_count = _count(requirements.get('parking', 0), 'parking')
    floors = _count(requirements.get('floors', 1), 'floors', 1)
    style = str(requirements.get('style', 'modern')).strip().lower()
    if not style:
        raise RequirementError('style is required')
    budget = requirements.get('budget')
    normalized_budget = None if budget in (None, '') else _number(budget, 'budget')
    return PlanningSpec(
        width, length, unit, tuple(room_instances), parking_count, floors,
        {key: bool(value) for key, value in features.items()}, style,
        str(requirements.get('style_other', '')).strip(), normalized_budget,
        str(requirements.get('additional_requirements', '')).strip(),
    )