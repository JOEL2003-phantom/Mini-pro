"""Architectural wall geometry derived from room boundaries."""

from typing import Any


def generate_walls(rooms: list[dict[str, Any]], plot: dict[str, Any], wall_thickness: float = 0.25) -> list[dict[str, Any]]:
    walls: list[dict[str, Any]] = []
    floors = sorted({room.get('floor', 1) for room in rooms} or {1})
    for floor in floors:
        walls.extend([
            {'id': f'exterior_{floor}_north', 'type': 'exterior', 'floor': floor, 'orientation': 'horizontal', 'x': 0.0, 'y': 0.0, 'length': plot['width'], 'thickness': wall_thickness},
            {'id': f'exterior_{floor}_south', 'type': 'exterior', 'floor': floor, 'orientation': 'horizontal', 'x': 0.0, 'y': plot['length'], 'length': plot['width'], 'thickness': wall_thickness},
            {'id': f'exterior_{floor}_west', 'type': 'exterior', 'floor': floor, 'orientation': 'vertical', 'x': 0.0, 'y': 0.0, 'length': plot['length'], 'thickness': wall_thickness},
            {'id': f'exterior_{floor}_east', 'type': 'exterior', 'floor': floor, 'orientation': 'vertical', 'x': plot['width'], 'y': 0.0, 'length': plot['length'], 'thickness': wall_thickness},
        ])
        for room in (item for item in rooms if item.get('floor', 1) == floor):
            prefix = f"room_{room['id']}"
            walls.extend([
                {'id': f'{prefix}_north', 'type': 'interior', 'floor': floor, 'orientation': 'horizontal', 'x': room['x'], 'y': room['y'], 'length': room['width'], 'thickness': wall_thickness, 'room_id': room['id']},
                {'id': f'{prefix}_south', 'type': 'interior', 'floor': floor, 'orientation': 'horizontal', 'x': room['x'], 'y': room['y'] + room['height'], 'length': room['width'], 'thickness': wall_thickness, 'room_id': room['id']},
                {'id': f'{prefix}_west', 'type': 'interior', 'floor': floor, 'orientation': 'vertical', 'x': room['x'], 'y': room['y'], 'length': room['height'], 'thickness': wall_thickness, 'room_id': room['id']},
                {'id': f'{prefix}_east', 'type': 'interior', 'floor': floor, 'orientation': 'vertical', 'x': room['x'] + room['width'], 'y': room['y'], 'length': room['height'], 'thickness': wall_thickness, 'room_id': room['id']},
            ])
    return walls
