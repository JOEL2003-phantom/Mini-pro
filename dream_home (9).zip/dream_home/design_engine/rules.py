"""Configurable conceptual planning defaults for the design engine."""

ROOM_RULES = {
    'living': {'min_width': 10.0, 'min_height': 10.0, 'preferred_area': 156.0, 'target_min': 140.0, 'target_max': 220.0, 'preferred_aspect': 1.35, 'priority': 1.2},
    'dining': {'min_width': 8.0, 'min_height': 8.0, 'preferred_area': 100.0, 'target_min': 90.0, 'target_max': 140.0, 'preferred_aspect': 1.25, 'priority': 1.0},
    'kitchen': {'min_width': 8.0, 'min_height': 8.0, 'preferred_area': 100.0, 'target_min': 90.0, 'target_max': 140.0, 'preferred_aspect': 1.25, 'priority': 1.0},
    'bedroom': {'min_width': 10.0, 'min_height': 10.0, 'preferred_area': 132.0, 'target_min': 110.0, 'target_max': 160.0, 'preferred_aspect': 1.2, 'priority': 1.0},
    # Was 5.0 x 6.0 (30 sq ft) — too tight to fit a WC, basin, and shower without crowding.
    # 5.5 x 7.0 (38.5 sq ft) is closer to a realistic minimum livable bathroom.
    'bathroom': {'min_width': 5.5, 'min_height': 7.0, 'preferred_area': 48.0, 'target_min': 40.0, 'target_max': 70.0, 'preferred_aspect': 0.85, 'priority': .7},
    'parking': {'min_width': 10.0, 'min_height': 18.0, 'preferred_area': 180.0, 'preferred_aspect': 0.55},
    'utility': {'min_width': 6.0, 'min_height': 6.0, 'preferred_area': 42.0, 'target_min': 35.0, 'target_max': 70.0, 'preferred_aspect': 1.0, 'priority': .7},
    'study': {'min_width': 8.0, 'min_height': 8.0, 'preferred_area': 80.0, 'target_min': 60.0, 'target_max': 100.0, 'preferred_aspect': 1.1, 'priority': .8},
    'prayer': {'min_width': 6.0, 'min_height': 6.0, 'preferred_area': 42.0, 'target_min': 36.0, 'target_max': 70.0, 'preferred_aspect': 1.0, 'priority': .7},
    'storage': {'min_width': 6.0, 'min_height': 6.0, 'preferred_area': 36.0, 'target_min': 30.0, 'target_max': 60.0, 'preferred_aspect': 1.0, 'priority': .6},
    'balcony': {'min_width': 6.0, 'min_height': 4.0, 'preferred_area': 24.0, 'target_min': 24.0, 'target_max': 60.0, 'preferred_aspect': 1.5, 'priority': .5},
    'garden': {'min_width': 8.0, 'min_height': 8.0, 'preferred_area': 64.0, 'preferred_aspect': 1.0},
}

ROOM_ZONES = {
    'living': 'public', 'dining': 'public', 'kitchen': 'semi_private',
    'bathroom': 'semi_private', 'utility': 'service', 'bedroom': 'private',
    'study': 'private', 'prayer': 'private', 'storage': 'service',
    'balcony': 'private',
}

ADJACENCY_RULES = {
    'living': {'dining': 10, 'kitchen': 4},
    'dining': {'living': 10, 'kitchen': 10},
    'kitchen': {'dining': 10, 'utility': 6},
    'bedroom': {'bathroom': 6},
    'bathroom': {'bedroom': 6},
    'parking': {'living': 4},
    'utility': {'kitchen': 6},
}

SCORE_WEIGHTS = {
    'requirement_satisfaction': 0.16,
    'adjacency': 0.14,
    'space_efficiency': 0.10,
    'circulation': 0.14,
    'proportion': 0.08,
    'privacy': 0.10,
    'open_space': 0.05,
    'parking': 0.05,
    'preference_match': 0.04,
    'bathroom_relationship': 0.06,
    'natural_light': 0.04,
    'architectural_coherence': 0.04,
    'furniture_fit': 0.03,
    'door_usability': 0.03,
    'floor_connectivity': 0.03,
    'room_size_balance': 0.08,
    'entrance_quality': 0.05,
    'staircase_quality': 0.04,
}
