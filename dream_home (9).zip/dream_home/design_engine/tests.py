from django.test import SimpleTestCase

from .analyzer import RequirementError, analyze_requirements
from .constraints import rectangles_overlap, validate_layout
from .circulation import plan_circulation, validate_circulation
from .diversity import layout_distance, select_diverse_layouts, structural_signature
from .editing import evaluate_layout, normalize_layout_for_editor
from .rules import ROOM_RULES
from .scorer import adjacency_score, calculate_metrics
from .services import generate_design, resolve_feasibility_decision


def sample_requirements():
	return {
		'plot': {'width': 30, 'length': 50, 'unit': 'ft'},
		'rooms': {'bedrooms': 3, 'bathrooms': 2, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
		'parking': 1,
		'floors': 2,
		'features': {'garden_open_space': True, 'storage_room': True, 'utility_room': True},
		'style': 'modern',
		'budget': 3000000,
		'additional_requirements': 'More natural light',
	}


def feasible_30x50_requirements():
	return {
		'plot': {'width': 30, 'length': 50, 'unit': 'ft'},
		'rooms': {'bedrooms': 2, 'bathrooms': 2, 'kitchen': 1, 'living_room': 1, 'dining_room': 0},
		'parking': 0, 'floors': 1, 'features': {}, 'style': 'modern',
	}


class RequirementAnalysisTests(SimpleTestCase):
	def test_phase_four_preferences_normalize_to_room_instances(self):
		spec = analyze_requirements(sample_requirements())

		self.assertEqual(spec.plot, {'width': 30.0, 'length': 50.0, 'unit': 'ft'})
		self.assertEqual(spec.room_counts['bedroom'], 3)
		self.assertEqual(spec.room_counts['utility'], 1)
		self.assertEqual([room.id for room in spec.rooms].count('bedroom_1'), 1)

	def test_invalid_requirements_return_clear_error(self):
		with self.assertRaises(RequirementError):
			analyze_requirements({'plot': {'width': 0, 'length': 50, 'unit': 'ft'}, 'rooms': {}})


class GeometryAndConstraintTests(SimpleTestCase):
	def test_circulation_builds_a_reachable_spine(self):
		rooms = [
			{'id': 'living_1', 'type': 'living', 'zone': 'public', 'floor': 1, 'x': 0, 'y': 0, 'width': 12, 'height': 10},
			{'id': 'dining_1', 'type': 'dining', 'zone': 'public', 'floor': 1, 'x': 12, 'y': 0, 'width': 8, 'height': 10},
			{'id': 'bedroom_1', 'type': 'bedroom', 'zone': 'private', 'floor': 1, 'x': 12, 'y': 10, 'width': 10, 'height': 10},
		]
		circulation = plan_circulation(rooms)
		self.assertEqual(circulation['entry_room'], 'living_1')
		self.assertFalse(validate_circulation(circulation, rooms))

	def test_room_rules_are_positive(self):
		for rule in ROOM_RULES.values():
			self.assertGreater(rule['min_width'], 0)
			self.assertGreater(rule['min_height'], 0)

	def test_touching_rectangles_are_not_overlapping(self):
		first = {'x': 0, 'y': 0, 'width': 10, 'height': 10}
		second = {'x': 10, 'y': 0, 'width': 10, 'height': 10}
		self.assertFalse(rectangles_overlap(first, second))

	def test_overlapping_rectangles_are_detected(self):
		first = {'x': 0, 'y': 0, 'width': 10, 'height': 10}
		second = {'x': 9, 'y': 0, 'width': 10, 'height': 10}
		self.assertTrue(rectangles_overlap(first, second))

	def test_invalid_geometry_and_duplicate_ids_are_rejected(self):
		spec = analyze_requirements(sample_requirements())
		layout = {'rooms': [
			{'id': 'same', 'type': 'bedroom', 'x': 0, 'y': 0, 'width': 10, 'height': 10, 'area': 100},
			{'id': 'same', 'type': 'bedroom', 'x': 0, 'y': 0, 'width': 10, 'height': 10, 'area': 100},
		], 'parking': [], 'open_spaces': []}
		result = validate_layout(layout, spec)
		self.assertFalse(result['valid'])
		self.assertTrue(any('unique' in error for error in result['errors']))


class GenerationTests(SimpleTestCase):
	def test_feasible_30x50_layout_has_architectural_relationships(self):
		result = generate_design(feasible_30x50_requirements())

		self.assertTrue(result['success'])
		layout = result['recommended_layout']
		self.assertGreaterEqual(len(result['plans']), 3)
		self.assertTrue(layout['circulation']['corridors'])
		attached = next(room for room in layout['rooms'] if room.get('bathroom_kind') == 'attached')
		target = next(room for room in layout['rooms'] if room['id'] == attached['attached_to'])
		self.assertTrue(
			abs(attached['x'] + attached['width'] - target['x']) < 0.01
			or abs(target['x'] + target['width'] - attached['x']) < 0.01
			or abs(attached['y'] + attached['height'] - target['y']) < 0.01
			or abs(target['y'] + target['height'] - attached['y']) < 0.01
		)
		self.assertTrue(any(room.get('bathroom_kind') == 'common' for room in layout['rooms']))
		self.assertTrue(all('swing_arc' in door for door in layout['doors']))
		self.assertTrue(all(
			any(
				window['room_id'] == room['id'] and (
					(window['orientation'] == 'horizontal' and window['y'] in (room['y'], room['y'] + room['height']))
					or (window['orientation'] == 'vertical' and window['x'] in (room['x'], room['x'] + room['width']))
				)
				for room in layout['rooms']
			)
			for window in layout['windows']
		))
		self.assertTrue(all(item['room_id'] in {room['id'] for room in layout['rooms']} for item in layout['furniture']))

	def test_feasible_plans_are_structurally_different(self):
		result = generate_design(feasible_30x50_requirements())
		signatures = {
			tuple((room['id'], room['x'], room['y'], room['floor']) for room in plan['rooms'])
			for plan in result['plans']
		}
		self.assertGreaterEqual(len(signatures), 3)

	def test_feasible_generation_selects_six_distinct_valid_strategies(self):
		result = generate_design(feasible_30x50_requirements())

		self.assertTrue(result['success'])
		self.assertEqual(len(result['plans']), 6)
		self.assertEqual(len({plan['candidate_id'] for plan in result['plans']}), 6)
		self.assertEqual(len({plan['strategy'] for plan in result['plans']}), 6)
		self.assertEqual(len({structural_signature(plan) for plan in result['plans']}), 6)
		self.assertTrue(all(plan['validation']['valid'] for plan in result['plans']))
		self.assertTrue(all(layout_distance(first, second) >= 0.15 for index, first in enumerate(result['plans']) for second in result['plans'][index + 1:]))

	def test_diversity_selector_rejects_near_duplicate_candidates(self):
		result = generate_design(feasible_30x50_requirements())
		original = result['plans'][0]
		duplicate = {**original, 'candidate_id': 'duplicate_candidate'}

		selected = select_diverse_layouts([original, duplicate], limit=6)

		self.assertEqual(selected, [original])
		self.assertEqual(layout_distance(original, duplicate), 0.0)

	def test_generated_layout_contains_structured_architectural_elements(self):
		requirements = {
			'plot': {'width': 40, 'length': 80, 'unit': 'ft'},
			'rooms': {'bedrooms': 3, 'bathrooms': 2, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
			'parking': 1, 'floors': 1, 'features': {'balcony': True, 'garden_open_space': True}, 'style': 'modern',
		}
		result = generate_design(requirements)

		self.assertTrue(result['success'])
		layout = result['recommended_layout']
		for key in ('walls', 'doors', 'windows', 'furniture', 'dimensions', 'stairs'):
			self.assertIn(key, layout)
		self.assertTrue(layout['walls'])
		self.assertTrue(layout['doors'])
		self.assertTrue(layout['windows'])
		self.assertTrue(layout['furniture'])
		self.assertTrue(layout['dimensions'])
		self.assertIn('circulation', layout)
		self.assertTrue(layout['circulation']['entry_room'])
		self.assertTrue(layout['validation']['valid'])
		self.assertTrue(all(item['room_id'] in {room['id'] for room in layout['rooms']} for item in layout['furniture']))

	def test_multi_floor_layout_has_floor_scoped_stairs(self):
		requirements = {
			'plot': {'width': 40, 'length': 80, 'unit': 'ft'},
			'rooms': {'bedrooms': 4, 'bathrooms': 2, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
			'parking': 1, 'floors': 2, 'features': {}, 'style': 'modern',
		}
		result = generate_design(requirements)

		self.assertTrue(result['success'])
		layout = result['recommended_layout']
		self.assertEqual({room['floor'] for room in layout['rooms']}, {1, 2})
		self.assertTrue(layout['stairs'])
		self.assertTrue(all(stair['floor'] == 1 for stair in layout['stairs']))
		self.assertTrue(layout['validation']['valid'])

	def test_multi_floor_layout_has_aligned_upper_floor_stair_arrivals(self):
		result = generate_design({
			'plot': {'width': 40, 'length': 80, 'unit': 'ft'},
			'rooms': {'bedrooms': 3, 'bathrooms': 2, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
			'parking': 1, 'floors': 2, 'features': {}, 'style': 'modern',
		})

		self.assertTrue(result['success'])
		layout = result['recommended_layout']
		self.assertEqual({arrival['floor'] for arrival in layout['stair_arrivals']}, {2})
		base = layout['stairs'][0]
		arrival = layout['stair_arrivals'][0]
		self.assertEqual((arrival['x'], arrival['y']), (base['x'], base['y']))
		self.assertTrue(arrival['arrival'])

	def test_edited_layout_recalculates_circulation_for_moved_rooms(self):
		requirements = feasible_30x50_requirements()
		generated = generate_design(requirements)
		self.assertTrue(generated['success'])
		layout = generated['recommended_layout']
		layout['rooms'][0]['x'] += 0.5
		result = evaluate_layout(requirements, layout)
		self.assertIn('corridors', layout['circulation'])
		self.assertIn('reachable_rooms', layout['circulation'])
		self.assertIsInstance(result['valid'], bool)

	def test_normalize_layout_for_editor_rebuilds_wall_objects_from_room_geometry(self):
		layout = {
			'plot': {'width': 20, 'length': 30, 'unit': 'ft'},
			'rooms': [
				{'id': 'room_a', 'name': 'Bedroom 1', 'type': 'bedroom', 'x': 0, 'y': 0, 'width': 10, 'height': 12, 'area': 120},
				{'id': 'room_b', 'name': 'Bedroom 2', 'type': 'bedroom', 'x': 10, 'y': 0, 'width': 10, 'height': 12, 'area': 120},
			],
		}

		normalized = normalize_layout_for_editor(layout)

		self.assertIn('walls', normalized)
		self.assertTrue(normalized['walls'])
		self.assertTrue(any(wall['x'] == 10 and wall['orientation'] == 'vertical' for wall in normalized['walls']))
		self.assertTrue(any(wall['type'] == 'exterior' for wall in normalized['walls']))

	def test_public_zone_reads_as_front_of_house_before_private_zone(self):
		requirements = {
			'plot': {'width': 30, 'length': 50, 'unit': 'ft'},
			'rooms': {'bedrooms': 4, 'bathrooms': 3, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
			'parking': 2, 'floors': 2, 'features': {'garden_open_space': True, 'storage_room': True, 'utility_room': True}, 'style': 'modern',
		}
		result = generate_design(requirements, seed=0)

		self.assertTrue(result['success'])
		layout = result['recommended_layout']
		entry_id = layout['circulation']['entry_room']
		entry = next(room for room in layout['rooms'] if room['id'] == entry_id)
		self.assertEqual(entry['type'], 'living')
		for floor in sorted({room.get('floor', 1) for room in layout['rooms']}):
			public_rooms = [room for room in layout['rooms'] if room.get('floor') == floor and room.get('zone') == 'public']
			private_rooms = [room for room in layout['rooms'] if room.get('floor') == floor and room.get('zone') == 'private']
			if public_rooms and private_rooms:
				self.assertLess(max(room['y'] for room in public_rooms), min(room['y'] for room in private_rooms))

	def test_feasible_result_exposes_all_valid_plans(self):
		result = generate_design({
			'plot': {'width': 40, 'length': 80, 'unit': 'ft'},
			'rooms': {'bedrooms': 3, 'bathrooms': 2, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
			'parking': 1,
			'floors': 1,
			'features': {},
			'style': 'modern',
		})

		self.assertTrue(result['success'])
		self.assertEqual(result['feasibility']['status'], 'feasible')
		self.assertEqual(result['plans'], [result['recommended_layout'], *result['alternatives']])

	def test_infeasible_result_requires_a_user_decision(self):
		result = generate_design({
			'plot': {'width': 8, 'length': 8, 'unit': 'ft'},
			'rooms': {'bedrooms': 4, 'bathrooms': 3, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
			'parking': 2,
			'floors': 1,
			'features': {},
			'style': 'modern',
		})

		self.assertFalse(result['success'])
		self.assertTrue(result['feasibility']['requires_user_decision'])
		self.assertEqual({option['id'] for option in result['feasibility']['options']}, {
			'adjust_requirements', 'add_floor', 'change_plot',
		})

	def test_add_floor_preserves_complete_program_until_user_chooses_it(self):
		requirements = {
			'plot': {'width': 30, 'length': 40, 'unit': 'ft'},
			'rooms': {'bedrooms': 4, 'bathrooms': 3, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
			'parking': 2,
			'floors': 1,
			'features': {},
			'style': 'modern',
		}
		result = resolve_feasibility_decision(requirements, 'add_floor')

		self.assertEqual(result['requirements']['floors'], 2)
		self.assertEqual(result['requirements']['rooms'], requirements['rooms'])
		self.assertEqual(sum(room['type'] == 'bedroom' for room in result['recommended_layout']['rooms']), 4)
		self.assertEqual({room['floor'] for room in result['recommended_layout']['rooms']}, {1, 2})
	def test_nearby_preferred_rooms_score_better_than_distant_rooms(self):
		nearby = {
			'rooms': [
				{'id': 'living_1', 'type': 'living', 'x': 0, 'y': 0, 'width': 10, 'height': 10},
				{'id': 'dining_1', 'type': 'dining', 'x': 10, 'y': 0, 'width': 8, 'height': 8},
			]
		}
		distant = {
			'rooms': [
				{'id': 'living_1', 'type': 'living', 'x': 0, 'y': 0, 'width': 10, 'height': 10},
				{'id': 'dining_1', 'type': 'dining', 'x': 25, 'y': 25, 'width': 8, 'height': 8},
			]
		}

		self.assertGreater(adjacency_score(nearby)[0], adjacency_score(distant)[0])

	def test_sample_generates_valid_structured_candidates(self):
		result = generate_design(sample_requirements(), seed=0)

		self.assertTrue(result['success'])
		self.assertEqual(len(result['candidates']), 6)
		self.assertIsNotNone(result['recommended_layout'])
		for candidate in result['candidates']:
			self.assertTrue(candidate['validation']['valid'])
			self.assertGreaterEqual(candidate['score']['total'], 0)
			self.assertLessEqual(candidate['score']['total'], 100)
			ids = [room['id'] for room in candidate['rooms']]
			self.assertEqual(len(ids), len(set(ids)))
			for room in candidate['rooms']:
				self.assertAlmostEqual(room['area'], room['width'] * room['height'])
				self.assertLessEqual(room['x'] + room['width'], 30)
				self.assertLessEqual(room['y'] + room['height'], 50)
			self.assertAlmostEqual(candidate['score']['total'], sum(candidate['score']['breakdown'].values()),)

	def test_realistic_two_floor_program_is_balanced_and_accessible(self):
		requirements = {
			'plot': {'width': 30, 'length': 50, 'unit': 'ft'},
			'rooms': {'bedrooms': 4, 'bathrooms': 3, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
			'parking': 2, 'floors': 2,
			'features': {'garden_open_space': True, 'balcony': True}, 'style': 'modern',
		}
		result = generate_design(requirements)

		self.assertTrue(result['success'])
		layout = result['recommended_layout']
		self.assertEqual(len(result['plans']), 6)
		self.assertTrue(layout['validation']['valid'])
		self.assertEqual({room['floor'] for room in layout['rooms']}, {1, 2})
		self.assertTrue(layout['entrances'])
		self.assertEqual(layout['entrances'][0]['connects_to'], 'living_1')
		self.assertGreaterEqual(len(layout['circulation']['corridors']), 2)
		self.assertTrue(layout['stairs'])
		self.assertLess(max(room['area'] for room in layout['rooms'] if room['type'] == 'bedroom'), 220)
		self.assertGreaterEqual(next(room['area'] for room in layout['rooms'] if room['type'] == 'living'), 140)
		self.assertGreaterEqual(next(room['area'] for room in layout['rooms'] if room['type'] == 'dining'), 90)
	def test_candidates_are_deterministic_and_vary(self):
		first = generate_design(sample_requirements(), seed=7)
		second = generate_design(sample_requirements(), seed=7)

		self.assertEqual(first, second)
		signatures = [tuple(room['id'] for room in candidate['rooms']) for candidate in first['candidates']]
		self.assertGreater(len(set(signatures)), 1)

	def test_impossible_plot_returns_structured_failure(self):
		requirements = sample_requirements()
		requirements['plot'] = {'width': 8, 'length': 8, 'unit': 'ft'}

		result = generate_design(requirements)

		self.assertFalse(result['success'])
		self.assertTrue(result['errors'])

	def test_invalid_candidates_cannot_be_recommended(self):
		requirements = sample_requirements()
		requirements['parking'] = 4

		result = generate_design(requirements)

		self.assertFalse(result['success'])
		self.assertNotIn('recommended_layout', result)

	def test_candidates_use_zones_and_have_meaningful_strategy_metadata(self):
		result = generate_design(sample_requirements())

		self.assertEqual(len(result['candidates']), 6)
		self.assertGreater(len({candidate['strategy'] for candidate in result['candidates']}), 3)
		zones = {room['zone'] for room in result['recommended_layout']['rooms']}
		self.assertIn('public', zones)
		self.assertIn('private', zones)

	def test_candidate_count_is_bounded_and_deterministic(self):
		first = generate_design(sample_requirements(), candidate_count=10, seed=4)
		second = generate_design(sample_requirements(), candidate_count=10, seed=4)

		self.assertEqual(len(first['candidates']), 6)
		self.assertEqual(first, second)

	def test_parking_and_no_parking_are_respected(self):
		with_parking = generate_design(sample_requirements())
		without_parking = sample_requirements()
		without_parking['parking'] = 0
		without_parking_result = generate_design(without_parking)

		self.assertTrue(with_parking['success'])
		self.assertTrue(without_parking_result['success'])
		self.assertEqual(len(with_parking['recommended_layout']['parking']), 1)
		self.assertEqual(without_parking_result['recommended_layout']['parking'], [])

	def test_score_contains_advanced_explainable_components(self):
		result = generate_design(sample_requirements())
		breakdown = result['recommended_layout']['score']['breakdown']

		for component in ('proportion', 'privacy', 'open_space', 'parking', 'preference_match'):
			self.assertIn(component, breakdown)
		self.assertAlmostEqual(result['recommended_layout']['score']['total'], sum(breakdown.values()))

	def test_narrow_room_receives_proportion_penalty(self):
		spec = analyze_requirements(sample_requirements())
		balanced = {'rooms': [{'id': 'bedroom_1', 'type': 'bedroom', 'x': 0, 'y': 0, 'width': 10, 'height': 12, 'area': 120}], 'parking': [], 'open_spaces': [], 'adjacency': {}}
		narrow = {'rooms': [{'id': 'bedroom_1', 'type': 'bedroom', 'x': 0, 'y': 0, 'width': 4, 'height': 30, 'area': 120}], 'parking': [], 'open_spaces': [], 'adjacency': {}}

		self.assertGreater(calculate_metrics(balanced, spec)['proportion'], calculate_metrics(narrow, spec)['proportion'])

	def test_floor_identifier_is_validated(self):
		spec = analyze_requirements(sample_requirements())
		layout = {'rooms': [{'id': 'room-1', 'type': 'bedroom', 'floor': 2, 'x': 0, 'y': 0, 'width': 10, 'height': 10, 'area': 100}], 'parking': [], 'open_spaces': []}

		result = validate_layout(layout, spec)

		self.assertFalse(result['valid'])
		self.assertTrue(any('floor' in error for error in result['errors']))

	def test_generated_layout_contains_connected_architectural_elements(self):
		result = generate_design(sample_requirements())
		layout = result['recommended_layout']

		self.assertTrue(result['success'])
		self.assertTrue(layout['entrances'])
		self.assertTrue(layout['doors'])
		self.assertTrue(layout['connectivity'])
		self.assertTrue(all(door['connects_to'] in {room['id'] for room in layout['rooms']} for door in layout['doors']))

	def test_generated_windows_reference_real_rooms(self):
		result = generate_design(sample_requirements())
		room_ids = {room['id'] for room in result['recommended_layout']['rooms']}

		self.assertTrue(all(window['room_id'] in room_ids for window in result['recommended_layout']['windows']))
