import json
from urllib.error import HTTPError
from unittest.mock import Mock, patch

from django.test import SimpleTestCase, override_settings

from design_engine.services import generate_design

from .parser import OllamaParser, OllamaUnavailableError, ParserError, parse_ollama_response
from .service import natural_language_to_design


def valid_payload():
    return {
        'plot': {'width': 40, 'length': 80, 'unit': 'ft'},
        'rooms': {'bedrooms': 3, 'bathrooms': 2, 'kitchen': 1, 'living_room': 1, 'dining_room': 1},
        'parking': 1,
        'floors': 1,
        'features': {'balcony': True, 'garden_open_space': True, 'storage_room': True, 'utility_room': True},
        'style': 'modern',
    }


class SchemaAndParserTests(SimpleTestCase):
    def test_valid_json_is_normalized(self):
        result = parse_ollama_response(json.dumps(valid_payload()))
        self.assertEqual(result['rooms']['bedrooms'], 3)
        self.assertTrue(result['features']['balcony'])
        self.assertFalse(result['features']['prayer_room'])

    def test_flat_json_is_supported_at_the_boundary(self):
        result = parse_ollama_response(json.dumps({
            'plot_width': 30, 'plot_length': 50, 'unit': 'ft', 'bedrooms': 4,
            'bathrooms': 3, 'kitchen': 1, 'living_room': 1, 'dining_room': 1,
        }))
        self.assertEqual(result['plot']['width'], 30.0)

    def test_malformed_response_is_rejected(self):
        with self.assertRaises(ParserError):
            parse_ollama_response('not json')

    def test_surrounding_whitespace_is_accepted(self):
        result = parse_ollama_response(f'\n  {json.dumps(valid_payload())}  \n')
        self.assertEqual(result['plot']['width'], 40.0)

    def test_explanatory_text_around_json_is_extracted(self):
        result = parse_ollama_response(f'Here is the result: {json.dumps(valid_payload())} Thanks!')
        self.assertEqual(result['rooms']['bedrooms'], 3)

    def test_missing_required_field_is_rejected(self):
        payload = valid_payload()
        del payload['plot']['width']
        with self.assertRaisesRegex(ParserError, 'width is required'):
            parse_ollama_response(json.dumps(payload))

    def test_invalid_counts_are_rejected(self):
        payload = valid_payload()
        payload['rooms']['bedrooms'] = -1
        with self.assertRaises(ParserError):
            parse_ollama_response(json.dumps(payload))

    def test_invalid_feature_type_is_rejected(self):
        payload = valid_payload()
        payload['features']['balcony'] = 'false'
        with self.assertRaisesRegex(ParserError, 'must be boolean'):
            parse_ollama_response(json.dumps(payload))

    def test_exact_natural_language_example_shape(self):
        result = parse_ollama_response(json.dumps({
            'plot': {'width': 30, 'length': 50, 'unit': 'ft'},
            'rooms': {'bedrooms': 4, 'bathrooms': 3},
            'parking': 2,
            'features': {'balcony': True, 'garden_open_space': True},
            'style': 'modern',
        }))
        self.assertEqual(result['rooms']['bedrooms'], 4)
        self.assertEqual(result['parking'], 2)
        self.assertTrue(result['features']['garden_open_space'])

    def test_unsupported_style_is_rejected(self):
        payload = valid_payload()
        payload['style'] = 'futuristic'
        with self.assertRaisesRegex(ParserError, 'unsupported style'):
            parse_ollama_response(json.dumps(payload))


class OllamaAndIntegrationTests(SimpleTestCase):
    def test_default_ollama_base_url_uses_localhost_ip(self):
        self.assertEqual(OllamaParser().base_url, 'http://127.0.0.1:11434')

    @override_settings(OLLAMA_BASE_URL='http://ollama.test', OLLAMA_MODEL='qwen3:4b')
    def test_ollama_response_is_sent_and_parsed(self):
        response = Mock()
        response.read.return_value = json.dumps({'response': json.dumps(valid_payload())}).encode()
        response.__enter__ = Mock(return_value=response)
        response.__exit__ = Mock(return_value=False)
        opener = Mock(return_value=response)

        result = OllamaParser(opener=opener).parse('4 bedrooms on a 30 by 50 ft plot')

        self.assertEqual(result['rooms']['bedrooms'], 3)
        request = opener.call_args.args[0]
        self.assertIn(b'qwen3:4b', request.data)
        request_payload = json.loads(request.data)
        self.assertFalse(request_payload['think'])
        self.assertEqual(request_payload['format'], 'json')

    @override_settings(OLLAMA_BASE_URL='http://ollama.test', OLLAMA_MODEL='qwen3:4b')
    def test_ollama_request_is_short_and_structured_for_requirement_understanding(self):
        tags_response = Mock()
        tags_response.read.return_value = json.dumps({'models': [{'name': 'qwen3:4b'}]}).encode()
        tags_response.__enter__ = Mock(return_value=tags_response)
        tags_response.__exit__ = Mock(return_value=False)

        generate_response = Mock()
        generate_response.read.return_value = json.dumps({'response': json.dumps(valid_payload())}).encode()
        generate_response.__enter__ = Mock(return_value=generate_response)
        generate_response.__exit__ = Mock(return_value=False)

        opener = Mock(side_effect=[tags_response, generate_response])

        OllamaParser(opener=opener).parse('i need a 2 bedroom house with a living room 1 bath room 1 kitchen 1 stair and a garden in front')

        request = opener.call_args_list[1].args[0]
        payload = json.loads(request.data)
        self.assertIn('Return only one valid JSON object', payload['prompt'])
        self.assertLessEqual(payload['options']['num_predict'], 192)
        self.assertEqual(payload['options']['temperature'], 0)

    @override_settings(OLLAMA_BASE_URL='http://ollama.test', OLLAMA_MODEL='qwen3:4b')
    def test_ollama_checks_model_availability_before_generate(self):
        tags_response = Mock()
        tags_response.read.return_value = json.dumps({'models': [{'name': 'qwen3:4b'}]}).encode()
        tags_response.__enter__ = Mock(return_value=tags_response)
        tags_response.__exit__ = Mock(return_value=False)

        generate_response = Mock()
        generate_response.read.return_value = json.dumps({'response': json.dumps(valid_payload())}).encode()
        generate_response.__enter__ = Mock(return_value=generate_response)
        generate_response.__exit__ = Mock(return_value=False)

        opener = Mock(side_effect=[tags_response, generate_response])

        result = OllamaParser(opener=opener).parse('4 bedrooms on a 30 by 50 ft plot')

        self.assertEqual(result['rooms']['bedrooms'], 3)
        self.assertEqual(opener.call_count, 2)
        self.assertEqual(opener.call_args_list[0].args[0].full_url, 'http://ollama.test/api/tags')
        self.assertEqual(opener.call_args_list[1].args[0].full_url, 'http://ollama.test/api/generate')

    def test_ollama_api_error_is_application_level_error(self):
        error = HTTPError(
            'http://ollama.test/api/generate', 500, 'failure', {},
            Mock(read=Mock(return_value=b'{"error":"model failed"}')),
        )
        with self.assertRaisesRegex(ParserError, 'model failed'):
            OllamaParser(opener=Mock(side_effect=error)).parse('three bedrooms')

    def test_invalid_json_from_ollama_is_application_level_error(self):
        response = Mock()
        response.read.return_value = json.dumps({'response': 'not json'}).encode()
        response.__enter__ = Mock(return_value=response)
        response.__exit__ = Mock(return_value=False)
        with self.assertRaises(ParserError):
            OllamaParser(opener=Mock(return_value=response)).parse('three bedrooms')

    @override_settings(OPENAI_API_KEY='test-key', OPENAI_ARCHITECTURE_REVIEW=False)
    @patch('ai_engine.service.OpenAIArchitectureClient')
    def test_openai_architectural_intent_drives_existing_engine(self, client_class):
        intent = {
            'requirements': valid_payload(),
            'room_priorities': {'living': 'high'},
            'zoning': {'public': ['living'], 'private': ['bedrooms']},
            'adjacency_preferences': [{'from': 'living', 'to': 'dining'}],
            'privacy_requirements': ['bedrooms away from entry'],
            'circulation_strategy': 'side_corridor',
            'bathroom_relationships': [],
            'staircase_requirements': {},
            'natural_light_requirements': ['bedrooms need exterior windows'],
            'outdoor_space_relationships': [],
            'style_intent': 'modern',
        }
        client_class.return_value.plan.return_value = intent

        result = natural_language_to_design('A structured brief', candidate_count=1)

        self.assertTrue(result['success'])
        self.assertEqual(result['architectural_intent']['circulation_strategy'], 'side_corridor')
        self.assertEqual(result['recommended_layout']['architectural_intent'], intent)
        client_class.return_value.plan.assert_called_once_with('A structured brief')

    @patch('ai_engine.parser.urlopen', side_effect=OSError)
    def test_ollama_failure_is_application_level_error(self, _urlopen):
        with self.assertRaises(OllamaUnavailableError):
            OllamaParser().parse('three bedrooms')

    @patch('ai_engine.service.parse_house_requirements', return_value=valid_payload())
    def test_integration_delegates_to_existing_engine_and_returns_multiple_plans(self, _parser):
        _parser.return_value['features'] = {}
        result = natural_language_to_design('ignored')

        self.assertTrue(result['success'])
        self.assertGreater(len(result['plans']), 1)
        self.assertEqual(len(result['candidates']), 6)
        self.assertTrue(all(plan in result['candidates'] for plan in result['plans']))
        self.assertEqual(result['recommended_layout'], result['plans'][0])
        self.assertTrue(all(plan['validation']['valid'] for plan in result['plans']))
        self.assertTrue(generate_design(_parser.return_value)['success'])