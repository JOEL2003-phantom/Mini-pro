"""Shared evaluation for user-edited structured layouts."""

from copy import deepcopy
from typing import Any

from .analyzer import RequirementError, analyze_requirements
from .constraints import validate_layout
from .circulation import plan_circulation
from .scorer import adjacency_score, score_layout
from .walls import generate_walls


def normalize_layout_for_editor(layout: dict[str, Any] | None) -> dict[str, Any]:
    """Restore the canonical editable model for legacy or partially generated layouts."""
    if not isinstance(layout, dict):
        return {} if layout is None else dict(layout)
    normalized = deepcopy(layout)
    plot = normalized.setdefault('plot', {})
    plot.setdefault('id', 'plot')
    plot.setdefault('x', 0.0)
    plot.setdefault('y', 0.0)
    plot.setdefault('width', 0.0)
    plot.setdefault('length', 0.0)
    plot.setdefault('unit', 'ft')

    rooms = normalized.setdefault('rooms', [])
    if not isinstance(rooms, list):
        rooms = []
        normalized['rooms'] = rooms

    for room in rooms:
        room.setdefault('floor', 1)
        room.setdefault('area', round(room.get('width', 0) * room.get('height', 0), 2))
        room['area'] = round(room['width'] * room['height'], 2)

    walls = normalized.get('walls')
    if not isinstance(walls, list) or not walls:
        walls = generate_walls(rooms, plot)
        normalized['walls'] = walls
    else:
        normalized['walls'] = walls

    for room in rooms:
        room['wall_ids'] = [
            wall['id'] for wall in normalized['walls']
            if wall.get('floor', 1) == room.get('floor', 1)
            and (
                room['id'] in wall.get('rooms', [])
                or wall.get('room_id') == room['id']
            )
        ]

    normalized.setdefault('doors', [])
    normalized.setdefault('windows', [])
    normalized.setdefault('furniture', [])
    normalized.setdefault('dimensions', [])
    normalized.setdefault('stairs', [])
    normalized.setdefault('stair_arrivals', [])
    normalized.setdefault('parking', [])
    normalized.setdefault('open_spaces', [])
    normalized.setdefault('annotations', [])
    normalized.setdefault('circulation', plan_circulation(rooms, plot.get('width', 0) if rooms else 0))
    if 'circulation' in normalized and not isinstance(normalized['circulation'], dict):
        normalized['circulation'] = {'corridors': []}
    return normalized


def evaluate_layout(requirements: dict[str, Any], layout: dict[str, Any]) -> dict[str, Any]:
    """Validate and score an edited layout using the existing engine rules."""
    layout = normalize_layout_for_editor(layout)
    try:
        spec = analyze_requirements(requirements)
    except RequirementError as error:
        return {'valid': False, 'errors': [str(error)], 'warnings': [], 'score': None}
    _, adjacency = adjacency_score(layout)
    layout['adjacency'] = adjacency
    if layout.pop('_recalculate_circulation', False) or not layout.get('circulation'):
        layout['circulation'] = plan_circulation(layout['rooms'], layout['plot']['width'])
    validation = validate_layout(layout, spec)
    score = None
    if validation['valid']:
        total, breakdown = score_layout(layout, spec)
        score = {'total': total, 'breakdown': breakdown}
    return {**validation, 'score': score}
