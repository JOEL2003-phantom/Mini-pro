"""Structured architectural intent exchanged with the OpenAI planning layer."""

from typing import Any, TypedDict

from .schema import HouseRequirements, SchemaError, normalize_requirements


class ArchitecturalIntent(TypedDict):
    requirements: HouseRequirements
    room_priorities: dict[str, str]
    zoning: dict[str, list[str]]
    adjacency_preferences: list[dict[str, Any]]
    privacy_requirements: list[str]
    circulation_strategy: str
    bathroom_relationships: list[dict[str, Any]]
    staircase_requirements: dict[str, Any]
    natural_light_requirements: list[str]
    outdoor_space_relationships: list[str]
    style_intent: str


class IntentError(ValueError):
    """Raised when an OpenAI architectural intent is not structured safely."""


def normalize_intent(raw: Any) -> ArchitecturalIntent:
    if not isinstance(raw, dict):
        raise IntentError('Architectural planner output must be a JSON object.')
    try:
        requirements = normalize_requirements(raw.get('requirements', raw))
    except SchemaError as error:
        raise IntentError(str(error)) from error

    zoning = raw.get('zoning', {})
    if not isinstance(zoning, dict):
        raise IntentError('architectural zoning must be an object')
    priorities = raw.get('room_priorities', {})
    if not isinstance(priorities, dict):
        raise IntentError('room_priorities must be an object')
    adjacency = raw.get('adjacency_preferences', [])
    bathroom_relationships = raw.get('bathroom_relationships', [])
    if not isinstance(adjacency, list) or not isinstance(bathroom_relationships, list):
        raise IntentError('architectural relationships must be arrays')

    return {
        'requirements': requirements,
        'room_priorities': {str(key): str(value) for key, value in priorities.items()},
        'zoning': {
            str(zone): [str(room) for room in rooms]
            for zone, rooms in zoning.items()
            if isinstance(rooms, list)
        },
        'adjacency_preferences': adjacency,
        'privacy_requirements': [str(item) for item in raw.get('privacy_requirements', [])],
        'circulation_strategy': str(raw.get('circulation_strategy', 'central_corridor')),
        'bathroom_relationships': bathroom_relationships,
        'staircase_requirements': raw.get('staircase_requirements', {}),
        'natural_light_requirements': [str(item) for item in raw.get('natural_light_requirements', [])],
        'outdoor_space_relationships': [str(item) for item in raw.get('outdoor_space_relationships', [])],
        'style_intent': str(raw.get('style_intent', requirements['style'])),
    }
