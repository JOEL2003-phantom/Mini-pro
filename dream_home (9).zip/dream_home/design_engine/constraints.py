"""Hard geometric validation for generated layouts."""

from typing import Any

from .bathroom_planner import validate_bathroom_relationships
from .analyzer import PlanningSpec
from .circulation import validate_circulation
from .rules import ROOM_RULES


def rectangles_overlap(first: dict[str, Any], second: dict[str, Any]) -> bool:
    return (
        first['x'] < second['x'] + second['width']
        and first['x'] + first['width'] > second['x']
        and first['y'] < second['y'] + second['height']
        and first['y'] + first['height'] > second['y']
    )


def _geometry_errors(item: dict[str, Any], plot_width: float, plot_length: float, label: str) -> list[str]:
    errors = []
    fields = ('x', 'y', 'width', 'height', 'area')
    if any(field not in item for field in fields):
        return [f'{label} is missing geometry fields']
    if item['x'] < 0 or item['y'] < 0:
        errors.append(f'{label} has negative coordinates')
    if item['width'] <= 0 or item['height'] <= 0 or item['area'] <= 0:
        errors.append(f'{label} has non-positive geometry')
    if abs(item['area'] - item['width'] * item['height']) > 0.01:
        errors.append(f'{label} area is inconsistent')
    if item['x'] + item['width'] > plot_width or item['y'] + item['height'] > plot_length:
        errors.append(f'{label} is outside the plot')
    return errors


def _room_boundary_contains(room: dict[str, Any], element: dict[str, Any]) -> bool:
    tolerance = 0.01
    x, y = element.get('x'), element.get('y')
    width = element.get('width', 0)
    orientation = element.get('orientation')
    if x is None or y is None or width <= 0:
        return False
    horizontal = room['x'] - tolerance <= x <= room['x'] + room['width'] - width + tolerance
    vertical = room['y'] - tolerance <= y <= room['y'] + room['height'] - width + tolerance
    on_horizontal = abs(y - room['y']) <= tolerance or abs(y - (room['y'] + room['height'])) <= tolerance
    on_vertical = abs(x - room['x']) <= tolerance or abs(x - (room['x'] + room['width'])) <= tolerance
    return (orientation == 'horizontal' and horizontal and on_horizontal) or (orientation == 'vertical' and vertical and on_vertical)


def _inside_room(room: dict[str, Any], item: dict[str, Any]) -> bool:
    return (
        item.get('x', -1) >= room['x']
        and item.get('y', -1) >= room['y']
        and item.get('x', -1) + item.get('width', 0) <= room['x'] + room['width']
        and item.get('y', -1) + item.get('height', 0) <= room['y'] + room['height']
    )


def validate_layout(layout: dict[str, Any], spec: PlanningSpec) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    rooms = layout.get('rooms', [])
    if not isinstance(rooms, list):
        errors.append('rooms must be a list')
        rooms = []
    room_ids = {room.get('id') for room in rooms}

    ids = [room.get('id') for room in rooms]
    if len(ids) != len(set(ids)):
        errors.append('room IDs must be unique')

    for room in rooms:
        errors.extend(_geometry_errors(room, spec.plot_width, spec.plot_length, f"room {room.get('id', '?')}"))
        if room.get('floor', 1) < 1 or room.get('floor', 1) > spec.floors:
            errors.append(f"room {room.get('id', '?')} has an invalid floor")
        if room.get('width', 0) and room.get('height', 0):
            ratio = max(room['width'], room['height']) / min(room['width'], room['height'])
            if ratio > 3.5:
                warnings.append(f"room {room.get('id', '?')} has a narrow proportion")
        rule = ROOM_RULES.get(room.get('type'), {})
        if rule.get('target_max') and room.get('area', 0) > rule['target_max'] * 1.75:
            errors.append(f"room {room.get('id', '?')} is excessively large for its type")
        elif rule.get('target_min') and room.get('area', 0) < rule['target_min'] * 0.75:
            warnings.append(f"room {room.get('id', '?')} is below its conceptual target range")

    for index, first in enumerate(rooms):
        for second in rooms[index + 1:]:
            if first.get('floor', 1) == second.get('floor', 1) and rectangles_overlap(first, second):
                errors.append(f"rooms {first.get('id')} and {second.get('id')} overlap")

    parking = layout.get('parking', [])
    open_spaces = layout.get('open_spaces', [])
    for item in [*parking, *open_spaces]:
        errors.extend(_geometry_errors(item, spec.plot_width, spec.plot_length, f"space {item.get('id', '?')}"))

    occupied = [*rooms, *parking, *open_spaces]
    for index, first in enumerate(occupied):
        for second in occupied[index + 1:]:
            if first.get('floor', 1) == second.get('floor', 1) and rectangles_overlap(first, second):
                errors.append(f"spaces {first.get('id')} and {second.get('id')} overlap")

    actual_counts: dict[str, int] = {}
    for room in rooms:
        actual_counts[room.get('type')] = actual_counts.get(room.get('type'), 0) + 1
    for room_type, count in spec.room_counts.items():
        if actual_counts.get(room_type, 0) != count:
            errors.append(f'required {room_type} count is not satisfied')

    if len(parking) != spec.parking_count:
        errors.append('required parking count is not satisfied')
    if spec.features.get('garden_open_space') and not open_spaces:
        errors.append('required garden/open space is missing')

    entrances = layout.get('entrances', [])
    if not entrances:
        errors.append('layout is missing a main entrance')
    else:
        entrance_target = next((room for room in rooms if room.get('id') == entrances[0].get('connects_to')), None)
        if entrance_target and entrance_target.get('type') in {'bedroom', 'bathroom', 'utility', 'storage', 'kitchen'}:
            errors.append('main entrance does not lead to a public foyer or living area')

    corridors = layout.get('circulation', {}).get('corridors', [])
    if rooms and (not corridors or any(corridor.get('width_clear', 0) < 3.5 for corridor in corridors)):
        errors.append('circulation spine is missing or too narrow')

    for door in layout.get('doors', []):
        if door.get('connects_to') not in room_ids:
            errors.append(f"door {door.get('id', '?')} connects to a missing room")
        if (
            door.get('connects_from') not in room_ids
            and door.get('connects_from') != 'exterior'
            and not door.get('circulation')
            and not door.get('exterior')
        ):
            errors.append(f"door {door.get('id', '?')} connects from a missing room")
        if door.get('width', 0) <= 0:
            errors.append(f"door {door.get('id', '?')} has non-positive width")
        target = next((room for room in rooms if room.get('id') == door.get('connects_to')), None)
        if target and not _room_boundary_contains(target, door):
            errors.append(f"door {door.get('id', '?')} is not on a room boundary")
        if target and door.get('clearance'):
            swing_width = door.get('width', 0)
            swing_height = swing_width
            swing = {
                'x': door.get('x', 0), 'y': door.get('y', 0),
                'width': swing_width, 'height': swing_height,
            }
            blocked = any(
                item.get('room_id') == target.get('id') and rectangles_overlap(swing, item)
                for item in layout.get('furniture', [])
            )
            if blocked:
                errors.append(f"door {door.get('id', '?')} swing is blocked by furniture")

    for window in layout.get('windows', []):
        room_id = window.get('room_id')
        if room_id not in room_ids:
            errors.append(f"window {window.get('id', '?')} references a missing room")
        if window.get('width', 0) <= 0:
            errors.append(f"window {window.get('id', '?')} has non-positive width")
        target = next((room for room in rooms if room.get('id') == room_id), None)
        if target and not _room_boundary_contains(target, window):
            errors.append(f"window {window.get('id', '?')} is not on a room boundary")

    for item in layout.get('furniture', []):
        target = next((room for room in rooms if room.get('id') == item.get('room_id')), None)
        if target is None:
            errors.append(f"furniture {item.get('id', '?')} references a missing room")
        elif not _inside_room(target, item):
            errors.append(f"furniture {item.get('id', '?')} is outside its room")

    for stair in [*layout.get('stairs', []), *layout.get('stair_arrivals', [])]:
        if not stair.get('arrival'):
            target = next((room for room in rooms if room.get('floor') == stair.get('floor') and _inside_room(room, stair)), None)
            if target is None:
                target = next((corridor for corridor in layout.get('circulation', {}).get('corridors', []) if corridor.get('floor') == stair.get('floor') and _inside_room(corridor, stair)), None)
            if target is None:
                errors.append(f"stairs {stair.get('id', '?')} are outside a room on their floor")
        if spec.floors > 1 and stair.get('connects_floors') != list(range(1, spec.floors + 1)):
            errors.append(f"stairs {stair.get('id', '?')} do not connect all required floors")
        if any(
            room.get('floor') == stair.get('floor') and room.get('type') == 'bedroom' and rectangles_overlap(room, stair)
            for room in rooms
        ):
            errors.append(f"stairs {stair.get('id', '?')} are inside a bedroom")
    if spec.floors > 1 and not layout.get('stairs'):
        errors.append('multi-floor layout is missing a connecting staircase')
    if spec.floors > 1:
        arrivals = layout.get('stair_arrivals', [])
        expected_floors = set(range(2, spec.floors + 1))
        actual_floors = {stair.get('floor') for stair in arrivals}
        if actual_floors != expected_floors:
            errors.append('stair arrivals are missing from one or more upper floors')
        base = next(iter(layout.get('stairs', [])), None)
        for arrival in arrivals:
            if base and (arrival.get('x') != base.get('x') or arrival.get('y') != base.get('y')):
                errors.append(f"stair arrival {arrival.get('id', '?')} is not vertically aligned")

    for wall in layout.get('walls', []):
        if wall.get('orientation') == 'vertical':
            in_bounds = 0 <= wall.get('x', -1) <= spec.plot_width and 0 <= wall.get('y', -1) <= spec.plot_length and wall.get('y', -1) + wall.get('length', 0) <= spec.plot_length
        else:
            in_bounds = 0 <= wall.get('x', -1) <= spec.plot_width and 0 <= wall.get('y', -1) <= spec.plot_length and wall.get('x', -1) + wall.get('length', 0) <= spec.plot_width
        if not in_bounds:
            errors.append(f"wall {wall.get('id', '?')} is outside the plot")

    room_ids = {room.get('id') for room in rooms}
    for dimension in layout.get('dimensions', []):
        if dimension.get('type') == 'room' and dimension.get('room_id') not in room_ids:
            errors.append(f"dimension {dimension.get('id', '?')} references a missing room")
        if dimension.get('length', 0) <= 0:
            errors.append(f"dimension {dimension.get('id', '?')} has non-positive length")

    circulation_errors = validate_circulation(layout.get('circulation', {}), rooms)
    warnings.extend(circulation_errors)
    errors.extend(validate_bathroom_relationships(rooms))

    return {'valid': not errors, 'errors': errors, 'warnings': warnings}
