"""Self-contained SVG export from structured layout geometry."""

from html import escape
from typing import Any


def _text(x: float, y: float, value: Any, class_name: str = '') -> str:
    return f'<text x="{x:g}" y="{y:g}" class="{class_name}">{escape(str(value))}</text>'


def _line(x1: float, y1: float, x2: float, y2: float, class_name: str) -> str:
    return f'<line x1="{x1:g}" y1="{y1:g}" x2="{x2:g}" y2="{y2:g}" class="{class_name}" />'


def _furniture(item: dict[str, Any]) -> str:
    x, y = item['x'], item['y']
    width, height = item['width'], item['height']
    kind = escape(str(item.get('type', 'fixture')))
    return f'<rect x="{x:g}" y="{y:g}" width="{width:g}" height="{height:g}" class="furniture furniture-{kind}" />'


def _door(door: dict[str, Any]) -> str:
    x, y, width = door['x'], door['y'], door.get('width', 2.5)
    if door.get('orientation') == 'vertical':
        leaf = _line(x, y, x + width, y, 'door-leaf')
        arc = f'<path d="M {x + width:g} {y:g} A {width:g} {width:g} 0 0 1 {x:g} {y + width:g}" class="door-arc" />'
    else:
        leaf = _line(x, y, x, y + width, 'door-leaf')
        arc = f'<path d="M {x:g} {y + width:g} A {width:g} {width:g} 0 0 0 {x + width:g} {y:g}" class="door-arc" />'
    jamb = _line(x, y, x + (width if door.get('orientation') == 'vertical' else 0), y + (width if door.get('orientation') != 'vertical' else 0), 'door-jamb')
    return f'<g class="door" id="door-{escape(str(door.get("id", "door")))}">{jamb}{leaf}{arc}</g>'


def _window(window: dict[str, Any]) -> str:
    x, y, width = window['x'], window['y'], window.get('width', 4)
    if window.get('orientation') == 'vertical':
        lines = _line(x, y, x, y + width, 'window-frame') + _line(x + .45, y, x + .45, y + width, 'window-frame')
    else:
        lines = _line(x, y, x + width, y, 'window-frame') + _line(x, y + .45, x + width, y + .45, 'window-frame')
    return f'<g class="window" id="window-{escape(str(window.get("id", "window")))}">{lines}</g>'


def layout_to_svg(layout: dict[str, Any], title: str = 'DREAM HOME') -> str:
    plot = layout['plot']
    width = float(plot['width'])
    length = float(plot['length'])
    margin = 12
    outer_x = 14
    outer_y = 12
    canvas_width = width + margin * 2 + 22
    canvas_height = length + margin * 2 + 18
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {canvas_width:g} {canvas_height:g}" role="img" aria-label="{escape(title)} conceptual floor plan">',
        '<style>.plot{fill:#fff;stroke:#172033;stroke-width:1}.room{fill:#f7fafc;stroke:#49566b;stroke-width:.12}.space{fill:#edf6ed;stroke:#4e8a5b;stroke-width:.2;stroke-dasharray:1 .7}.parking{fill:#f4ead8;stroke:#7b6546;stroke-width:.2}.label{fill:#172033;font:700 1.05px sans-serif;text-anchor:middle}.detail{fill:#4b5563;font:.72px sans-serif;text-anchor:middle}.dim{fill:#53627a;font:.9px sans-serif;text-anchor:middle}.title{fill:#172033;font:700 2.2px sans-serif}.subtitle{fill:#4b5563;font:.82px sans-serif}.exterior-wall{stroke:#172033;stroke-width:.7}.interior-wall{stroke:#566274;stroke-width:.28}.door-leaf,.door-arc{fill:none;stroke:#7a4b2a;stroke-width:.26}.window-frame{stroke:#2f80a8;stroke-width:.24}.furniture{fill:#dfeaf5;stroke:#62748a;stroke-width:.12}.circulation{fill:#eef3f7;stroke:#9aa7b4;stroke-width:.18;stroke-dasharray:.7 .5}.stair{fill:#f5f0e7;stroke:#6b7280;stroke-width:.24}.stair-step{stroke:#6b7280;stroke-width:.12}.north{fill:#172033;font:700 1.5px sans-serif;text-anchor:middle}.dimension-line{stroke:#53627a;stroke-width:.18;stroke-dasharray:0.6 .22}.dimension-label{fill:#53627a;font:.8px sans-serif;text-anchor:middle}</style>',
        f'<g id="title-block"><text x="{margin}" y="{margin * 0.9:g}" class="title">DREAM HOME</text><text x="{margin}" y="{margin * 1.5:g}" class="subtitle">{escape(str(title))}</text></g>',
        f'<g transform="translate({margin} {margin})"><rect class="plot" x="0" y="0" width="{width:g}" height="{length:g}"/></g>',
    ]
    plot_group = f'<g id="plan" transform="translate({margin} {margin})">'
    for space in [*(layout.get('parking') or []), *(layout.get('open_spaces') or [])]:
        class_name = 'parking' if space.get('type') == 'parking' else 'space'
        plot_group += f'<g id="space-{escape(str(space.get("id", "space")))}"><rect class="{class_name}" x="{space["x"]}" y="{space["y"]}" width="{space["width"]}" height="{space["height"]}"/>'
        label = 'PARKING' if class_name == 'parking' else 'GARDEN'
        plot_group += _text(space['x'] + space['width'] / 2, space['y'] + space['height'] / 2, label, 'detail')
        plot_group += '</g>'
    for corridor in layout.get('circulation', {}).get('corridors', []):
        plot_group += f'<rect class="circulation" x="{corridor["x"]}" y="{corridor["y"]}" width="{corridor["width"]}" height="{corridor["height"]}"/>'
    for entrance in layout.get('entrances', []):
        plot_group += _text(entrance['x'] + entrance['width'] / 2, entrance['y'] - 1.0, 'ENTRY', 'detail')
    for room in layout.get('rooms') or []:
        center_x = room['x'] + room['width'] / 2
        center_y = room['y'] + room['height'] / 2
        compact = room['width'] < 6.5 or room['height'] < 6.5
        plot_group += f'<g id="room-{escape(str(room["id"]))}"><rect class="room" x="{room["x"]}" y="{room["y"]}" width="{room["width"]}" height="{room["height"]}"/>'
        for item in room.get('furniture', []):
            plot_group += _furniture(item)
        label = room.get('name') or room.get('type', 'Room').replace('_', ' ').title()
        plot_group += _text(center_x, center_y - 1.0, label, 'label')
        if not compact:
            plot_group += _text(center_x, center_y + 1.5, f'{room["width"]} x {room["height"]} {plot.get("unit", "ft")}', 'detail')
            plot_group += _text(center_x, center_y + 3.0, f'{room["area"]} sq ft', 'detail')
        else:
            plot_group += _text(center_x, center_y + 1.4, f'{room["area"]} sq ft', 'detail')
        plot_group += '</g>'
    for wall in layout.get('walls', []):
        cls = 'exterior-wall' if wall.get('type') == 'exterior' else 'interior-wall'
        if wall.get('orientation') == 'vertical':
            plot_group += _line(wall['x'], wall['y'], wall['x'], wall['y'] + wall['length'], cls)
        else:
            plot_group += _line(wall['x'], wall['y'], wall['x'] + wall['length'], wall['y'], cls)
    for door in layout.get('doors') or []:
        plot_group += _door(door)
    for window in layout.get('windows') or []:
        plot_group += _window(window)
    for stair in [*layout.get('stairs', []), *layout.get('stair_arrivals', [])]:
        plot_group += f'<g class="stair"><rect x="{stair["x"]}" y="{stair["y"]}" width="{stair["width"]}" height="{stair["height"]}"/>'
        step = stair['height'] / max(1, stair.get('steps', 10))
        for index in range(1, stair.get('steps', 10)):
            plot_group += _line(stair['x'], stair['y'] + index * step, stair['x'] + stair['width'], stair['y'] + index * step, 'stair-step')
        plot_group += _text(stair['x'] + stair['width'] / 2, stair['y'] + stair['height'] / 2, 'UP', 'detail')
        plot_group += '</g>'
    plot_group += '</g>'
    parts.append(plot_group)
    parts.append(f'<g id="dimensions" transform="translate({margin} {margin})">')
    parts.append(_line(-1.5, -2.5, width + 1.5, -2.5, 'dimension-line'))
    parts.append(_line(-2.5, -1.5, -2.5, length + 1.5, 'dimension-line'))
    parts.append(_text(width / 2, -4.2, f'{width:g} {plot.get("unit", "ft")}', 'dimension-label'))
    parts.append(_text(-4.9, length / 2, f'{length:g} {plot.get("unit", "ft")}', 'dimension-label'))
    parts.append('</g>')
    parts.append(f'<g id="north-arrow" transform="translate({width + margin + 6} {margin + 3})"><text x="0" y="0" class="north">N</text><path d="M 0 4 L 1.4 0 L 2.8 4" fill="none" stroke="#172033" stroke-width=".25"/><line x1="1.4" y1="4" x2="1.4" y2="9" stroke="#172033" stroke-width=".2" /></g>')
    score = layout.get('score') or {}
    score_text = f"Score: {score.get('total', 'n/a')}/100"
    parts.append(f'<g id="score-block"><text x="{margin}" y="{canvas_height - 4:g}" class="subtitle">{escape(score_text)}</text></g>')
    parts.append('</svg>')
    return ''.join(parts)
