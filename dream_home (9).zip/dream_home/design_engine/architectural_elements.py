"""Deterministic architectural elements derived from generated room geometry."""

from typing import Any

from .door_planner import plan_doors
from .furniture import generate_furniture as generate_planned_furniture
from .rules import ADJACENCY_RULES
from .walls import generate_walls as generate_planned_walls


def _touching(first: dict[str, Any], second: dict[str, Any]) -> tuple[str, float, float] | None:
    first_right = first['x'] + first['width']
    second_right = second['x'] + second['width']
    first_bottom = first['y'] + first['height']
    second_bottom = second['y'] + second['height']
    vertical_overlap = max(first['y'], second['y']) < min(first_bottom, second_bottom)
    horizontal_overlap = max(first['x'], second['x']) < min(first_right, second_right)
    if abs(first_right - second['x']) < 0.01 and vertical_overlap:
        start, end = max(first['y'], second['y']), min(first_bottom, second_bottom)
        return 'vertical', (start + end) / 2, end - start
    if abs(first_bottom - second['y']) < 0.01 and horizontal_overlap:
        start, end = max(first['x'], second['x']), min(first_right, second_right)
        return 'horizontal', (start + end) / 2, end - start
    if abs(second_right - first['x']) < 0.01 and vertical_overlap:
        start, end = max(first['y'], second['y']), min(first_bottom, second_bottom)
        return 'vertical', (start + end) / 2, end - start
    if abs(second_bottom - first['y']) < 0.01 and horizontal_overlap:
        start, end = max(first['x'], second['x']), min(first_right, second_right)
        return 'horizontal', (start + end) / 2, end - start
    return None


def _preferred(room: dict[str, Any], other: dict[str, Any]) -> bool:
    return other['type'] in ADJACENCY_RULES.get(room['type'], {})


def _wall_key(first: dict[str, Any], second: dict[str, Any]) -> tuple[Any, ...] | None:
    touching = _touching(first, second)
    if touching is None or first.get('floor', 1) != second.get('floor', 1):
        return None
    orientation, coordinate, _ = touching
    if orientation == 'vertical':
        return ('vertical', first.get('floor', 1), round(coordinate, 2), round(max(first['y'], second['y']), 2), round(min(first['y'] + first['height'], second['y'] + second['height']), 2))
    return ('horizontal', first.get('floor', 1), round(coordinate, 2), round(max(first['x'], second['x']), 2), round(min(first['x'] + first['width'], second['x'] + second['width']), 2))


def generate_walls(rooms: list[dict[str, Any]], plot: dict[str, Any], wall_thickness: float = 0.25) -> list[dict[str, Any]]:
    """Create one wall record per exterior or shared boundary segment."""
    walls: list[dict[str, Any]] = []
    seen: set[tuple[Any, ...]] = set()
    floors = sorted({room.get('floor', 1) for room in rooms} or {1})
    for floor in floors:
        walls.extend([
            {'id': f'exterior_{floor}_north', 'type': 'exterior', 'floor': floor, 'orientation': 'horizontal', 'x': 0.0, 'y': 0.0, 'length': plot['width'], 'thickness': wall_thickness},
            {'id': f'exterior_{floor}_south', 'type': 'exterior', 'floor': floor, 'orientation': 'horizontal', 'x': 0.0, 'y': plot['length'], 'length': plot['width'], 'thickness': wall_thickness},
            {'id': f'exterior_{floor}_west', 'type': 'exterior', 'floor': floor, 'orientation': 'vertical', 'x': 0.0, 'y': 0.0, 'length': plot['length'], 'thickness': wall_thickness},
            {'id': f'exterior_{floor}_east', 'type': 'exterior', 'floor': floor, 'orientation': 'vertical', 'x': plot['width'], 'y': 0.0, 'length': plot['length'], 'thickness': wall_thickness},
        ])
    for index, first in enumerate(rooms):
        for second in rooms[index + 1:]:
            key = _wall_key(first, second)
            if key is None or key in seen:
                continue
            seen.add(key)
            orientation, floor, coordinate, start, end = key
            walls.append({
                'id': f'interior_{len(walls) + 1}', 'type': 'interior', 'floor': floor,
                'orientation': orientation, 'x': coordinate if orientation == 'vertical' else start,
                'y': start if orientation == 'vertical' else coordinate, 'length': round(end - start, 2),
                'thickness': wall_thickness, 'rooms': [first['id'], second['id']],
            })
    return walls


def _inside(room: dict[str, Any], x: float, y: float, width: float, height: float, inset: float = 0.25) -> bool:
    return (
        x >= room['x'] + inset and y >= room['y'] + inset
        and x + width <= room['x'] + room['width'] - inset
        and y + height <= room['y'] + room['height'] - inset
    )


def _furniture(room: dict[str, Any], item_type: str, x: float, y: float, width: float, height: float, **extra: Any) -> dict[str, Any] | None:
    if not _inside(room, x, y, width, height):
        return None
    return {'id': f"{room['id']}_{item_type}_{len(room.get('furniture', [])) + 1}", 'type': item_type, 'room_id': room['id'], 'floor': room.get('floor', 1), 'x': round(x, 2), 'y': round(y, 2), 'width': round(width, 2), 'height': round(height, 2), **extra}


def generate_furniture(rooms: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Place conservative, room-specific conceptual symbols only when they fit."""
    furniture: list[dict[str, Any]] = []
    for room in rooms:
        room['furniture'] = []
        inset = 0.7
        x, y, width, height = room['x'] + inset, room['y'] + inset, room['width'] - inset * 2, room['height'] - inset * 2
        candidates: list[tuple[str, float, float, float, float, dict[str, Any]]] = []
        if room['type'] == 'bedroom':
            candidates = [('bed', x, y, min(6.2, width * .62), min(6.6, height * .62), {}), ('wardrobe', room['x'] + room['width'] - 1.3, room['y'] + .7, 1.0, min(4.0, height), {})]
        elif room['type'] == 'living':
            candidates = [('sofa', x, y, min(6.5, width * .58), 1.6, {}), ('coffee_table', x + .5, y + 2.5, min(3.0, width * .3), 1.4, {})]
        elif room['type'] == 'dining':
            candidates = [('dining_table', room['x'] + room['width'] / 2 - min(4.5, width) / 2, room['y'] + room['height'] / 2 - min(3.0, height) / 2, min(4.5, width), min(3.0, height), {'seats': 6})]
        elif room['type'] == 'kitchen':
            candidates = [('counter', x, y, width, min(2.0, height), {}), ('sink', x + min(3.0, width - 1.4), y + .35, 1.4, 1.3, {}), ('cooktop', x + max(0.5, width - 3.0), y + .45, 1.5, 1.0, {})]
        elif room['type'] == 'bathroom':
            candidates = [('toilet', x, y, 1.4, 1.9, {}), ('basin', room['x'] + room['width'] - 2.1, y, 1.6, .9, {})]
        elif room['type'] == 'study':
            candidates = [('desk', x, y, min(4.5, width), 1.8, {}), ('chair', x + 1.5, y + 2.0, 1.2, 1.2, {})]
        elif room['type'] == 'utility':
            candidates = [('utility_counter', x, y, width, min(1.8, height), {}), ('washing_machine', x, y + 2.1, 2.0, 2.0, {})]
        for item_type, item_x, item_y, item_width, item_height, extra in candidates:
            item = _furniture(room, item_type, item_x, item_y, item_width, item_height, **extra)
            if item:
                room['furniture'].append(item)
                furniture.append(item)
    return furniture


def generate_stairs(rooms: list[dict[str, Any]], floors: int, circulation: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    if floors <= 1:
        return []
    corridor = next((item for item in (circulation or {}).get('corridors', []) if item.get('floor') == 1), None)
    if corridor and corridor['height'] >= 7:
        return [{
            'id': 'stairs_1', 'type': 'stairs', 'floor': 1,
            'x': 0.25, 'y': round(corridor['y'] + 0.5, 2), 'width': 3.5,
            'height': min(8.0, round(corridor['height'] - 1.0, 2)),
            'direction': 'up', 'steps': 10, 'connects_floors': list(range(1, floors + 1)),
            'connects_to': 'circulation', 'core': True, 'dedicated_zone': 'corridor',
        }]
    for room in rooms:
        if room.get('floor') != 1 or room['width'] < 4 or room['height'] < 5:
            continue
        width, height = min(3.5, room['width'] - 1.0), min(8.0, room['height'] - 1.0)
        positions = [
            (room['x'] + room['width'] - width - .5, room['y'] + .5),
            (room['x'] + .5, room['y'] + .5),
            (room['x'] + .5, room['y'] + room['height'] - height - .5),
        ]
        for x, y in positions:
            stair = {
                'id': 'stairs_1', 'type': 'stairs', 'floor': 1,
                'x': round(x, 2), 'y': round(y, 2), 'width': width, 'height': height,
                'direction': 'up', 'steps': 10, 'connects_floors': list(range(1, floors + 1)),
                'connects_to': 'circulation', 'core': True,
            }
            if not _inside(room, x, y, width, height):
                continue
            if any(
                x < item['x'] + item['width'] and x + width > item['x']
                and y < item['y'] + item['height'] and y + height > item['y']
                for item in room.get('furniture', [])
            ):
                continue
            return [stair]
    return []


def generate_stair_arrivals(stairs: list[dict[str, Any]], floors: int) -> list[dict[str, Any]]:
    """Create aligned landing geometry for each upper floor of the stair core."""
    if floors <= 1 or not stairs:
        return []
    base = stairs[0]
    return [
        {
            **base,
            'id': f"{base['id']}_arrival_{floor}",
            'floor': floor,
            'arrival': True,
        }
        for floor in range(2, floors + 1)
    ]


def generate_dimensions(rooms: list[dict[str, Any]], plot: dict[str, Any]) -> list[dict[str, Any]]:
    dimensions = [
        {'id': 'dimension_plot_width', 'type': 'overall', 'orientation': 'horizontal', 'x': 0.0, 'y': -3.0, 'length': plot['width'], 'label': f"{plot['width']} {plot['unit']}"},
        {'id': 'dimension_plot_length', 'type': 'overall', 'orientation': 'vertical', 'x': -3.0, 'y': 0.0, 'length': plot['length'], 'label': f"{plot['length']} {plot['unit']}"},
    ]
    for room in rooms:
        dimensions.extend([
            {'id': f"dimension_{room['id']}_width", 'type': 'room', 'room_id': room['id'], 'floor': room.get('floor', 1), 'orientation': 'horizontal', 'x': room['x'], 'y': room['y'] + room['height'] + .8, 'length': room['width'], 'label': f"{room['width']} {plot['unit']}"},
            {'id': f"dimension_{room['id']}_height", 'type': 'room', 'room_id': room['id'], 'floor': room.get('floor', 1), 'orientation': 'vertical', 'x': room['x'] + room['width'] + .8, 'y': room['y'], 'length': room['height'], 'label': f"{room['height']} {plot['unit']}"},
        ])
    return dimensions


def generate_doors(rooms: list[dict[str, Any]], parking: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    doors: list[dict[str, Any]] = []
    entrances: list[dict[str, Any]] = []
    connected_pairs: set[frozenset[str]] = set()
    public_rooms = [room for room in rooms if room.get('zone') == 'public']
    entry_room = public_rooms[0] if public_rooms else (rooms[0] if rooms else None)
    if entry_room:
        width = min(3.0, entry_room['width'] * 0.35)
        entrance = {
            'id': 'main_entrance',
            'type': 'main',
            'room_id': entry_room['id'],
            'wall': 'north',
            'floor': entry_room.get('floor', 1),
            'x': round(entry_room['x'] + (entry_room['width'] - width) / 2, 2),
            'y': round(entry_room['y'], 2),
            'width': round(width, 2),
            'orientation': 'horizontal',
            'swing': 'right',
            'connects_from': parking[0]['id'] if parking else 'exterior',
            'connects_to': entry_room['id'],
            'exterior': True,
        }
        entrances.append(entrance)
        doors.append({**entrance, 'id': 'door_main_entrance'})

    for index, room in enumerate(rooms):
        for other in rooms[index + 1:]:
            if room.get('floor', 1) != other.get('floor', 1):
                continue
            pair = frozenset((room['id'], other['id']))
            if pair in connected_pairs or not (_preferred(room, other) or _preferred(other, room)):
                continue
            touching = _touching(room, other)
            if touching is None:
                continue
            orientation, coordinate, overlap_length = touching
            door_width = min(3.0, overlap_length)
            if orientation == 'vertical':
                x = min(room['x'] + room['width'], other['x'] + other['width'])
                door = {'x': round(x, 2), 'y': round(coordinate - door_width / 2, 2), 'orientation': 'vertical'}
            else:
                y = min(room['y'] + room['height'], other['y'] + other['height'])
                door = {'x': round(coordinate - door_width / 2, 2), 'y': round(y, 2), 'orientation': 'horizontal'}
            doors.append({
                'id': f"door_{room['id']}_{other['id']}",
                'type': 'interior',
                'room_id': other['id'],
                'wall': orientation,
                'floor': room.get('floor', 1),
                'width': round(door_width, 2),
                'swing': 'right',
                'connects_from': room['id'],
                'connects_to': other['id'],
                'exterior': False,
                **door,
            })
            connected_pairs.add(pair)
    connected_rooms = {door.get('connects_to') for door in doors}
    for room in rooms:
        if room['id'] in connected_rooms or (entry_room and room['id'] == entry_room['id']):
            continue
        width = min(2.5, room['width'] * 0.3)
        doors.append({
            'id': f"door_{room['id']}_exterior", 'type': 'room', 'room_id': room['id'],
            'wall': 'north', 'floor': room.get('floor', 1), 'x': round(room['x'] + (room['width'] - width) / 2, 2),
            'y': round(room['y'], 2), 'width': round(width, 2), 'orientation': 'horizontal',
            'swing': 'right', 'connects_from': 'exterior', 'connects_to': room['id'], 'exterior': True,
        })
    return doors, entrances


def generate_windows(rooms: list[dict[str, Any]], plot: dict[str, Any]) -> list[dict[str, Any]]:
    windows: list[dict[str, Any]] = []
    for room in rooms:
        if room['type'] in {'storage', 'utility', 'bathroom'}:
            window_width = min(2.0, room['width'] * 0.35)
        else:
            window_width = min(4.0, room['width'] * 0.45)
        width = min(4.0, room['width'] * 0.45)
        height = min(4.0, room['height'] * 0.45)
        if room['x'] <= 0:
            windows.append({'id': f"window_{room['id']}_west", 'x': 0.0, 'y': round(room['y'] + (room['height'] - height) / 2, 2), 'width': height, 'orientation': 'vertical', 'room_id': room['id'], 'wall': 'west', 'wall_side': 'west', 'floor': room.get('floor', 1), 'type': 'ventilation' if room['type'] == 'bathroom' else 'window'})
        elif room['x'] + room['width'] >= plot['width']:
            windows.append({'id': f"window_{room['id']}_east", 'x': round(plot['width'], 2), 'y': round(room['y'] + (room['height'] - height) / 2, 2), 'width': height, 'orientation': 'vertical', 'room_id': room['id'], 'wall': 'east', 'wall_side': 'east', 'floor': room.get('floor', 1), 'type': 'ventilation' if room['type'] == 'bathroom' else 'window'})
        if room['y'] + room['height'] >= plot['length']:
            windows.append({'id': f"window_{room['id']}_south", 'x': round(room['x'] + (room['width'] - width) / 2, 2), 'y': round(plot['length'], 2), 'width': width, 'orientation': 'horizontal', 'room_id': room['id'], 'wall': 'south', 'wall_side': 'south', 'floor': room.get('floor', 1), 'type': 'ventilation' if room['type'] == 'bathroom' else 'window'})
        row_rooms = [other for other in rooms if other.get('floor', 1) == room.get('floor', 1) and abs(other['y'] - room['y']) < 0.01]
        exposed = room['x'] + room['width'] >= max((other['x'] + other['width'] for other in row_rooms), default=0) - 0.01
        floor_rooms = [other for other in rooms if other.get('floor', 1) == room.get('floor', 1)]
        first_row = abs(room['y'] - min((other['y'] for other in floor_rooms), default=room['y'])) < 0.01
        last_row = abs(room['y'] + room['height'] - max((other['y'] + other['height'] for other in floor_rooms), default=room['y'] + room['height'])) < 0.01
        if not any(window['room_id'] == room['id'] for window in windows) and exposed and room['type'] in {'living', 'dining', 'bedroom', 'kitchen'}:
            right_edge = room['x'] + room['width']
            windows.append({'id': f"window_{room['id']}_exterior", 'x': round(right_edge, 2), 'y': round(room['y'] + (room['height'] - window_width) / 2, 2), 'width': round(window_width, 2), 'orientation': 'vertical', 'room_id': room['id'], 'wall': 'east', 'wall_side': 'east', 'floor': room.get('floor', 1), 'type': 'window'})
        if not any(window['room_id'] == room['id'] for window in windows) and room['type'] in {'living', 'dining', 'bedroom', 'kitchen'} and (first_row or last_row):
            y = room['y'] if first_row else room['y'] + room['height']
            wall = 'north' if first_row else 'south'
            windows.append({'id': f"window_{room['id']}_{wall}", 'x': round(room['x'] + (room['width'] - width) / 2, 2), 'y': round(y, 2), 'width': round(width, 2), 'orientation': 'horizontal', 'room_id': room['id'], 'wall': wall, 'wall_side': wall, 'floor': room.get('floor', 1), 'type': 'window'})
    return windows


def generate_architectural_elements(rooms: list[dict[str, Any]], parking: list[dict[str, Any]], plot: dict[str, Any], floors: int = 1) -> dict[str, Any]:
    from .circulation import plan_circulation

    circulation = plan_circulation(rooms, plot['width'])
    doors, entrances = plan_doors(rooms, circulation, parking)
    windows = generate_windows(rooms, plot)
    walls = generate_planned_walls(rooms, plot)
    furniture = generate_planned_furniture(rooms, doors)
    stairs = generate_stairs(rooms, floors, circulation)
    stair_arrivals = generate_stair_arrivals(stairs, floors)
    dimensions = generate_dimensions(rooms, plot)
    connectivity = {room['id']: [] for room in rooms}
    for door in doors:
        target = door['connects_to']
        source = door['connects_from']
        if source in connectivity:
            connectivity[source].append(target)
        if target in connectivity and source != 'exterior':
            connectivity[target].append(source)
    return {
        'walls': walls, 'doors': doors, 'windows': windows, 'entrances': entrances,
        'furniture': furniture, 'stairs': stairs, 'dimensions': dimensions,
        'stair_arrivals': stair_arrivals, 'connectivity': connectivity, 'circulation': circulation,
    }
