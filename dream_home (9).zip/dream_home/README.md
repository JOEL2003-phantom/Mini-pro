# DREAM HOME

## Overview

DREAM HOME is a Django project for structured home-layout planning. Phases 1 through 4 now cover the landing page, MongoDB persistence, authentication, and structured house requirements collection. Layout generation, visualization, AI integration, and export remain future phases.

## Technology Stack

- Python 3.13+
- Django 5.2
- PyMongo 4.x
- MongoDB 7.x or a compatible MongoDB deployment
- HTML, CSS, and JavaScript for the Phase 1 landing page

## Phase 2 Persistence Architecture

Django continues to use SQLite for framework-owned tables such as admin, sessions, and migrations. Structured DREAM HOME designs are stored in MongoDB through the PyMongo driver.

The application does not use a third-party Django MongoDB ORM. `designs/persistence.py` is the persistence service boundary and owns:

- lazy MongoDB client and collection access
- connection ping verification
- storage-level validation for identifiers, plot dimensions, and basic room geometry
- create, retrieve, update, delete, and user-scoped list operations

The service accepts an optional collection, which keeps tests and future application layers independent from raw MongoDB calls. Layout-generation algorithms do not belong in this module.

## MongoDB Setup

Install MongoDB locally or use a managed MongoDB deployment. Create a database user when authentication is enabled, then copy the environment template:

```powershell
copy .env.example .env
```

Set `MONGODB_URI` in `.env` to the connection URI supplied by your MongoDB installation or provider. The default local URI is `mongodb://localhost:27017`. The database and collection are selected separately by `MONGODB_DB_NAME` and `MONGODB_DESIGNS_COLLECTION`.

Never commit `.env` or place credentials directly in source code. `.env` is ignored by Git.

## Environment Variables

```env
SECRET_KEY=replace-with-a-local-or-production-secret
DEBUG=True
ALLOWED_HOSTS=127.0.0.1,localhost
MONGODB_URI=mongodb://localhost:27017
MONGODB_DB_NAME=dream_home
MONGODB_DESIGNS_COLLECTION=designs
MONGODB_SERVER_SELECTION_TIMEOUT_MS=2000
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=qwen3:4b
```

`MONGODB_SERVER_SELECTION_TIMEOUT_MS` controls how long a client waits to select a reachable MongoDB server. The client is created lazily, so Django checks and the Phase 1 landing page do not require MongoDB to be running.

## Local AI Requirement Parsing

The optional `ai_engine` package sends natural-language requirements to a local Ollama server and validates the returned JSON before passing it to the unchanged deterministic `design_engine`. Ollama interprets requirements only; it does not generate floor-plan images or geometry. `natural_language_to_design()` returns the existing `recommended_layout`, `alternatives`, and `candidates` fields plus `requirements` and `plans`, where `plans` contains valid candidates sorted by score.

Install and start Ollama separately:

```powershell
winget install --id Ollama.Ollama -e
ollama pull qwen3:4b
ollama serve
```

The default endpoint is `http://localhost:11434`. Set `OLLAMA_BASE_URL` and `OLLAMA_MODEL` in `.env` to use another local endpoint or model. No Ollama Python dependency is required.

## Example Design Document

```json
{
	"user_id": "user-1",
	"design_id": "design-1",
	"design_name": "Courtyard concept",
	"plot": {
		"width": 30,
		"length": 40,
		"unit": "feet"
	},
	"preferences": {
		"bedrooms": 3,
		"bathrooms": 2,
		"kitchen": true,
		"living_room": true,
		"dining_room": true,
		"parking": true,
		"floors": 1,
		"balcony": false,
		"utility_room": false,
		"work_study_room": true,
		"prayer_room": false,
		"storage_room": true,
		"garden_open_space": true,
		"style": "modern",
		"approximate_budget": 150000,
		"other_requirements": ""
	},
	"layout": {
		"rooms": [
			{
				"id": "room-1",
				"name": "Living room",
				"type": "living_room",
				"x": 0,
				"y": 0,
				"width": 12,
				"height": 14,
				"area": 168,
				"doors": [],
				"windows": [],
				"furniture": [],
				"adjacency": []
			}
		],
		"doors": [],
		"windows": [],
		"adjacency": [],
		"plot_boundary": {"width": 30, "length": 40},
		"score": null,
		"validation": {}
	},
	"created_at": "2026-09-15T00:00:00Z",
	"updated_at": "2026-09-15T00:00:00Z"
}
```

The persistence validation intentionally checks only basic storage integrity. Full layout validation and generation belong to the later Design Engine phase.

## Phase 3 Authentication

DREAM HOME uses Django's built-in authentication system with the existing SQLite database for users and sessions. Passwords are handled by Django's password hashing and validation utilities; plaintext passwords are never stored.

Available authentication routes:

- `/accounts/register/` creates an account, validates username/email/password fields, and signs the user in.
- `/accounts/login/` authenticates a user and creates a Django session.
- `/accounts/logout/` accepts a CSRF-protected POST, invalidates the session, and returns to the landing page.
- `/accounts/profile/` displays the authenticated user's username, email, and account creation date.
- `/dashboard/` is protected and provides the authenticated workspace empty state.

Dashboard and profile access uses `login_required`. The authenticated Django user primary key is the stable identity that future design workflows must pass as `user_id` to `DesignPersistenceService`; the MongoDB persistence service itself remains unchanged. No design creation, preferences, layout generation, or saved-design workflow is implemented in Phase 3.

## Phase 4 House Preference System

Authenticated users can select **Create new design** from the dashboard and submit structured requirements at `/designs/new/`.

The form supports plot width, plot length, feet (`ft`) as the unit, room counts, optional spaces, Modern/Traditional/Minimalist/Contemporary/Other style, a custom Other description, an approximate numeric budget, and additional free-text requirements. An optional design name receives a simple bedroom-based default when omitted.

Server-side validation rejects non-positive plot dimensions, negative or malformed counts, floors below one, unsupported styles, invalid budgets, and missing custom descriptions for Other. Client-submitted `user_id` values are ignored; ownership always comes from `request.user.pk`.

Submissions use `DesignPersistenceService` and create a preference-only design document with `layout: null` and `score: null`. No generated or fake floor plan is created. `/designs/<design_id>/review/` confirms the saved requirements, and the dashboard shows basic saved-record information.

Example preference structure:

```json
{
	"plot": {"width": 30, "length": 50, "unit": "ft"},
	"rooms": {"bedrooms": 3, "bathrooms": 2, "kitchen": 1, "living_room": 1, "dining_room": 1},
	"parking": 1,
	"floors": 1,
	"features": {"balcony": false, "utility_room": true, "work_study_room": false, "prayer_room": false, "storage_room": true, "garden_open_space": true},
	"style": "modern",
	"style_other": "",
	"budget": 3000000,
	"additional_requirements": "More natural light"
}
```

The current workflow is: landing page -> register/login -> dashboard -> house requirements -> review -> SVG floor plan.

## Phase 5 Design Engine

The pure-Python service `design_engine.services.generate_design(requirements, candidate_count=3, seed=0)` transforms the structured Phase 4 preferences into deterministic structured layout data. It is independent of Django HTTP requests and MongoDB, so it can later be called by views, tests, or visualization code.

The engine is split into:

- `analyzer.py`: normalizes plot, counts, optional features, style, floors, budget, and additional requirements into a planning specification.
- `rules.py`: centralizes configurable conceptual minimum dimensions, adjacency heuristics, and score weights.
- `generator.py`: reserves parking and garden space, creates unique room instances, and packs deterministic candidate layouts.
- `constraints.py`: validates geometry, plot boundaries, duplicate IDs, required rooms, parking, open space, and rectangle overlaps. Touching boundaries are allowed.
- `scorer.py`: calculates adjacency, privacy, circulation, space-efficiency, and modest preference metrics, then applies weighted scoring.
- `services.py`: validates, ranks, and returns the recommended layout plus valid alternatives.

Each room includes `id`, `name`, `type`, `x`, `y`, `width`, `height`, `area`, and empty future-compatible door/window/furniture fields. Layouts also contain plot, parking, open spaces, adjacency, validation, score, and score breakdown data.

The engine returns structured failure results when requirements cannot fit. It does not return invalid candidates as the recommendation, generate images, call AI providers, render SVG, or implement interactive editing. It is a conceptual intelligent planning system and is not a substitute for professional architectural or structural design.

## Phase 7 Advanced Layout Generation

The engine now produces up to six deterministic candidate layouts from the same structured requirements and seed. Candidate strategies vary meaningful room ordering and zoning: public-front, public-open, private-front, zoned split, semi-private-front, and reverse arrangements. Candidate generation remains bounded and fast for a Django request.

Planning spaces are classified as public, semi-private, private, or service using configurable rules. Public rooms are favored near the plan entrance side, private rooms are grouped away from public rooms where the candidate permits, and service spaces remain close to related rooms. These are explainable conceptual planning heuristics, not building-code or professional architectural guarantees.

Every candidate is checked for plot boundaries, positive and mathematically consistent geometry, duplicate IDs, required room counts, parking/open-space requirements, floor identifiers, and rectangle overlap. Invalid candidates cannot be recommended. Rooms include stable IDs, floor metadata, zone metadata, dimensions, area, and the existing Phase 6-compatible door/window/furniture fields.

Scoring is configurable and normalized through weighted components: requirement satisfaction, adjacency, space efficiency, circulation, room proportion, privacy, open-space utilization, parking quality, and style preference. Narrow room proportions receive a transparent quality penalty; budget remains an approximate planning preference and is not treated as construction-cost estimation.

Phase 7 remains deterministic and does not use an AI provider. The output is structured geometry consumed by the existing Phase 6 SVG visualizer. It is an intelligent conceptual planning system, not a substitute for professional architectural or structural design, legal approval, or construction documentation.

## Phase 6 SVG Visualization

Authenticated users can open `/designs/<design_id>/visualize/` from the requirements review page. The view scopes retrieval by the authenticated user's ID, invokes the Phase 5 engine for preference-only records, and passes the recommended structured layout to the visualizer. Existing stored layouts are consumed directly when present.

The SVG renderer in `static/js/floor_plan.js` keeps plot, walls, rooms, doors, windows, dimensions, and annotations in independent addressable groups. It uses one SVG unit per real-world foot and a responsive `viewBox`, so plot proportions remain accurate. Room rectangles, labels, areas, parking, garden/open space, dimension lines, score, validation, scale, and a neutral diagrammatic north indicator are derived from the Phase 5 layout rather than hard-coded house geometry.

The canvas supports non-destructive zoom controls and room selection/highlighting. Doors and windows remain empty groups until the engine supplies geometry; no unsupported architectural detail is fabricated. There is no dragging, resizing, editing, export, AI integration, or complete save/load workflow. The visualization is conceptual and must be reviewed by a qualified professional before construction.
Phase 7 architectural geometry now includes deterministic main entrances, shared-wall interior doors for supported room relationships, exterior-wall windows, room connectivity metadata, and floor/zone metadata. Doors and windows are generated as structured records first; the SVG only renders those records. A conceptual plan is not construction-ready architectural documentation.

## Phase 8 Structured Floor-Plan Editor

The existing SVG visualization now supports controlled structured editing. Authenticated users can select rooms, inspect room metadata, drag rooms with half-foot snapping, resize width/height, and see the SVG update immediately. Edits are kept in browser model coordinates, not screen pixels.

The editor maintains bounded undo/redo history and provides Reset to Generated Design, Save, Validate, and Regenerate actions. Invalid movement or resizing is rejected locally when it leaves the plot or creates overlap. Server-side validation uses the existing Phase 7 analyzer, geometry validator, adjacency calculation, and scorer before a save is accepted.

Phase 8 endpoints are ownership-scoped:

- `/designs/<design_id>/validate/` validates and scores an edited layout.
- `/designs/<design_id>/save-layout/` persists valid edited geometry through `DesignPersistenceService`.
- `/designs/<design_id>/regenerate/` regenerates from the original requirements through the Phase 7 engine.

MongoDB design IDs, requirements, ownership, structured rooms, doors, windows, entrances, connectivity, score, and validation are preserved. The editor remains conceptual and is not construction-ready architectural documentation. Room type changes, arbitrary door/window creation, export, and full revision history remain outside this phase.

## Setup and Verification

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python manage.py check
python manage.py test designs
python manage.py test ai_engine
python manage.py runserver
```

To verify a live MongoDB server separately, use the service-level ping from a Django shell or application integration check. The automated Phase 2 tests use an in-memory collection and do not require a MongoDB server or credentials.

The Phase 1 landing page remains available at `http://127.0.0.1:8000/`. Phase 3 includes authentication only; later design workflows remain intentionally out of scope.

## Current Project Structure

```text
dream_home/
├── manage.py
├── config/
│   ├── settings.py
│   ├── urls.py
│   ├── asgi.py
│   └── wsgi.py
├── accounts/
├── preferences/
├── designs/
│   ├── persistence.py
│   ├── tests.py
│   └── urls.py
├── design_engine/
├── templates/
├── static/
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Recommended Next Step

Review the Phase 2 persistence contract and MongoDB deployment choice before beginning the separately scoped authentication phase.
# DREAM HOME

## Overview

DREAM HOME is an AI-assisted home-layout planning platform designed to convert user preferences into a structured, explainable, and visually represented 2D floor plan. The system is intentionally built around deterministic planning logic, room heuristics, and validation rather than image-only generation.

## Problem Statement

Many design tools rely on generic AI-generated images without preserving the underlying room geometry, constraints, and explainability that matter for concept planning. DREAM HOME addresses this by combining user requirements, structured room planning, layout scoring, and an SVG-based floor-plan renderer.

## Objectives

- Collect plot and household requirements from non-technical users.
- Convert inputs into structured design constraints.
- Generate multiple valid candidate layouts.
- Score, validate, and explain layout quality.
- Visualize the chosen layout as an editable 2D plan.
- Save, retrieve, and export conceptual house designs.

## Core Features

- User registration and authentication foundation
- Preference collection for plot and room requirements
- Deterministic design engine with room rules and constraints
- Candidate layout generation and validation
- SVG-based 2D floor-plan generation
- Responsive landing page and project structure for future UX screens
- Ready-to-extend environment for later AI integration

## Technology Stack

- Python
- Django
- HTML5
- CSS3
- JavaScript
- Bootstrap-ready custom styling
- SVG visualization
- SQLite for Phase 1 development
- MongoDB-ready architecture for future persistence

## Project Structure

```text
dream_home/
├── manage.py
├── config/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   ├── asgi.py
│   └── wsgi.py
├── accounts/
├── preferences/
├── designs/
├── design_engine/
├── templates/
├── static/
│   ├── css/
│   ├── js/
│   └── images/
├── .env.example
├── .gitignore
├── requirements.txt
├── README.md
└── db.sqlite3
```

## Setup Instructions

1. Create a virtual environment.
2. Install dependencies from `requirements.txt`.
3. Copy `.env.example` to `.env` and adjust values.
4. Run the Django development server.

## Environment Variables

```env
SECRET_KEY=change-me-in-production
DEBUG=True
ALLOWED_HOSTS=127.0.0.1,localhost
MONGODB_URI=mongodb://localhost:27017/dream_home
AI_API_KEY=
```

## How to Run

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python manage.py migrate
python manage.py runserver
```

## Current Status

This is the Phase 1 foundation of the DREAM HOME project. The project structure, environment configuration, landing page, and Django base setup are in place and ready for the next phase.

## Limitations

- Phase 1 focuses on project foundation and landing page.
- No production-grade MongoDB integration yet.
- No user authentication workflows or design engine logic yet.
- The concept is intentionally deterministic and academic in scope.

## Future Enhancements

- Authentication and user profile flows
- Preference collection and validation
- Design engine with layout generation and scoring
- SVG floor-plan editing
- Save/load/export features
- AI abstraction and optional provider integration
