from django.urls import path

from .views import (
    decide_design, delete_design, export_design_svg, library, new_design, regenerate_design,
    review_design, save_edited_layout, select_plan, validate_edited_layout, visualize_design,
)

app_name = 'designs'

urlpatterns = [
    path('designs/library/', library, name='library'),
    path('designs/new/', new_design, name='new'),
    path('designs/<str:design_id>/review/', review_design, name='review'),
    path('designs/<str:design_id>/visualize/', visualize_design, name='visualize'),
    path('designs/<str:design_id>/decision/', decide_design, name='decision'),
    path('designs/<str:design_id>/select-plan/', select_plan, name='select_plan'),
    path('designs/<str:design_id>/export.svg', export_design_svg, name='export_svg'),
    path('designs/<str:design_id>/validate/', validate_edited_layout, name='validate'),
    path('designs/<str:design_id>/save-layout/', save_edited_layout, name='save_layout'),
    path('designs/<str:design_id>/regenerate/', regenerate_design, name='regenerate'),
    path('designs/<str:design_id>/delete/', delete_design, name='delete_design'),
]
