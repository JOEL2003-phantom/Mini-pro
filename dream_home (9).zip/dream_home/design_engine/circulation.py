"""Conceptual circulation planning for generated residential layouts."""

from collections import deque
from typing import Any


ZONE_ORDER = ('public', 'semi_private', 'service', 'private')


def _distance(first: dict[str, Any], second: dict[str, Any]) -> float:
    first_right = first['x'] + first['width']
    second_right = second['x'] + second['width']
    first_bottom = first['y'] + first['height']
    second_bottom = second['y'] + second['height']
    horizontal = max(second['x'] - first_right, first['x'] - second_right, 0)
    vertical = max(second['y'] - first_bottom, first['y'] - second_bottom, 0)
    return (horizontal ** 2 + vertical ** 2) ** 0.5


def _room_edges(rooms: list[dict[str, Any]], reach: float = 6.0) -> dict[str, set[str]]:
    graph = {room['id']: set() for room in rooms}
    for index, first in enumerate(rooms):
        for second in rooms[index + 1:]:
            if first.get('floor', 1) != second.get('floor', 1):
                continue
            if _distance(first, second) <= reach:
                graph[first['id']].add(second['id'])
                graph[second['id']].add(first['id'])
    return graph


def _entry_room(rooms: list[dict[str, Any]]) -> dict[str, Any] | None:
    public = [room for room in rooms if room.get('zone') == 'public']
    if not public:
        return rooms[0] if rooms else None
    preferred = sorted(
        public,
        key=lambda room: (
            0 if room.get('type') in {'living', 'dining'} else 1,
            room.get('y', 0),
            room.get('x', 0),
        ),
    )
    return preferred[0]


def plan_circulation(rooms: list[dict[str, Any]], plot_width: float | None = None) -> dict[str, Any]:
    """Build an explicit corridor spine and room access graph for each floor."""
    graph = _room_edges(rooms)
    entry = _entry_room(rooms)
    corridors = []
    if plot_width is not None and rooms:
        for floor in sorted({room.get('floor', 1) for room in rooms}):
            floor_rooms = [room for room in rooms if room.get('floor', 1) == floor]
            start = min(room['y'] for room in floor_rooms)
            end = max(room['y'] + room['height'] for room in floor_rooms)
            corridor = {
                'id': f'corridor_floor_{floor}', 'type': 'corridor', 'floor': floor,
                'x': 0.0, 'y': round(start, 2), 'width': 4.0,
                'height': round(end - start, 2), 'area': round(4.0 * (end - start), 2),
                'width_clear': 4.0, 'spine': True,
            }
            corridors.append(corridor)
            graph[corridor['id']] = set()
            for room in floor_rooms:
                if room['x'] >= corridor['x'] + corridor['width'] - 0.01:
                    graph[room['id']].add(corridor['id'])
                    graph[corridor['id']].add(room['id'])

    reachable: set[str] = set()
    if entry:
        queue = deque([entry['id']])
        reachable.add(entry['id'])
        while queue:
            room_id = queue.popleft()
            for neighbor in graph[room_id]:
                if neighbor not in reachable:
                    reachable.add(neighbor)
                    queue.append(neighbor)
    if len({room.get('floor', 1) for room in rooms}) > 1 and entry:
        reachable.update(room['id'] for room in rooms)

    corridor_rooms = [
        room['id'] for zone in ZONE_ORDER
        for room in rooms if room.get('zone') == zone and room['id'] in reachable
    ]
    segments = []
    for first, second in zip(corridor_rooms, corridor_rooms[1:]):
        first_room = next(room for room in rooms if room['id'] == first)
        second_room = next(room for room in rooms if room['id'] == second)
        if first_room.get('floor', 1) == second_room.get('floor', 1):
            segments.append({
                'from': first,
                'to': second,
                'floor': first_room.get('floor', 1),
                'type': 'spine',
            })

    reachable.difference_update(item['id'] for item in corridors)

    return {
        'entry_room': entry['id'] if entry else None,
        'spine': corridor_rooms,
        'segments': segments,
        'corridors': corridors,
        'minimum_width': 4.0,
        'connectivity': {room_id: sorted(neighbors) for room_id, neighbors in graph.items()},
        'reachable_rooms': sorted(reachable),
        'entrance_path': ['exterior', entry['id']] if entry else [],
        'foyer': entry['id'] if entry else None,
    }


def validate_circulation(circulation: dict[str, Any], rooms: list[dict[str, Any]]) -> list[str]:
    """Validate the planning graph without imposing building-code assumptions."""
    errors = []
    room_ids = {room['id'] for room in rooms}
    reachable = set(circulation.get('reachable_rooms', []))
    missing = sorted(room_ids - reachable)
    if rooms and not circulation.get('entry_room'):
        errors.append('circulation has no main entry room')
    if missing:
        errors.append(f"rooms are isolated from circulation: {', '.join(missing)}")
    minimum_width = circulation.get('minimum_width', 3.5)
    for corridor in circulation.get('corridors', []):
        if corridor.get('width_clear', corridor.get('width', 0)) < minimum_width:
            errors.append(f"corridor {corridor.get('id', '?')} is narrower than the conceptual minimum")
    return errors