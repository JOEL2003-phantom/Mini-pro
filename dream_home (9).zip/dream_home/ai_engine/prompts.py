"""Prompts used by the local Ollama requirement parser."""

SYSTEM_PROMPT = '''Return only compact JSON matching this exact shape, with no markdown or explanation:
{"plot":{"width":30,"length":50,"unit":"ft"},"rooms":{"bedrooms":2,"bathrooms":1,"kitchen":1,"living_room":1,"dining_room":1},"parking":0,"floors":1,"features":{"balcony":false,"utility_room":false,"work_study_room":false,"prayer_room":false,"storage_room":false,"garden_open_space":false},"style":"modern","style_other":"","budget":null,"additional_requirements":""}
Copy explicit user values. Use width 30 and length 50 when omitted. Set garden_open_space true for a garden and record its position; record stair count in additional_requirements. Output JSON only.'''


def build_prompt(requirements_text: str) -> str:
    return f'{SYSTEM_PROMPT}\n\nUser requirements:\n{requirements_text.strip()}'