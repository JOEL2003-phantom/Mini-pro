"""Small standard-library Ollama client and safe response parser."""

from __future__ import annotations

import json
import logging
import os
import re
import time
from json import JSONDecodeError
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from django.conf import settings

from .prompts import build_prompt
from .schema import HouseRequirements, SchemaError, normalize_requirements

logger = logging.getLogger(__name__)


class ParserError(ValueError):
    """Base error for local AI parsing failures."""

    def __init__(self, message: str, *, error_type: str = 'internal'):
        super().__init__(message)
        self.error_type = error_type


class OllamaUnavailableError(ParserError):
    """Base error for local Ollama availability issues."""

    def __init__(self, message: str, *, error_type: str = 'connection'):
        super().__init__(message, error_type=error_type)


class OllamaConnectionError(OllamaUnavailableError):
    """Raised when the local Ollama server cannot be reached."""

    def __init__(self, message: str = 'Cannot connect to the local AI service.'):
        super().__init__(message, error_type='connection')


class OllamaTimeoutError(OllamaUnavailableError):
    """Raised when the local model takes too long to respond."""

    def __init__(self, message: str = 'The local AI model took too long to respond.'):
        super().__init__(message, error_type='timeout')


class OllamaModelNotFoundError(ParserError):
    """Raised when the configured model does not exist in Ollama."""

    def __init__(self, message: str):
        super().__init__(message, error_type='model')


class OllamaResponseError(ParserError):
    """Raised when Ollama returns unusable raw content."""

    def __init__(self, message: str):
        super().__init__(message, error_type='parsing')


class OllamaAPIError(ParserError):
    """Raised when Ollama returns an HTTP or application-level API error."""

    def __init__(self, message: str):
        super().__init__(message, error_type='api')


class InvalidRequirementsError(ParserError):
    """Raised when generated JSON does not match the Dream Home schema."""

    def __init__(self, message: str):
        super().__init__(message, error_type='invalid_requirements')


def _strip_json_fence(response_text: str) -> str:
    text = response_text.strip()
    if not text:
        return text
    if text.startswith('```'):
        text = re.sub(r'^```(?:json)?\s*', '', text, flags=re.IGNORECASE)
        text = re.sub(r'\s*```\s*$', '', text, flags=re.IGNORECASE)
    return text.strip()


def _json_object(response_text: str) -> dict[str, Any]:
    text = _strip_json_fence(response_text)

    candidates: list[str] = []
    if text:
        candidates.append(text)
        match = re.search(r'\{.*\}', text, flags=re.DOTALL)
        if match:
            candidates.insert(0, match.group(0))

    last_error: JSONDecodeError | None = None
    for candidate in candidates:
        try:
            value = json.loads(candidate)
        except JSONDecodeError as error:
            last_error = error
            continue
        if isinstance(value, dict):
            return value
        raise ParserError("The local AI response must be a JSON object.")

    raise ParserError("The local AI returned invalid JSON.") from last_error


def parse_ollama_response(response_text: str) -> HouseRequirements:
    """Extract and validate one JSON object returned by Ollama."""

    try:
        return normalize_requirements(_json_object(response_text))
    except ParserError as error:
        raise OllamaResponseError('The AI returned an invalid requirement format.') from error
    except SchemaError as error:
        raise InvalidRequirementsError(str(error)) from error


class OllamaParser:

    def __init__(
        self,
        base_url: str | None = None,
        model: str | None = None,
        timeout: float | None = None,
        opener: Callable[..., Any] | None = None,
    ):
        self.base_url = (
            base_url
            or getattr(
                settings,
                "OLLAMA_BASE_URL",
                os.getenv(
                    "OLLAMA_BASE_URL",
                    "http://127.0.0.1:11434",
                ),
            )
        ).rstrip("/")

        self.model = (
            model
            or getattr(
                settings,
                "OLLAMA_MODEL",
                os.getenv("OLLAMA_MODEL", "qwen3:4b"),
            )
        )

        configured_timeout = timeout if timeout is not None else getattr(settings, 'OLLAMA_TIMEOUT_SECONDS', os.getenv('OLLAMA_TIMEOUT_SECONDS', '90'))
        self.timeout = float(configured_timeout)
        self.opener = opener or urlopen

    def _parse_response_payload(self, raw: str):
        text = raw.strip()
        if not text:
            raise OllamaResponseError("The local AI service returned an empty response.")

        try:
            value = json.loads(text)
            return value
        except JSONDecodeError:
            pass

        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if len(lines) > 1:
            parsed_chunks = []
            for line in lines:
                try:
                    chunk = json.loads(line)
                except JSONDecodeError:
                    continue
                if isinstance(chunk, dict):
                    parsed_chunks.append(chunk)
            if parsed_chunks:
                pieces = []
                for chunk in parsed_chunks:
                    if isinstance(chunk.get("error"), str):
                        raise ParserError(str(chunk["error"]))
                    response_value = chunk.get("response")
                    if isinstance(response_value, str):
                        pieces.append(response_value)
                assembled = ''.join(pieces)
                if assembled:
                    return {'response': assembled}
                raise OllamaResponseError("The local AI returned streamed output that could not be reconstructed.")

        match = re.search(r'\{.*\}', text, flags=re.DOTALL)
        if match:
            try:
                return json.loads(match.group(0))
            except JSONDecodeError as error:
                raise OllamaResponseError("The local AI response could not be parsed.") from error

        raise OllamaResponseError("The local AI response could not be parsed.")

    def _request_json(self, url: str, *, method: str = "GET", data: bytes | None = None):
        started = time.time()
        logger.info("AI REQUEST START: method=%s url=%s model=%s timeout=%ss", method, url, self.model, self.timeout)
        request = Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"} if data is not None else {},
            method=method,
        )
        try:
            with self.opener(request, timeout=self.timeout) as response:
                raw = response.read().decode("utf-8")
                duration = time.time() - started
                logger.info(
                    "OLLAMA HTTP STATUS: %s duration=%.2fs response_length=%s url=%s",
                    getattr(response, 'status', 'unknown'),
                    duration,
                    len(raw),
                    url,
                )
                logger.info("OLLAMA RESPONSE RECEIVED: %s", raw[:500])
                return self._parse_response_payload(raw)
        except HTTPError as error:
            duration = time.time() - started
            logger.exception("OLLAMA HTTP ERROR: status=%s duration=%.2fs url=%s model=%s", error.code, duration, url, self.model)
            try:
                error_body = json.loads(error.read().decode("utf-8"))
            except (JSONDecodeError, UnicodeDecodeError, OSError):
                error_body = None
            if isinstance(error_body, dict) and isinstance(error_body.get('error'), str):
                message = error_body['error']
                if 'model' in message.lower() and 'not found' in message.lower():
                    raise OllamaModelNotFoundError(f"The configured Ollama model '{self.model}' was not found.") from error
                raise OllamaAPIError(message) from error
            if error.code == 404:
                raise OllamaModelNotFoundError(f"The configured Ollama model '{self.model}' was not found.") from error
            raise OllamaAPIError(f"The local AI service returned HTTP {error.code}.") from error
        except TimeoutError as error:
            duration = time.time() - started
            logger.exception("AI request timed out against Ollama: model=%s url=%s duration=%.2fs", self.model, url, duration)
            raise OllamaTimeoutError("The local AI model is taking too long to respond. Please try again.") from error
        except (OSError, URLError) as error:
            duration = time.time() - started
            logger.exception("Ollama connection error: model=%s url=%s duration=%.2fs", self.model, url, duration)
            raise OllamaConnectionError("Cannot connect to the local AI service.") from error
        except (JSONDecodeError, UnicodeDecodeError) as error:
            duration = time.time() - started
            logger.exception("Ollama response was not valid UTF-8/JSON: model=%s url=%s duration=%.2fs", self.model, url, duration)
            raise OllamaResponseError("The local AI service returned an invalid response.") from error

    def _ensure_model_available(self) -> None:
        body = self._request_json(f"{self.base_url}/api/tags")
        if not isinstance(body, dict):
            logger.warning(
                "Ollama tags response was not a JSON object; skipping model availability check for %s",
                self.model,
            )
            return

        if 'models' not in body or not isinstance(body.get('models'), list):
            logger.warning(
                "Ollama tags response did not include a models list; skipping model availability check for %s",
                self.model,
            )
            return

        models = body['models']
        names = []
        for item in models:
            if isinstance(item, dict):
                name = item.get("name")
                if name:
                    names.append(name)
        normalized = [name.rstrip(":latest") for name in names]
        if self.model not in names and self.model not in normalized:
            raise OllamaModelNotFoundError(
                f"The configured Ollama model '{self.model}' was not found."
            )

    def parse(self, requirements_text: str) -> HouseRequirements:

        if not isinstance(requirements_text, str) or not requirements_text.strip():
            raise ParserError("House requirements text is required.")

        started = time.time()
        try:
            self._ensure_model_available()

            payload = json.dumps({
                "model": self.model,
                "prompt": build_prompt(requirements_text),
                "format": "json",
                "think": False,
                "options": {"temperature": 0, "num_predict": 192},
                "stream": False,
            }).encode("utf-8")

            logger.info("PARSER START: preparing generation request for %s prompt_length=%s", self.model, len(requirements_text))
            body = self._request_json(
                f"{self.base_url}/api/generate",
                method="POST",
                data=payload,
            )

            generated = body.get("response") if isinstance(body, dict) else None

            if isinstance(body, dict) and body.get("error"):
                raise ParserError(str(body["error"]))

            if not isinstance(generated, str):
                message = body.get("error") if isinstance(body, dict) else None
                raise ParserError(message or "The local AI service returned no generated content.")

            logger.info("PARSING START: parsing generated response length=%s model=%s", len(generated), self.model)
            result = parse_ollama_response(generated)
            logger.info("PARSING SUCCESS: model=%s total_duration=%.2fs", self.model, time.time() - started)
            return result
        except ParserError:
            logger.exception("PARSING FAILED: model=%s total_duration=%.2fs", self.model, time.time() - started)
            raise
        except Exception:
            logger.exception("Unexpected exception while parsing AI requirements via Ollama: model=%s total_duration=%.2fs", self.model, time.time() - started)
            raise ParserError("AI processing failed while parsing the local model response.") from None


def parse_requirements(text: str) -> HouseRequirements:
    return OllamaParser().parse(text)
            