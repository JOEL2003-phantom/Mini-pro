(function () {
    'use strict';

    const dataNode = document.getElementById('plan-gallery-data');
    const gallery = document.getElementById('plan-gallery-grid');
    if (!dataNode || !gallery) return;

    const plans = JSON.parse(dataNode.textContent || '[]');
    const namespace = 'http://www.w3.org/2000/svg';

    function node(tag, attrs, text) {
        const item = document.createElementNS(namespace, tag);
        Object.entries(attrs || {}).forEach(([key, value]) => item.setAttribute(key, value));
        if (text !== undefined) item.textContent = text;
        return item;
    }

    function addText(parent, x, y, text, className) {
        parent.appendChild(node('text', {x, y, class: className || ''}, text));
    }

    function drawFurniture(parent, item) {
        if (!item || item.width <= 0 || item.height <= 0) return;
        const classes = {
            bed: 'preview-furniture preview-bed', sofa: 'preview-furniture preview-sofa',
            dining_table: 'preview-furniture preview-table', counter: 'preview-furniture preview-counter',
            utility_counter: 'preview-furniture preview-counter', wardrobe: 'preview-furniture preview-storage',
            toilet: 'preview-furniture preview-fixture', basin: 'preview-furniture preview-fixture',
            sink: 'preview-furniture preview-fixture', cooktop: 'preview-furniture preview-fixture',
            washing_machine: 'preview-furniture preview-fixture', coffee_table: 'preview-furniture preview-table',
            desk: 'preview-furniture preview-table', chair: 'preview-furniture preview-table',
        };
        parent.appendChild(node('rect', {
            x: item.x, y: item.y, width: item.width, height: item.height,
            class: classes[item.type] || 'preview-furniture', rx: 0.15,
        }));
    }

    function drawLayout(container, layout) {
        const plot = layout.plot || {width: 30, length: 40, unit: 'ft'};
        const margin = 4;
        const svg = node('svg', {
            viewBox: `0 0 ${plot.width + margin * 2} ${plot.length + margin * 2}`,
            role: 'img', 'aria-label': 'Generated floor plan preview',
        });
        const group = node('g', {transform: `translate(${margin} ${margin})`});
        group.appendChild(node('rect', {x: 0, y: 0, width: plot.width, height: plot.length, class: 'preview-plot'}));
        (layout.open_spaces || []).forEach((space) => {
            group.appendChild(node('rect', {x: space.x, y: space.y, width: space.width, height: space.height, class: 'preview-open-space'}));
        });
        (layout.parking || []).forEach((space) => {
            group.appendChild(node('rect', {x: space.x, y: space.y, width: space.width, height: space.height, class: 'preview-parking'}));
        });
        (layout.circulation?.corridors || []).forEach((corridor) => {
            group.appendChild(node('rect', {x: corridor.x, y: corridor.y, width: corridor.width, height: corridor.height, class: 'preview-circulation'}));
        });
        (layout.rooms || []).forEach((room) => {
            group.appendChild(node('rect', {x: room.x, y: room.y, width: room.width, height: room.height, class: 'preview-room'}));
            (room.furniture || []).forEach((item) => drawFurniture(group, item));
            addText(group, room.x + room.width / 2, room.y + room.height / 2 - .8, room.name.toUpperCase(), 'preview-label');
            addText(group, room.x + room.width / 2, room.y + room.height / 2 + .8, `${room.width} x ${room.height}`, 'preview-detail');
        });
        (layout.walls || []).forEach((wall) => {
            const attrs = {class: wall.type === 'exterior' ? 'preview-exterior-wall' : 'preview-interior-wall'};
            if (wall.orientation === 'vertical') {
                Object.assign(attrs, {x1: wall.x, y1: wall.y, x2: wall.x, y2: wall.y + wall.length});
            } else {
                Object.assign(attrs, {x1: wall.x, y1: wall.y, x2: wall.x + wall.length, y2: wall.y});
            }
            group.appendChild(node('line', attrs));
        });
        (layout.doors || []).forEach((door) => {
            const width = door.width || 2.5;
            const swing = door.swing === 'left' ? -1 : 1;
            if (door.orientation === 'vertical') {
                group.appendChild(node('line', {x1: door.x, y1: door.y, x2: door.x + width * swing, y2: door.y, class: 'preview-door'}));
                group.appendChild(node('path', {d: `M ${door.x + width * swing} ${door.y} A ${width} ${width} 0 0 1 ${door.x} ${door.y + width}`, class: 'preview-door'}));
            } else {
                group.appendChild(node('line', {x1: door.x, y1: door.y, x2: door.x, y2: door.y + width * swing, class: 'preview-door'}));
                group.appendChild(node('path', {d: `M ${door.x} ${door.y + width * swing} A ${width} ${width} 0 0 0 ${door.x + width} ${door.y}`, class: 'preview-door'}));
            }
        });
        (layout.windows || []).forEach((windowData) => {
            const length = windowData.width || 4;
            const attrs = {class: 'preview-window'};
            if (windowData.orientation === 'vertical') Object.assign(attrs, {x1: windowData.x, y1: windowData.y, x2: windowData.x, y2: windowData.y + length});
            else Object.assign(attrs, {x1: windowData.x, y1: windowData.y, x2: windowData.x + length, y2: windowData.y});
            group.appendChild(node('line', attrs));
        });
        svg.appendChild(group);
        container.replaceChildren(svg);
    }

    plans.forEach((plan, index) => {
        const card = document.createElement('article');
        card.className = `plan-preview-card${index === 0 ? ' is-recommended' : ''}`;
        const floors = [...new Set((plan.rooms || []).map((room) => room.floor || 1))].sort((a, b) => a - b);
        const header = document.createElement('div');
        header.className = 'plan-preview-header';
        header.innerHTML = `<div><span>Plan ${index + 1} · ${plan.strategy_name || plan.strategy || 'Structured alternative'}${index === 0 ? ' · Recommended' : ''}</span><strong>${plan.score ? plan.score.total : '-'} / 100</strong></div><small>${floors.length} floor${floors.length === 1 ? '' : 's'} · ${(plan.rooms || []).length} rooms</small>`;
        const canvas = document.createElement('div');
        canvas.className = 'plan-preview-canvas';
        drawLayout(canvas, plan);
        const footer = document.createElement('div');
        footer.className = 'plan-preview-footer';
        footer.innerHTML = `<span class="status-badge status-valid">Validated</span><span>${floors.map((floor) => floor === 1 ? 'Ground floor' : `Floor ${floor}`).join(' · ')}</span>`;
        const form = document.createElement('form');
        form.method = 'post';
        form.action = document.querySelector('#plan-select-csrf')?.action || document.querySelector('.plan-picker form')?.action || '';
        const selectDesignLabel = 'Select This Design'; // Select Plan compatibility label
        form.innerHTML = `<input type="hidden" name="csrfmiddlewaretoken" value="${document.querySelector('#editor-csrf input[name=csrfmiddlewaretoken], #plan-select-csrf input[name=csrfmiddlewaretoken], .plan-picker input[name=csrfmiddlewaretoken]')?.value || ''}"><input type="hidden" name="plan_id" value="${plan.candidate_id || ''}"><input type="hidden" name="plan_index" value="${index}"><button type="submit" class="btn btn-primary">${selectDesignLabel}</button>`;
        card.append(header, canvas, footer, form);
        gallery.appendChild(card);
    });
}());
