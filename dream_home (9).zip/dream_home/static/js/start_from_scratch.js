(() => {
    const layoutNode = document.getElementById('recommended-layout');
    const viewport = document.getElementById('svg-viewport');
    if (!layoutNode || !viewport) return;

    const baseLayout = JSON.parse(layoutNode.textContent);
    let currentLayout = JSON.parse(JSON.stringify(baseLayout));
    let undoStack = [];
    let redoStack = [];
    let activeTool = 'select';
    let selectedType = 'plot';
    let selectedId = null;
    let pendingFurnitureType = 'bed';
    let dragState = null;
    const SVG_NS = 'http://www.w3.org/2000/svg';

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function ensureCollection(name, fallback) {
        if (!Array.isArray(currentLayout[name])) {
            currentLayout[name] = fallback || [];
        }
    }

    function ensureLayout() {
        const plot = currentLayout.plot || {width: 40, length: 50, unit: 'ft'};
        currentLayout.plot = plot;
        ensureCollection('rooms');
        ensureCollection('walls');
        ensureCollection('doors');
        ensureCollection('windows');
        ensureCollection('stairs');
        ensureCollection('parking');
        ensureCollection('open_spaces');
        ensureCollection('furniture');
        ensureCollection('dimensions');
        ensureCollection('annotations');
        if (!currentLayout.circulation || typeof currentLayout.circulation !== 'object') {
            currentLayout.circulation = {corridors: []};
        }
        if (!Array.isArray(currentLayout.circulation.corridors)) {
            currentLayout.circulation.corridors = [];
        }
        if (!Array.isArray(currentLayout.stair_arrivals)) {
            currentLayout.stair_arrivals = [];
        }
    }

    function setStatus(message, kind = 'info') {
        const status = document.getElementById('editor-status');
        if (status) {
            status.textContent = message;
            status.dataset.kind = kind;
        }
    }

    function csrfToken() {
        return document.querySelector('#editor-csrf input[name=csrfmiddlewaretoken]')?.value || '';
    }

    function designRoot() {
        return window.location.pathname.replace(/\/$/, '');
    }

    function nextId(prefix, collection) {
        const ids = collection.map((item) => item.id).filter(Boolean);
        let index = 1;
        while (ids.includes(`${prefix}_${index}`)) index += 1;
        return `${prefix}_${index}`;
    }

    function snapshot() {
        undoStack.push(clone(currentLayout));
        if (undoStack.length > 30) undoStack.shift();
        redoStack = [];
    }

    function revertFromSnapshot() {
        if (!undoStack.length) return;
        redoStack.push(clone(currentLayout));
        currentLayout = undoStack.pop();
        ensureLayout();
        render();
    }

    function redo() {
        if (!redoStack.length) return;
        undoStack.push(clone(currentLayout));
        currentLayout = redoStack.pop();
        ensureLayout();
        render();
    }

    function getSelectedObject() {
        if (!selectedType || !selectedId) return null;
        if (selectedType === 'plot') return {type: 'plot'};
        if (selectedType === 'room') return (currentLayout.rooms || []).find((item) => item.id === selectedId) || null;
        if (selectedType === 'wall') return (currentLayout.walls || []).find((item) => item.id === selectedId) || null;
        if (selectedType === 'door') return (currentLayout.doors || []).find((item) => item.id === selectedId) || null;
        if (selectedType === 'window') return (currentLayout.windows || []).find((item) => item.id === selectedId) || null;
        if (selectedType === 'stair') return (currentLayout.stairs || []).find((item) => item.id === selectedId) || null;
        if (selectedType === 'parking') return (currentLayout.parking || []).find((item) => item.id === selectedId) || null;
        if (selectedType === 'garden') return (currentLayout.open_spaces || []).find((item) => item.id === selectedId) || null;
        if (selectedType === 'walkway') return (currentLayout.circulation?.corridors || []).find((item) => item.id === selectedId) || null;
        if (selectedType === 'furniture') return (currentLayout.furniture || []).find((item) => item.id === selectedId) || null;
        if (selectedType === 'dimension') return (currentLayout.dimensions || []).find((item) => item.id === selectedId) || null;
        if (selectedType === 'text') return (currentLayout.annotations || []).find((item) => item.id === selectedId) || null;
        return null;
    }

    function addSvgElement(parent, tag, attrs = {}, text) {
        const node = document.createElementNS(SVG_NS, tag);
        Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, String(value)));
        if (text !== undefined) node.textContent = text;
        parent.appendChild(node);
        return node;
    }

    function plotOrigin() {
        return {x: 28, y: 28};
    }

    function planSize() {
        const plot = currentLayout.plot || {width: 40, length: 50, unit: 'ft'};
        return {width: plot.width + 56, height: plot.length + 56};
    }

    function screenToPlan(event) {
        const svg = viewport.querySelector('svg');
        if (!svg) return {x: 0, y: 0};
        const rect = svg.getBoundingClientRect();
        const viewBox = svg.viewBox.baseVal;
        const x = ((event.clientX - rect.left) / rect.width) * viewBox.width;
        const y = ((event.clientY - rect.top) / rect.height) * viewBox.height;
        const origin = plotOrigin();
        return {x: x - origin.x, y: y - origin.y};
    }

    function clamp(value, min, max) {
        return Math.min(Math.max(value, min), max);
    }

    function renderPlotBoundary(svg) {
        const plot = currentLayout.plot || {width: 40, length: 50, unit: 'ft'};
        const origin = plotOrigin();
        const boundary = addSvgElement(svg, 'rect', {
            x: origin.x,
            y: origin.y,
            width: plot.width,
            height: plot.length,
            class: 'scratch-plot-boundary',
            rx: 2,
        });
        boundary.style.cursor = 'pointer';
        boundary.addEventListener('pointerdown', (event) => {
            event.stopPropagation();
            selectedType = 'plot';
            selectedId = 'plot';
            syncInspector();
            setStatus('Plot selected. Adjust width, length, and unit in the inspector.', 'info');
        });
        const grid = addSvgElement(svg, 'rect', {
            x: origin.x,
            y: origin.y,
            width: plot.width,
            height: plot.length,
            class: 'scratch-grid',
            fill: 'url(#scratchGrid)'
        });
        grid.style.pointerEvents = 'none';
        const north = addSvgElement(svg, 'text', {
            x: origin.x + plot.width / 2,
            y: origin.y - 8,
            class: 'scratch-north-label',
            'text-anchor': 'middle'
        }, 'N');
        north.style.pointerEvents = 'none';
    }

    function renderRooms(svg) {
        const rooms = currentLayout.rooms || [];
        rooms.forEach((room) => {
            const group = addSvgElement(svg, 'g', {
                class: 'scratch-object scratch-room-object',
                'data-type': 'room',
                'data-id': room.id,
            });
            const rect = addSvgElement(group, 'rect', {
                x: room.x + plotOrigin().x,
                y: room.y + plotOrigin().y,
                width: room.width,
                height: room.height,
                rx: 2,
                class: selectedType === 'room' && selectedId === room.id ? 'scratch-room selected' : 'scratch-room',
            });
            rect.style.cursor = 'pointer';
            rect.addEventListener('pointerdown', (event) => {
                event.stopPropagation();
                if (activeTool === 'delete') {
                    deleteObject('room', room.id);
                    return;
                }
                if (activeTool === 'select') {
                    selectObject('room', room.id);
                    startMove(event, 'room', room.id);
                }
            });
            addSvgElement(group, 'text', {
                x: room.x + plotOrigin().x + room.width / 2,
                y: room.y + plotOrigin().y + room.height / 2,
                class: 'scratch-room-label',
                'text-anchor': 'middle',
                'dominant-baseline': 'middle'
            }, room.name || 'Room');
        });
    }

    function renderWalls(svg) {
        const walls = currentLayout.walls || [];
        walls.forEach((wall) => {
            const group = addSvgElement(svg, 'g', {
                class: 'scratch-object scratch-wall-object',
                'data-type': 'wall',
                'data-id': wall.id,
            });
            const isVertical = wall.orientation === 'vertical';
            const line = addSvgElement(group, 'line', {
                x1: wall.x + plotOrigin().x,
                y1: wall.y + plotOrigin().y,
                x2: isVertical ? wall.x + plotOrigin().x : wall.x + wall.length + plotOrigin().x,
                y2: isVertical ? wall.y + wall.length + plotOrigin().y : wall.y + plotOrigin().y,
                class: selectedType === 'wall' && selectedId === wall.id ? 'scratch-wall selected' : 'scratch-wall',
            });
            line.style.cursor = 'pointer';
            line.addEventListener('pointerdown', (event) => {
                event.stopPropagation();
                if (activeTool === 'delete') {
                    deleteObject('wall', wall.id);
                    return;
                }
                if (activeTool === 'select') {
                    selectObject('wall', wall.id);
                    startMove(event, 'wall', wall.id);
                }
            });
        });
    }

    function renderOpenSpaces(svg) {
        const spaces = currentLayout.open_spaces || [];
        spaces.forEach((space) => {
            const group = addSvgElement(svg, 'g', {
                class: 'scratch-object scratch-space-object',
                'data-type': 'garden',
                'data-id': space.id,
            });
            const rect = addSvgElement(group, 'rect', {
                x: space.x + plotOrigin().x,
                y: space.y + plotOrigin().y,
                width: space.width,
                height: space.height,
                class: selectedType === 'garden' && selectedId === space.id ? 'scratch-garden selected' : 'scratch-garden',
            });
            rect.style.cursor = 'pointer';
            rect.addEventListener('pointerdown', (event) => {
                event.stopPropagation();
                if (activeTool === 'delete') {
                    deleteObject('garden', space.id);
                    return;
                }
                if (activeTool === 'select') {
                    selectObject('garden', space.id);
                    startMove(event, 'garden', space.id);
                }
            });
            addSvgElement(group, 'text', {
                x: space.x + plotOrigin().x + space.width / 2,
                y: space.y + plotOrigin().y + space.height / 2,
                class: 'scratch-space-label',
                'text-anchor': 'middle',
                'dominant-baseline': 'middle'
            }, 'Garden');
        });
    }

    function renderParking(svg) {
        const items = currentLayout.parking || [];
        items.forEach((item) => {
            const group = addSvgElement(svg, 'g', {
                class: 'scratch-object scratch-parking-object',
                'data-type': 'parking',
                'data-id': item.id,
            });
            const rect = addSvgElement(group, 'rect', {
                x: item.x + plotOrigin().x,
                y: item.y + plotOrigin().y,
                width: item.width,
                height: item.height,
                class: selectedType === 'parking' && selectedId === item.id ? 'scratch-parking selected' : 'scratch-parking',
            });
            rect.style.cursor = 'pointer';
            rect.addEventListener('pointerdown', (event) => {
                event.stopPropagation();
                if (activeTool === 'delete') {
                    deleteObject('parking', item.id);
                    return;
                }
                if (activeTool === 'select') {
                    selectObject('parking', item.id);
                    startMove(event, 'parking', item.id);
                }
            });
        });
    }

    function renderWalkways(svg) {
        const items = currentLayout.circulation?.corridors || [];
        items.forEach((item) => {
            const group = addSvgElement(svg, 'g', {'data-type': 'walkway', 'data-id': item.id});
            const rect = addSvgElement(group, 'rect', {
                x: item.x + plotOrigin().x,
                y: item.y + plotOrigin().y,
                width: item.width,
                height: item.height,
                class: selectedType === 'walkway' && selectedId === item.id ? 'scratch-walkway selected' : 'scratch-walkway',
            });
            rect.style.cursor = 'pointer';
            rect.addEventListener('pointerdown', (event) => {
                event.stopPropagation();
                if (activeTool === 'delete') {
                    deleteObject('walkway', item.id);
                    return;
                }
                if (activeTool === 'select') {
                    selectObject('walkway', item.id);
                    startMove(event, 'walkway', item.id);
                }
            });
        });
    }

    function renderDoors(svg) {
        const doors = currentLayout.doors || [];
        doors.forEach((door) => {
            const group = addSvgElement(svg, 'g', {'data-type': 'door', 'data-id': door.id});
            const x = door.x + plotOrigin().x;
            const y = door.y + plotOrigin().y;
            const line = addSvgElement(group, 'line', {
                x1: x,
                y1: y,
                x2: door.orientation === 'vertical' ? x : x + (door.width || 2.5),
                y2: door.orientation === 'vertical' ? y + (door.width || 2.5) : y,
                class: selectedType === 'door' && selectedId === door.id ? 'scratch-door selected' : 'scratch-door',
            });
            line.style.cursor = 'pointer';
            line.addEventListener('pointerdown', (event) => {
                event.stopPropagation();
                if (activeTool === 'delete') {
                    deleteObject('door', door.id);
                    return;
                }
                if (activeTool === 'select') {
                    selectObject('door', door.id);
                    startMove(event, 'door', door.id);
                }
            });
        });
    }

    function renderWindows(svg) {
        const windows = currentLayout.windows || [];
        windows.forEach((windowItem) => {
            const group = addSvgElement(svg, 'g', {'data-type': 'window', 'data-id': windowItem.id});
            const x = windowItem.x + plotOrigin().x;
            const y = windowItem.y + plotOrigin().y;
            const line = addSvgElement(group, 'line', {
                x1: x,
                y1: y,
                x2: windowItem.orientation === 'vertical' ? x : x + (windowItem.width || 3),
                y2: windowItem.orientation === 'vertical' ? y + (windowItem.width || 3) : y,
                class: selectedType === 'window' && selectedId === windowItem.id ? 'scratch-window selected' : 'scratch-window',
            });
            line.style.cursor = 'pointer';
            line.addEventListener('pointerdown', (event) => {
                event.stopPropagation();
                if (activeTool === 'delete') {
                    deleteObject('window', windowItem.id);
                    return;
                }
                if (activeTool === 'select') {
                    selectObject('window', windowItem.id);
                    startMove(event, 'window', windowItem.id);
                }
            });
        });
    }

    function renderStairs(svg) {
        const stairs = currentLayout.stairs || [];
        stairs.forEach((stair) => {
            const group = addSvgElement(svg, 'g', {'data-type': 'stair', 'data-id': stair.id});
            const rect = addSvgElement(group, 'rect', {
                x: stair.x + plotOrigin().x,
                y: stair.y + plotOrigin().y,
                width: stair.width,
                height: stair.height,
                class: selectedType === 'stair' && selectedId === stair.id ? 'scratch-stair selected' : 'scratch-stair',
            });
            rect.style.cursor = 'pointer';
            rect.addEventListener('pointerdown', (event) => {
                event.stopPropagation();
                if (activeTool === 'delete') {
                    deleteObject('stair', stair.id);
                    return;
                }
                if (activeTool === 'select') {
                    selectObject('stair', stair.id);
                    startMove(event, 'stair', stair.id);
                }
            });
        });
    }

    function renderFurniture(svg) {
        const furniture = currentLayout.furniture || [];
        furniture.forEach((item) => {
            const group = addSvgElement(svg, 'g', {'data-type': 'furniture', 'data-id': item.id});
            const rect = addSvgElement(group, 'rect', {
                x: item.x + plotOrigin().x,
                y: item.y + plotOrigin().y,
                width: item.width,
                height: item.height,
                class: selectedType === 'furniture' && selectedId === item.id ? 'scratch-furniture selected' : 'scratch-furniture',
            });
            rect.style.cursor = 'pointer';
            rect.addEventListener('pointerdown', (event) => {
                event.stopPropagation();
                if (activeTool === 'delete') {
                    deleteObject('furniture', item.id);
                    return;
                }
                if (activeTool === 'select') {
                    selectObject('furniture', item.id);
                    startMove(event, 'furniture', item.id);
                }
            });
            addSvgElement(group, 'text', {
                x: item.x + plotOrigin().x + item.width / 2,
                y: item.y + plotOrigin().y + item.height / 2,
                class: 'scratch-furniture-label',
                'text-anchor': 'middle',
                'dominant-baseline': 'middle'
            }, item.type || 'Item');
        });
    }

    function renderDimensions(svg) {
        const dimensions = currentLayout.dimensions || [];
        dimensions.forEach((dimension) => {
            const group = addSvgElement(svg, 'g', {'data-type': 'dimension', 'data-id': dimension.id});
            const x1 = dimension.x1 || dimension.x + plotOrigin().x;
            const y1 = dimension.y1 || dimension.y + plotOrigin().y;
            const x2 = dimension.x2 || dimension.x + plotOrigin().x + (dimension.width || 0);
            const y2 = dimension.y2 || dimension.y + plotOrigin().y + (dimension.height || 0);
            addSvgElement(group, 'line', {
                x1,
                y1,
                x2,
                y2,
                class: 'scratch-dimension-line',
            });
            const midX = (x1 + x2) / 2;
            const midY = (y1 + y2) / 2;
            addSvgElement(group, 'text', {
                x: midX,
                y: midY,
                class: 'scratch-dimension-label',
                'text-anchor': 'middle'
            }, dimension.label || '');
        });
    }

    function renderAnnotations(svg) {
        const list = currentLayout.annotations || [];
        list.forEach((annotation) => {
            addSvgElement(svg, 'text', {
                x: annotation.x + plotOrigin().x,
                y: annotation.y + plotOrigin().y,
                class: 'scratch-annotation-label',
            }, annotation.text || 'Label');
        });
    }

    function renderPreview(svg) {
        if (!dragState || !dragState.current) return;
        const origin = plotOrigin();
        if (dragState.kind === 'room' || dragState.kind === 'garden' || dragState.kind === 'parking' || dragState.kind === 'walkway' || dragState.kind === 'stair') {
            const rect = dragState.current;
            addSvgElement(svg, 'rect', {
                x: rect.x + origin.x,
                y: rect.y + origin.y,
                width: rect.width,
                height: rect.height,
                class: 'scratch-preview',
                fill: 'rgba(27, 117, 255, 0.15)',
                stroke: '#1b75ff',
                'stroke-dasharray': '4 4',
            });
        }
        if (dragState.kind === 'wall') {
            const line = dragState.current;
            addSvgElement(svg, 'line', {
                x1: line.x1 + origin.x,
                y1: line.y1 + origin.y,
                x2: line.x2 + origin.x,
                y2: line.y2 + origin.y,
                class: 'scratch-preview-wall',
            });
        }
    }

    function render() {
        ensureLayout();
        viewport.innerHTML = '';
        const plot = currentLayout.plot || {width: 40, length: 50, unit: 'ft'};
        const {width, height} = planSize();
        const svg = addSvgElement(viewport, 'svg', {
            viewBox: `0 0 ${width} ${height}`,
            role: 'img',
            'aria-label': 'Scratch floor plan canvas'
        });
        const defs = addSvgElement(svg, 'defs');
        const grid = addSvgElement(defs, 'pattern', {
            id: 'scratchGrid', width: 10, height: 10, patternUnits: 'userSpaceOnUse'
        });
        addSvgElement(grid, 'path', {d: 'M 10 0 L 0 0 0 10', fill: 'none', stroke: '#dfe7f3', 'stroke-width': '0.6'});
        renderPlotBoundary(svg);
        renderOpenSpaces(svg);
        renderParking(svg);
        renderWalkways(svg);
        renderWalls(svg);
        renderRooms(svg);
        renderDoors(svg);
        renderWindows(svg);
        renderStairs(svg);
        renderFurniture(svg);
        renderDimensions(svg);
        renderAnnotations(svg);
        renderPreview(svg);
        bindCanvasInteractions(svg);
        syncSummary();
        syncInspector();
    }

    function bindCanvasInteractions(svg) {
        svg.addEventListener('pointerdown', (event) => {
            if (activeTool === 'select') {
                if (event.target === svg || event.target.tagName === 'svg' || event.target.classList.contains('scratch-grid')) {
                    selectedType = 'plot';
                    selectedId = 'plot';
                    syncInspector();
                    setStatus('Plot selected. Adjust dimensions from the inspector.', 'info');
                }
                return;
            }
            const point = screenToPlan(event);
            if (activeTool === 'plot') {
                selectedType = 'plot';
                selectedId = 'plot';
                syncInspector();
                setStatus('Plot selected. Edit width, length, and unit below.', 'info');
                return;
            }
            if (activeTool === 'delete') {
                setStatus('Delete tool is active. Click an object to remove it.', 'warning');
                return;
            }
            if (activeTool === 'room') {
                const rect = {x: point.x, y: point.y, width: 12, height: 12};
                dragState = {kind: 'room', current: rect};
                return;
            }
            if (activeTool === 'garden') {
                dragState = {kind: 'garden', current: {x: point.x, y: point.y, width: 10, height: 10}};
                return;
            }
            if (activeTool === 'parking') {
                dragState = {kind: 'parking', current: {x: point.x, y: point.y, width: 10, height: 18}};
                return;
            }
            if (activeTool === 'walkway') {
                dragState = {kind: 'walkway', current: {x: point.x, y: point.y, width: 4, height: 10}};
                return;
            }
            if (activeTool === 'stair') {
                dragState = {kind: 'stair', current: {x: point.x, y: point.y, width: 8, height: 12}};
                return;
            }
            if (activeTool === 'wall') {
                dragState = {kind: 'wall', current: {x1: point.x, y1: point.y, x2: point.x, y2: point.y}};
                return;
            }
            if (activeTool === 'door') {
                const hitWall = findWallAtPoint(point);
                if (!hitWall) {
                    setStatus('Draw a wall first to place a door.', 'warning');
                    return;
                }
                const door = {
                    id: nextId('door', currentLayout.doors),
                    type: 'door',
                    x: hitWall.x,
                    y: hitWall.y,
                    width: 2.5,
                    height: 0.5,
                    orientation: hitWall.orientation || 'horizontal',
                    swing: 'right',
                    floor: 1,
                    room_id: hitWall.rooms?.[0] || null,
                    wall_id: hitWall.id,
                };
                currentLayout.doors.push(door);
                selectedType = 'door';
                selectedId = door.id;
                setStatus('Door placed on the selected wall.', 'success');
                render();
                return;
            }
            if (activeTool === 'window') {
                const hitWall = findWallAtPoint(point);
                if (!hitWall) {
                    setStatus('Draw a wall first to place a window.', 'warning');
                    return;
                }
                const windowItem = {
                    id: nextId('window', currentLayout.windows),
                    type: 'window',
                    x: hitWall.x,
                    y: hitWall.y,
                    width: 3,
                    height: 0.5,
                    orientation: hitWall.orientation || 'horizontal',
                    floor: 1,
                    room_id: hitWall.rooms?.[0] || null,
                    wall_id: hitWall.id,
                };
                currentLayout.windows.push(windowItem);
                selectedType = 'window';
                selectedId = windowItem.id;
                setStatus('Window placed on the selected wall.', 'success');
                render();
                return;
            }
            if (activeTool === 'furniture') {
                const item = createFurnitureObject(point.x, point.y, pendingFurnitureType);
                currentLayout.furniture.push(item);
                selectedType = 'furniture';
                selectedId = item.id;
                setStatus(`${pendingFurnitureType.replace('_', ' ')} placed on the canvas.`, 'success');
                render();
            }
        });

        svg.addEventListener('pointermove', (event) => {
            if (!dragState) return;
            const point = screenToPlan(event);
            if (dragState.kind === 'room' || dragState.kind === 'garden' || dragState.kind === 'parking' || dragState.kind === 'walkway' || dragState.kind === 'stair') {
                const start = dragState.current;
                const x = Math.min(start.x, point.x);
                const y = Math.min(start.y, point.y);
                const w = Math.abs(point.x - start.x);
                const h = Math.abs(point.y - start.y);
                dragState.current = {x, y, width: Math.max(2, w), height: Math.max(2, h)};
                render();
                return;
            }
            if (dragState.kind === 'wall') {
                const start = dragState.current;
                const x2 = point.x;
                const y2 = point.y;
                const dx = x2 - start.x1;
                const dy = y2 - start.y1;
                const horizontal = Math.abs(dx) >= Math.abs(dy);
                dragState.current = {
                    x1: start.x1,
                    y1: start.y1,
                    x2: horizontal ? x2 : start.x1,
                    y2: horizontal ? start.y1 : y2,
                };
                render();
            }
        });

        svg.addEventListener('pointerup', () => {
            if (!dragState) return;
            const kind = dragState.kind;
            const geom = dragState.current;
            dragState = null;
            if (kind === 'room') {
                const room = {
                    id: nextId('room', currentLayout.rooms),
                    name: `Room ${currentLayout.rooms.length + 1}`,
                    type: 'room',
                    x: geom.x,
                    y: geom.y,
                    width: Math.max(6, geom.width),
                    height: Math.max(6, geom.height),
                    floor: 1,
                    area: Math.round(Math.max(6, geom.width) * Math.max(6, geom.height) * 100) / 100,
                };
                currentLayout.rooms.push(room);
                selectedType = 'room';
                selectedId = room.id;
                setStatus('Room created on the canvas. Resize it using the inspector.', 'success');
                render();
                return;
            }
            if (kind === 'garden') {
                const item = {
                    id: nextId('garden', currentLayout.open_spaces),
                    type: 'garden',
                    x: geom.x,
                    y: geom.y,
                    width: Math.max(6, geom.width),
                    height: Math.max(6, geom.height),
                    floor: 1,
                };
                currentLayout.open_spaces.push(item);
                selectedType = 'garden';
                selectedId = item.id;
                setStatus('Garden created inside the plot.', 'success');
                render();
                return;
            }
            if (kind === 'parking') {
                const item = {
                    id: nextId('parking', currentLayout.parking),
                    type: 'parking',
                    x: geom.x,
                    y: geom.y,
                    width: Math.max(5, geom.width),
                    height: Math.max(8, geom.height),
                    floor: 1,
                };
                currentLayout.parking.push(item);
                selectedType = 'parking';
                selectedId = item.id;
                setStatus('Parking area created.', 'success');
                render();
                return;
            }
            if (kind === 'walkway') {
                const item = {
                    id: nextId('walkway', currentLayout.circulation.corridors),
                    type: 'walkway',
                    x: geom.x,
                    y: geom.y,
                    width: Math.max(2, geom.width),
                    height: Math.max(4, geom.height),
                    floor: 1,
                };
                currentLayout.circulation.corridors.push(item);
                selectedType = 'walkway';
                selectedId = item.id;
                setStatus('Walkway created.', 'success');
                render();
                return;
            }
            if (kind === 'stair') {
                const item = {
                    id: nextId('stair', currentLayout.stairs),
                    type: 'stair',
                    x: geom.x,
                    y: geom.y,
                    width: Math.max(6, geom.width),
                    height: Math.max(8, geom.height),
                    steps: 8,
                    floor: 1,
                };
                currentLayout.stairs.push(item);
                selectedType = 'stair';
                selectedId = item.id;
                setStatus('Stair created and ready to edit.', 'success');
                render();
                return;
            }
            if (kind === 'wall') {
                const full = Math.hypot(geom.x2 - geom.x1, geom.y2 - geom.y1);
                if (full < 2) {
                    setStatus('Drag farther to create a wall.', 'warning');
                    render();
                    return;
                }
                const wall = {
                    id: nextId('wall', currentLayout.walls),
                    type: 'wall',
                    floor: 1,
                    orientation: Math.abs(geom.x2 - geom.x1) >= Math.abs(geom.y2 - geom.y1) ? 'horizontal' : 'vertical',
                    x: Math.min(geom.x1, geom.x2),
                    y: Math.min(geom.y1, geom.y2),
                    length: Math.max(3, full),
                    thickness: 0.25,
                    rooms: [],
                };
                currentLayout.walls.push(wall);
                selectedType = 'wall';
                selectedId = wall.id;
                setStatus('Wall created. Use the inspector to fine-tune it.', 'success');
                render();
            }
        });
    }

    function findWallAtPoint(point) {
        const walls = currentLayout.walls || [];
        const origin = plotOrigin();
        return walls.find((wall) => {
            const x1 = wall.x + origin.x;
            const y1 = wall.y + origin.y;
            const x2 = wall.orientation === 'vertical' ? wall.x + origin.x : wall.x + wall.length + origin.x;
            const y2 = wall.orientation === 'vertical' ? wall.y + wall.length + origin.y : wall.y + origin.y;
            const px = point.x + origin.x;
            const py = point.y + origin.y;
            const near = Math.min(Math.hypot(px - x1, py - y1), Math.hypot(px - x2, py - y2));
            return near < 3;
        });
    }

    function createFurnitureObject(x, y, kind) {
        const defaults = {
            bed: {width: 6, height: 7, label: 'Bed'},
            sofa: {width: 6, height: 3.5, label: 'Sofa'},
            dining_table: {width: 5, height: 5, label: 'Dining Table'},
            chair: {width: 2, height: 2, label: 'Chair'},
            wardrobe: {width: 2.5, height: 5.5, label: 'Wardrobe'},
            sink: {width: 2, height: 2, label: 'Sink'},
            cooktop: {width: 2, height: 2, label: 'Cooktop'},
            refrigerator: {width: 2, height: 3, label: 'Refrigerator'},
            washing_machine: {width: 2.2, height: 2.2, label: 'Washing Machine'},
            desk: {width: 4, height: 2, label: 'Desk'},
            storage: {width: 3, height: 2, label: 'Storage'},
            toilet: {width: 2.2, height: 2.2, label: 'Toilet'},
            shower: {width: 3, height: 3, label: 'Shower'},
            bathtub: {width: 5, height: 3, label: 'Bathtub'},
            tv: {width: 4, height: 2, label: 'TV'},
            tv_unit: {width: 4, height: 2, label: 'TV Unit'},
            kitchen_counter: {width: 6, height: 2, label: 'Counter'},
        };
        const config = defaults[kind] || defaults.bed;
        return {
            id: nextId(kind, currentLayout.furniture),
            type: kind,
            x,
            y,
            width: config.width,
            height: config.height,
            floor: 1,
            rotation: 0,
        };
    }

    function selectObject(type, id) {
        selectedType = type;
        selectedId = id;
        syncInspector();
    }

    function syncSummary() {
        const plot = currentLayout.plot || {width: 40, length: 50, unit: 'ft'};
        const roomCount = currentLayout.rooms?.length || 0;
        document.getElementById('plot-summary').textContent = `${plot.width} × ${plot.length} ${plot.unit}`;
        document.getElementById('room-count').textContent = `${roomCount} rooms`;
        document.getElementById('scale-summary').textContent = 'Architectural scale';
        document.getElementById('layout-score').textContent = '-';
        document.getElementById('candidate-name').textContent = 'Manual';
        const validation = document.getElementById('validation-message');
        const warnings = document.getElementById('warning-list');
        validation.textContent = 'Scratch mode is live and editable.';
        warnings.innerHTML = '';
    }

    function syncInspector() {
        const inspector = document.getElementById('room-inspector');
        const item = getSelectedObject();
        if (!inspector || !item) {
            if (inspector) inspector.hidden = true;
            return;
        }
        inspector.hidden = false;
        const label = selectedType === 'plot' ? 'Plot' : selectedType.charAt(0).toUpperCase() + selectedType.slice(1);
        document.getElementById('inspector-title').textContent = `Selected ${label}`;
        document.getElementById('selected-room-name').textContent = item.name || item.type || 'Plot';

        const xField = document.getElementById('element-x');
        const yField = document.getElementById('element-y');
        const widthField = document.getElementById('element-width');
        const heightField = document.getElementById('element-height');
        const orientationField = document.getElementById('element-orientation');
        const swingField = document.getElementById('element-swing');
        const widthLabel = document.getElementById('element-width-label');
        const heightLabel = document.getElementById('element-height-label');
        const orientationLabel = document.getElementById('element-orientation-label');
        const swingLabel = document.getElementById('element-swing-label');

        xField.value = Number.isFinite(item.x) ? item.x : 0;
        yField.value = Number.isFinite(item.y) ? item.y : 0;

        if (selectedType === 'plot') {
            widthField.value = currentLayout.plot.width;
            heightField.value = currentLayout.plot.length;
            widthLabel.hidden = false;
            heightLabel.hidden = false;
            orientationLabel.hidden = true;
            swingLabel.hidden = true;
            widthLabel.querySelector('span, label')?.remove();
            widthLabel.childNodes[0].nodeValue = 'Width ';
            heightLabel.childNodes[0].nodeValue = 'Length ';
            return;
        }

        if (selectedType === 'wall') {
            widthField.value = item.length || 6;
            heightField.value = item.thickness || 0.25;
            widthLabel.hidden = false;
            heightLabel.hidden = false;
            orientationLabel.hidden = false;
            swingLabel.hidden = true;
            widthLabel.querySelector('span, label')?.remove();
            widthLabel.childNodes[0].nodeValue = 'Length ';
            heightLabel.childNodes[0].nodeValue = 'Thickness ';
            orientationField.value = item.orientation || 'horizontal';
            return;
        }

        if (selectedType === 'door' || selectedType === 'window') {
            widthField.value = item.width || 3;
            heightField.value = item.height || 0.5;
            widthLabel.hidden = false;
            heightLabel.hidden = true;
            orientationLabel.hidden = false;
            swingLabel.hidden = selectedType !== 'door';
            orientationField.value = item.orientation || 'horizontal';
            if (selectedType === 'door') swingField.value = item.swing || 'right';
            return;
        }

        if (selectedType === 'stair') {
            widthField.value = item.width || 8;
            heightField.value = item.height || 12;
            widthLabel.hidden = false;
            heightLabel.hidden = false;
            orientationLabel.hidden = false;
            swingLabel.hidden = true;
            widthLabel.querySelector('span, label')?.remove();
            widthLabel.childNodes[0].nodeValue = 'Width ';
            heightLabel.childNodes[0].nodeValue = 'Height ';
            return;
        }

        widthField.value = item.width || 10;
        heightField.value = item.height || 10;
        widthLabel.hidden = false;
        heightLabel.hidden = false;
        orientationLabel.hidden = true;
        swingLabel.hidden = true;
        widthLabel.querySelector('span, label')?.remove();
        heightLabel.querySelector('span, label')?.remove();
        widthLabel.childNodes[0].nodeValue = 'Width ';
        heightLabel.childNodes[0].nodeValue = 'Height ';
    }

    function startMove(event, type, id) {
        const item = getSelectedObject();
        if (!item) return;
        snapshot();
        const point = screenToPlan(event);
        dragState = {
            mode: 'move',
            type,
            id,
            start: point,
            origin: {x: item.x || 0, y: item.y || 0},
        };
        event.preventDefault();
        window.addEventListener('pointermove', onPointerMove);
        window.addEventListener('pointerup', onPointerUp, {once: true});
    }

    function onPointerMove(event) {
        if (!dragState || dragState.mode !== 'move') return;
        const point = screenToPlan(event);
        const item = getSelectedObject();
        if (!item) return;
        const dx = point.x - dragState.start.x;
        const dy = point.y - dragState.start.y;
        item.x = clamp(dragState.origin.x + dx, 0, currentLayout.plot.width);
        item.y = clamp(dragState.origin.y + dy, 0, currentLayout.plot.length);
        render();
    }

    function onPointerUp() {
        dragState = null;
        window.removeEventListener('pointermove', onPointerMove);
        setStatus('Object moved in the current layout.', 'success');
    }

    function deleteObject(type, id) {
        snapshot();
        if (type === 'room') {
            currentLayout.rooms = currentLayout.rooms.filter((item) => item.id !== id);
        } else if (type === 'wall') {
            currentLayout.walls = currentLayout.walls.filter((item) => item.id !== id);
        } else if (type === 'door') {
            currentLayout.doors = currentLayout.doors.filter((item) => item.id !== id);
        } else if (type === 'window') {
            currentLayout.windows = currentLayout.windows.filter((item) => item.id !== id);
        } else if (type === 'stair') {
            currentLayout.stairs = currentLayout.stairs.filter((item) => item.id !== id);
        } else if (type === 'parking') {
            currentLayout.parking = currentLayout.parking.filter((item) => item.id !== id);
        } else if (type === 'garden') {
            currentLayout.open_spaces = currentLayout.open_spaces.filter((item) => item.id !== id);
        } else if (type === 'walkway') {
            currentLayout.circulation.corridors = currentLayout.circulation.corridors.filter((item) => item.id !== id);
        } else if (type === 'furniture') {
            currentLayout.furniture = currentLayout.furniture.filter((item) => item.id !== id);
        } else if (type === 'dimension') {
            currentLayout.dimensions = currentLayout.dimensions.filter((item) => item.id !== id);
        } else if (type === 'text') {
            currentLayout.annotations = currentLayout.annotations.filter((item) => item.id !== id);
        }
        selectedType = 'plot';
        selectedId = 'plot';
        render();
        setStatus('Selected object removed from the scratch layout.', 'success');
    }

    async function requestEvaluation() {
        try {
            const response = await fetch(`${designRoot()}/validate/`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': csrfToken(),
                },
                body: JSON.stringify({layout: currentLayout}),
            });
            return await response.json();
        } catch (error) {
            return {success: false, errors: ['The scratch editor could not validate the layout.']};
        }
    }

    async function saveCurrentLayout() {
        const response = await fetch(`${designRoot()}/save-layout/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken(),
            },
            body: JSON.stringify({layout: currentLayout}),
        });
        const result = await response.json();
        if (result.success && result.layout) currentLayout = result.layout;
        return result;
    }

    function applyInspectorChanges() {
        const item = getSelectedObject();
        if (!item) return;
        if (selectedType === 'plot') {
            currentLayout.plot.width = Number(document.getElementById('element-width').value) || currentLayout.plot.width;
            currentLayout.plot.length = Number(document.getElementById('element-height').value) || currentLayout.plot.length;
            currentLayout.plot.unit = currentLayout.plot.unit || 'ft';
            render();
            setStatus('Plot updated. Objects remain in place where possible.', 'success');
            return;
        }
        item.x = Number(document.getElementById('element-x').value) || item.x || 0;
        item.y = Number(document.getElementById('element-y').value) || item.y || 0;
        if (selectedType === 'wall') {
            item.length = Number(document.getElementById('element-width').value) || item.length || 5;
            item.thickness = Number(document.getElementById('element-height').value) || item.thickness || 0.25;
            item.orientation = document.getElementById('element-orientation').value || item.orientation || 'horizontal';
        } else if (selectedType === 'door' || selectedType === 'window') {
            item.width = Number(document.getElementById('element-width').value) || item.width || 3;
            item.orientation = document.getElementById('element-orientation').value || item.orientation || 'horizontal';
            if (selectedType === 'door') item.swing = document.getElementById('element-swing').value || item.swing || 'right';
        } else {
            item.width = Number(document.getElementById('element-width').value) || item.width || 10;
            item.height = Number(document.getElementById('element-height').value) || item.height || 10;
        }
        render();
        setStatus('Inspector changes applied.', 'success');
    }

    function resetScratch() {
        snapshot();
        const plot = currentLayout.plot || {width: 40, length: 50, unit: 'ft'};
        currentLayout = {
            plot: {width: plot.width, length: plot.length, unit: plot.unit || 'ft'},
            rooms: [],
            walls: [],
            doors: [],
            windows: [],
            stairs: [],
            parking: [],
            open_spaces: [],
            furniture: [],
            dimensions: [],
            annotations: [],
            circulation: {corridors: []},
            stair_arrivals: [],
        };
        selectedType = 'plot';
        selectedId = 'plot';
        render();
        setStatus('Scratch canvas reset to empty plot.', 'success');
    }

    function bindToolbar() {
        document.querySelectorAll('.toolbar-tool[data-tool]').forEach((button) => {
            button.addEventListener('click', () => {
                activeTool = button.dataset.tool;
                document.querySelectorAll('.toolbar-tool[data-tool]').forEach((candidate) => {
                    const active = candidate === button;
                    candidate.setAttribute('aria-pressed', String(active));
                    candidate.classList.toggle('is-active', active);
                });
                const statusMap = {
                    select: 'Select an object to edit or drag it into place.',
                    wall: 'Click and drag on the plot to draw a wall.',
                    room: 'Click and drag on the plot to create a room.',
                    door: 'Click a wall to place a door.',
                    window: 'Click a wall to place a window.',
                    stair: 'Click and drag to create a stair run.',
                    furniture: 'Choose a furniture type, then place it on the canvas.',
                    parking: 'Click and drag inside the plot to create a parking bay.',
                    garden: 'Click and drag inside the plot to create a garden.',
                    walkway: 'Click and drag to create a walkway.',
                    dimension: 'Click two points to create a dimension line.',
                    text: 'Click the canvas to place text.',
                    delete: 'Delete tool active. Click an object to remove it.'
                };
                setStatus(statusMap[activeTool] || 'Tool activated.', 'info');
            });
        });

        document.querySelector('[data-editor-action="undo"]')?.addEventListener('click', () => {
            revertFromSnapshot();
            setStatus('Undo applied to the current layout.', 'success');
        });
        document.querySelector('[data-editor-action="redo"]')?.addEventListener('click', () => {
            redo();
            setStatus('Redo applied to the current layout.', 'success');
        });
        document.querySelector('[data-editor-action="reset"]')?.addEventListener('click', resetScratch);
        document.querySelector('[data-editor-action="save"]')?.addEventListener('click', async () => {
            const result = await saveCurrentLayout();
            setStatus(result.success ? 'Changes saved successfully.' : (result.errors || ['Save failed.']).join(' '), result.success ? 'success' : 'error');
        });
        document.getElementById('export-scratch-design')?.addEventListener('click', async () => {
            const result = await saveCurrentLayout();
            if (!result.success) {
                setStatus(result.errors || ['The layout could not be exported right now.'], 'error');
                return;
            }
            window.location.href = `${designRoot()}/export.svg`;
        });
        document.querySelector('[data-zoom="in"]')?.addEventListener('click', () => {
            viewport.style.setProperty('--plan-zoom', '1.15');
        });
        document.querySelector('[data-zoom="out"]')?.addEventListener('click', () => {
            viewport.style.setProperty('--plan-zoom', '0.85');
        });
        document.querySelector('[data-zoom="reset"]')?.addEventListener('click', () => {
            viewport.style.setProperty('--plan-zoom', '1');
        });
        document.getElementById('apply-element-changes')?.addEventListener('click', applyInspectorChanges);
        document.getElementById('delete-selected-element')?.addEventListener('click', () => {
            const item = getSelectedObject();
            if (!item) return;
            const type = selectedType;
            if (type === 'plot') {
                setStatus('The plot can not be removed. Only the objects inside it can be deleted.', 'warning');
                return;
            }
            deleteObject(type, selectedId);
        });

        document.querySelectorAll('[data-furniture]').forEach((button) => {
            button.addEventListener('click', () => {
                pendingFurnitureType = button.dataset.furniture;
                activeTool = 'furniture';
                setStatus(`${pendingFurnitureType.replace('_', ' ')} selected. Click to place it on the canvas.`, 'info');
            });
        });
    }

    ensureLayout();
    render();
    bindToolbar();
    selectedType = 'plot';
    selectedId = 'plot';
    syncInspector();
    setStatus('Select a tool and draw on the plot.', 'info');
})();
