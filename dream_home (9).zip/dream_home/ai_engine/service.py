"""Application services joining local AI parsing to the deterministic engine."""

from __future__ import annotations

from typing import Any

from django.conf import settings
from design_engine.services import generate_design, resolve_feasibility_decision

from .architectural_intent import ArchitecturalIntent
from .openai_architecture import OpenAIArchitectureClient, OpenAIArchitectureError, openai_configured
from .parser import ParserError, parse_requirements
from .schema import HouseRequirements


def parse_house_requirements(text: str) -> HouseRequirements:
    if openai_configured():
        return OpenAIArchitectureClient().plan(text)['requirements']
    return parse_requirements(text)


def natural_language_to_design(text: str, candidate_count: int = 6, seed: int = 0) -> dict[str, Any]:
    """Parse text, then delegate geometry, validation, and scoring to the existing engine."""
    intent: ArchitecturalIntent | None = None
    try:
        if openai_configured():
            intent = OpenAIArchitectureClient().plan(text)
            requirements = intent['requirements']
        else:
            requirements = parse_house_requirements(text)
    except (ParserError, OpenAIArchitectureError) as error:
        return {'success': False, 'errors': [str(error)], 'warnings': [], 'requirements': None, 'plans': []}

    result = generate_design(
        requirements,
        candidate_count=candidate_count,
        seed=seed,
        architectural_intent=intent,
    )
    if not result.get('success'):
        return {**result, 'requirements': requirements, 'plans': []}
    plans = result.get('plans', [
        candidate for candidate in result.get('candidates', [])
        if candidate.get('validation', {}).get('valid')
    ])
    response = {**result, 'requirements': requirements, 'plans': plans}
    if intent:
        response['architectural_intent'] = intent
        if getattr(settings, 'OPENAI_ARCHITECTURE_REVIEW', True):
            try:
                reviewer = OpenAIArchitectureClient()
                review = reviewer.review(intent, result['recommended_layout'])
                response['architectural_review'] = review
                actions = review.get('revision_actions', [])
                if actions:
                    revised_intent = {**intent, 'revision_actions': [str(action) for action in actions]}
                    revised = generate_design(
                        requirements,
                        candidate_count=candidate_count,
                        seed=seed + 1,
                        architectural_intent=revised_intent,
                    )
                    if revised.get('success') and revised.get('recommended_layout'):
                        response.update({
                            key: revised[key]
                            for key in ('recommended_layout', 'alternatives', 'candidates', 'plans', 'generation_summary')
                            if key in revised
                        })
                        response['architectural_review']['applied'] = True
            except OpenAIArchitectureError as error:
                response.setdefault('warnings', []).append(str(error))
    return response


def apply_feasibility_decision(
    requirements: HouseRequirements,
    decision: str,
    updated_requirements: HouseRequirements | None = None,
    candidate_count: int = 6,
    seed: int = 0,
) -> dict[str, Any]:
    """Rerun planning after the user explicitly chooses a feasibility option."""
    result = resolve_feasibility_decision(
        requirements,
        decision,
        updated_requirements=updated_requirements,
        candidate_count=candidate_count,
        seed=seed,
    )
    result.setdefault('plans', [])
    if result.get('success'):
        result['plans'] = result.get('plans', [])
    return result