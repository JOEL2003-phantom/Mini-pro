"""Structural comparison and selection for generated architectural plans."""

from typing import Any


def _room_order(layout: dict[str, Any]) -> tuple[tuple[Any, ...], ...]:
    floors: dict[int, list[dict[str, Any]]] = {}
    for room in layout.get('rooms', []):
        floors.setdefault(room.get('floor', 1), []).append(room)
    return tuple(
        tuple((room.get('type'), room.get('zone')) for room in floors[floor])
        for floor in sorted(floors)
    )


def _adjacency_edges(layout: dict[str, Any]) -> tuple[tuple[str, str], ...]:
    edges = []
    for room_id, neighbors in (layout.get('adjacency') or {}).items():
        for neighbor in neighbors:
            edges.append(tuple(sorted((room_id, neighbor))))
    return tuple(sorted(set(edges)))


def structural_signature(layout: dict[str, Any]) -> tuple[Any, ...]:
    """Return topology and planning intent, deliberately excluding raw coordinates."""
    strategy = layout.get('strategy_metadata', {})
    corridors = layout.get('circulation', {}).get('corridors', [])
    corridor_shape = tuple(
        (corridor.get('floor'), corridor.get('width_clear'), corridor.get('spine'))
        for corridor in corridors
    )
    entrance = next(iter(layout.get('entrances', [])), {})
    stairs = tuple(
        (stair.get('floor'), stair.get('connects_to'), stair.get('dedicated_zone'))
        for stair in layout.get('stairs', [])
    )
    room_types = tuple(room.get('type') for room in layout.get('rooms', []))
    return (
        strategy.get('corridor_strategy'),
        strategy.get('site_variant'),
        tuple(strategy.get('zone_blocks', ())),
        _room_order(layout),
        room_types,
        _adjacency_edges(layout),
        (entrance.get('connects_to'), entrance.get('wall')),
        corridor_shape,
        stairs,
        bool(layout.get('open_spaces')),
        len(layout.get('parking', [])),
    )


def layout_distance(first: dict[str, Any], second: dict[str, Any]) -> float:
    """Measure meaningful structural differences, ignoring candidate IDs and coordinates."""
    first_signature = structural_signature(first)
    second_signature = structural_signature(second)
    if first_signature == second_signature:
        return 0.0
    differences = sum(left != right for left, right in zip(first_signature, second_signature))
    return differences / max(len(first_signature), 1)


def select_diverse_layouts(
    candidates: list[dict[str, Any]],
    limit: int = 6,
    minimum_distance: float = 0.15,
) -> list[dict[str, Any]]:
    """Select high-quality candidates while rejecting near-identical structures."""
    ranked = sorted(
        candidates,
        key=lambda candidate: candidate.get('score', {}).get('total', 0),
        reverse=True,
    )
    selected: list[dict[str, Any]] = []
    for candidate in ranked:
        if all(layout_distance(candidate, existing) >= minimum_distance for existing in selected):
            candidate['structural_signature'] = structural_signature(candidate)
            selected.append(candidate)
        if len(selected) == limit:
            break
    return selected
