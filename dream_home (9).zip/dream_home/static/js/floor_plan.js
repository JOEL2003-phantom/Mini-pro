(function () {
    'use strict';

    const layoutNode = document.getElementById('recommended-layout');
    const alternativesNode = document.getElementById('layout-alternatives');
    const viewport = document.getElementById('svg-viewport');
    if (!layoutNode || !viewport) return;

    let currentLayout = JSON.parse(layoutNode.textContent);
    const originalLayout = JSON.parse(layoutNode.textContent);
    const alternatives = alternativesNode ? JSON.parse(alternativesNode.textContent) : [];
    const candidates = [currentLayout].concat(alternatives);
    let candidateIndex = 0;
    let currentFloor = 1;
    let zoom = 1;
    let selectedObject = null;
    let selectedRoomId = null;
    let selectedElement = null;
    let undoStack = [];
    let redoStack = [];
    let dragState = null;
    const SVG_NS = 'http://www.w3.org/2000/svg';

    function element(tag, attrs, text) {
        const node = document.createElementNS(SVG_NS, tag);
        Object.entries(attrs || {}).forEach(([key, value]) => node.setAttribute(key, value));
        if (text !== undefined) node.textContent = text;
        return node;
    }

    function clone(value) {
        return JSON.parse(JSON.stringify(value));
    }

    function setStatus(message, kind) {
        const status = document.getElementById('editor-status');
        if (status) {
            status.textContent = message;
            status.dataset.kind = kind || 'info';
        }
    }

    function csrfToken() {
        return document.querySelector('#editor-csrf input[name=csrfmiddlewaretoken]')?.value || '';
    }

    function bindIfExists(selector, handler) {
        const node = document.querySelector(selector);
        if (node) node.addEventListener('click', handler);
    }

    function designRoot() {
        return window.location.pathname.replace(/\/visualize\/?$/, '');
    }

    function snapshot() {
        undoStack.push(clone(currentLayout));
        if (undoStack.length > 30) undoStack.shift();
        redoStack = [];
    }

    function validateLocal(layout) {
        const errors = [];
        const rooms = layout.rooms || [];
        const plot = layout.plot || {};
        rooms.forEach((room) => {
            if (room.width <= 0 || room.height <= 0) errors.push(`${room.name} has invalid dimensions.`);
            if (room.x < 0 || room.y < 0 || room.x + room.width > plot.width || room.y + room.height > plot.length) errors.push(`${room.name} is outside the plot.`);
            room.area = Math.round(room.width * room.height * 100) / 100;
        });
        rooms.forEach((room, index) => rooms.slice(index + 1).forEach((other) => {
            if ((room.floor || 1) !== (other.floor || 1)) return;
            if (room.x < other.x + other.width && room.x + room.width > other.x && room.y < other.y + other.height && room.y + room.height > other.y) errors.push(`${room.name} overlaps ${other.name}.`);
        }));
        return {valid: errors.length === 0, errors};
    }

    async function requestEvaluation() {
        try {
            const response = await fetch(`${designRoot()}/validate/`, {method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRFToken': csrfToken()}, body: JSON.stringify({layout: currentLayout})});
            const result = await response.json();
            currentLayout.validation = {valid: result.valid, errors: result.errors || [], warnings: result.warnings || []};
            currentLayout.score = result.score;
            updateInfo(currentLayout);
            if (!result.valid) setStatus(result.errors.join(' '), 'error');
            else setStatus(`Design is valid. Score: ${result.score ? result.score.total : '-'}/100`, 'success');
            return result.valid;
        } catch (error) {
            setStatus('The edited layout could not be validated.', 'error');
            return false;
        }
    }

    function addText(parent, x, y, text, className, anchor) {
        parent.appendChild(element('text', {x, y, class: className || '', 'text-anchor': anchor || 'middle'}, text));
    }

    function addRoomLabel(group, room) {
        const centerX = room.x + room.width / 2;
        const centerY = room.y + room.height / 2;
        const availableWidth = Math.max(3, room.width - 1.8);
        const name = room.name.toUpperCase();
        const detail = `${room.width} × ${room.height} ${room.unit || 'ft'}`.trim();
        const area = `${room.area} sq ft`;
        const fontSize = Math.max(0.65, Math.min(1.2, availableWidth / Math.max(name.length * 0.62, 1)));
        const labelWidth = Math.min(room.width - 0.6, Math.max(name.length, detail.length, area.length) * fontSize * 0.62 + 0.6);
        const labelHeight = fontSize * 3.9;
        group.appendChild(element('rect', {
            x: centerX - labelWidth / 2, y: centerY - 1.6 - fontSize * 0.9,
            width: labelWidth, height: labelHeight, class: 'label-bg', rx: 0.15,
        }));
        const label = element('text', {x: centerX, y: centerY - 1.6, class: 'room-label', 'font-size': fontSize, 'text-anchor': 'middle'});
        label.appendChild(element('tspan', {x: centerX, dy: 0}, name));
        label.appendChild(element('tspan', {x: centerX, dy: 1.9, class: 'room-dimension'}, detail));
        label.appendChild(element('tspan', {x: centerX, dy: 1.7, class: 'room-area'}, area));
        group.appendChild(label);
    }

    function addRect(parent, x, y, width, height, className, rx) {
        if (width <= 0 || height <= 0) return;
        parent.appendChild(element('rect', {x, y, width, height, class: className, rx: rx || 0}));
    }

    function addFurnLine(parent, x1, y1, x2, y2, className) {
        parent.appendChild(element('line', {x1, y1, x2, y2, class: className}));
    }

    function addFurnCircle(parent, cx, cy, r, className) {
        parent.appendChild(element('circle', {cx, cy, r, class: className}));
    }

    function addFurnEllipse(parent, cx, cy, rx, ry, className) {
        parent.appendChild(element('ellipse', {cx, cy, rx, ry, class: className}));
    }

    function renderBedFurniture(group, room) {
        const inset = 0.7;
        const innerX = room.x + inset, innerY = room.y + inset;
        const innerW = room.width - inset * 2, innerH = room.height - inset * 2;
        if (innerW < 2.2 || innerH < 2.2) return;
        const bedW = Math.min(innerW * 0.62, 5.2);
        const bedH = Math.min(innerH * 0.62, 6.6);
        addRect(group, innerX, innerY, bedW, bedH, 'furn-bed', 0.15);
        addRect(group, innerX + 0.15, innerY + 0.15, bedW - 0.3, bedH * 0.26, 'furn-pillow', 0.15);
        addFurnLine(group, innerX, innerY + bedH * 0.32, innerX + bedW, innerY + bedH * 0.32, 'furn-line');
        if (innerW - bedW > 1.1) addRect(group, innerX + bedW + 0.3, innerY, 1.0, 1.0, 'furn-side', 0.12);
        if (innerH > 6) addRect(group, innerX + innerW - 1.1, innerY + innerH - Math.min(3.5, innerH * 0.4), 1.1, Math.min(3.5, innerH * 0.4), 'furn-wardrobe');
    }

    function renderBathFurniture(group, room) {
        const innerX = room.x + 0.5, innerY = room.y + 0.5;
        const innerW = room.width - 1.0, innerH = room.height - 1.0;
        if (innerW < 1.6 || innerH < 1.6) return;
        addRect(group, innerX, innerY, 1.4, 1.9, 'furn-wc', 0.55);
        addFurnEllipse(group, innerX + 0.7, innerY + 0.55, 0.5, 0.35, 'furn-wc-seat');
        addRect(group, innerX + innerW - 1.6, innerY, 1.6, 0.9, 'furn-sink', 0.3);
        addFurnCircle(group, innerX + innerW - 0.8, innerY + 0.42, 0.11, 'furn-tap');
        if (innerH > 3.2) addRect(group, innerX, innerY + innerH - 1.6, innerW, 1.6, 'furn-tub', 0.5);
    }

    function renderKitchenFurniture(group, room) {
        const innerX = room.x + 0.5, innerY = room.y + 0.5;
        const innerW = room.width - 1.0, innerH = room.height - 1.0;
        if (innerW < 2.2 || innerH < 2.2) return;
        const depth = 2.0;
        addRect(group, innerX, innerY, innerW, depth, 'furn-counter');
        addRect(group, innerX, innerY, depth, innerH, 'furn-counter');
        [0.42, 0.66].forEach((f) => addFurnCircle(group, innerX + innerW * f, innerY + depth / 2, 0.26, 'furn-burner'));
        addRect(group, innerX + depth + 0.3, innerY + 0.35, 1.4, 1.3, 'furn-sink', 0.2);
    }

    function renderLivingFurniture(group, room) {
        const innerX = room.x + 0.6, innerY = room.y + 0.6;
        const innerW = room.width - 1.2, innerH = room.height - 1.2;
        if (innerW < 3.2 || innerH < 3.2) return;
        const sofaLen = Math.min(innerW * 0.58, 6.5);
        addRect(group, innerX, innerY, sofaLen, 1.6, 'furn-sofa', 0.2);
        addRect(group, innerX, innerY, 0.32, 1.6, 'furn-sofa-arm');
        addRect(group, innerX + sofaLen - 0.32, innerY, 0.32, 1.6, 'furn-sofa-arm');
        addRect(group, innerX + 0.6, innerY + 2.5, Math.min(innerW * 0.3, 3), 1.4, 'furn-table', 0.15);
    }

    function renderDiningFurniture(group, room) {
        const cx = room.x + room.width / 2, cy = room.y + room.height / 2;
        const tableW = Math.min(room.width - 2.2, 4.5), tableH = Math.min(room.height - 2.2, 3.0);
        if (tableW < 1.6 || tableH < 1.3) return;
        addRect(group, cx - tableW / 2, cy - tableH / 2, tableW, tableH, 'furn-table', 0.1);
        for (let i = 0; i < 3; i++) {
            const sx = cx - tableW / 2 + (i + 0.5) * (tableW / 3);
            addRect(group, sx - 0.28, cy - tableH / 2 - 0.55, 0.56, 0.48, 'furn-chair', 0.1);
            addRect(group, sx - 0.28, cy + tableH / 2 + 0.07, 0.56, 0.48, 'furn-chair', 0.1);
        }
    }

    function renderFurniture(group, room) {
        if (Array.isArray(room.furniture) && room.furniture.length) {
            room.furniture.forEach((item) => renderStructuredFurniture(group, item));
            return;
        }
        const map = {bedroom: renderBedFurniture, bathroom: renderBathFurniture, kitchen: renderKitchenFurniture, living: renderLivingFurniture, dining: renderDiningFurniture};
        const fn = map[room.type];
        if (fn) fn(group, room);
    }

    function renderStructuredFurniture(group, item) {
        const x = item.x, y = item.y, w = item.width, h = item.height;
        if (!Number.isFinite(x) || !Number.isFinite(y) || w <= 0 || h <= 0) return;
        if (item.type === 'bed') {
            addRect(group, x, y, w, h, 'furn-bed', 0.15);
            addRect(group, x + 0.15, y + 0.15, Math.max(0.2, w - 0.3), Math.min(1.6, h * 0.26), 'furn-pillow', 0.15);
        } else if (item.type === 'sofa') {
            addRect(group, x, y, w, h, 'furn-sofa', 0.2);
            addRect(group, x, y, Math.min(0.32, w), h, 'furn-sofa-arm');
            addRect(group, x + w - Math.min(0.32, w), y, Math.min(0.32, w), h, 'furn-sofa-arm');
        } else if (item.type === 'dining_table' || item.type === 'table') {
            addRect(group, x, y, w, h, 'furn-table', 0.1);
            const seats = item.seats || 4;
            for (let index = 0; index < Math.ceil(seats / 2); index += 1) {
                const chairX = x + (index + 0.5) * (w / Math.ceil(seats / 2));
                addRect(group, chairX - 0.28, y - 0.55, 0.56, 0.48, 'furn-chair', 0.1);
                addRect(group, chairX - 0.28, y + h + 0.07, 0.56, 0.48, 'furn-chair', 0.1);
            }
        } else if (item.type === 'wardrobe') {
            addRect(group, x, y, w, h, 'furn-wardrobe');
        } else if (item.type === 'toilet') {
            addRect(group, x, y, w, h, 'furn-wc', 0.55);
            addFurnEllipse(group, x + w / 2, y + h * 0.3, Math.min(0.5, w / 3), Math.min(0.35, h / 4), 'furn-wc-seat');
        } else if (item.type === 'basin' || item.type === 'sink') {
            addRect(group, x, y, w, h, 'furn-sink', 0.3);
            addFurnCircle(group, x + w / 2, y + h / 2, 0.11, 'furn-tap');
        } else if (item.type === 'counter' || item.type === 'utility_counter') {
            addRect(group, x, y, w, h, 'furn-counter');
        } else if (item.type === 'cooktop') {
            addRect(group, x, y, w, h, 'furn-counter');
            addFurnCircle(group, x + w * 0.35, y + h / 2, 0.26, 'furn-burner');
            addFurnCircle(group, x + w * 0.7, y + h / 2, 0.26, 'furn-burner');
        } else if (item.type === 'washing_machine') {
            addRect(group, x, y, w, h, 'furn-sink', 0.15);
            addFurnCircle(group, x + w / 2, y + h / 2, Math.min(w, h) * 0.25, 'furn-wc-seat');
        } else if (item.type === 'coffee_table' || item.type === 'desk' || item.type === 'chair') {
            addRect(group, x, y, w, h, item.type === 'chair' ? 'furn-chair' : 'furn-table', 0.15);
        }
    }

    function wallStart(wall) {
        return wall.orientation === 'vertical'
            ? {x: wall.x, y: wall.y}
            : {x: wall.x, y: wall.y};
    }

    function wallEnd(wall) {
        if (wall.orientation === 'vertical') return {x: wall.x, y: wall.y + wall.length};
        return {x: wall.x + wall.length, y: wall.y};
    }

    function setWallFromEndpoints(wall, start, end) {
        if (Math.abs(start.x - end.x) < 0.01 && Math.abs(start.y - end.y) > 0.01) {
            wall.orientation = 'vertical';
            wall.x = start.x;
            wall.y = Math.min(start.y, end.y);
            wall.length = Math.abs(end.y - start.y);
            return;
        }
        if (Math.abs(start.y - end.y) < 0.01 && Math.abs(start.x - end.x) > 0.01) {
            wall.orientation = 'horizontal';
            wall.x = Math.min(start.x, end.x);
            wall.y = start.y;
            wall.length = Math.abs(end.x - start.x);
        }
    }

    function renderPlotBoundary(parent, plot) {
        const group = element('g', {id: 'plot-boundary', class: 'plot-boundary'});
        group.appendChild(element('rect', {
            x: 0, y: 0, width: plot.width, height: plot.length,
            class: 'plot-outline',
            fill: 'transparent',
            stroke: '#364152',
            'stroke-width': 0.5,
            'vector-effect': 'non-scaling-stroke',
        }));
        parent.appendChild(group);
    }

    function renderWall(parent, wall) {
        const isSelected = selectedObject && selectedObject.type === 'wall' && selectedObject.id === wall.id;
        const group = element('g', {
            id: `wall-${wall.id}`,
            class: `plan-wall${isSelected ? ' is-selected' : ''}`,
            'data-wall-id': wall.id,
            'data-object-id': wall.id,
            'data-object-type': 'wall',
        });
        const start = wallStart(wall);
        const end = wallEnd(wall);
        const attrs = {class: wall.type === 'exterior' ? 'wall-visible structured-exterior-wall' : 'wall-visible structured-interior-wall'};
        attrs.x1 = start.x; attrs.y1 = start.y; attrs.x2 = end.x; attrs.y2 = end.y;

        const visible = element('line', attrs);
        const hit = element('line', {
            x1: start.x,
            y1: start.y,
            x2: end.x,
            y2: end.y,
            class: 'wall-hit-target',
            stroke: 'transparent',
            'stroke-width': wall.orientation === 'vertical' ? 18 : 18,
            'vector-effect': 'non-scaling-stroke',
        });
        const startHandle = element('circle', {
            class: 'wall-handle wall-handle-start',
            cx: start.x, cy: start.y, r: 0.65,
            'data-wall-handle': 'start',
        });
        const endHandle = element('circle', {
            class: 'wall-handle wall-handle-end',
            cx: end.x, cy: end.y, r: 0.65,
            'data-wall-handle': 'end',
        });

        group.appendChild(visible);
        group.appendChild(hit);
        group.appendChild(startHandle);
        group.appendChild(endHandle);

        const activateWall = (event, handle) => {
            event.preventDefault();
            event.stopPropagation();
            selectElement(wall, 'walls', 'Wall');
            dragState = {
                item: wall,
                collection: 'walls',
                mode: handle ? 'endpoint' : 'move',
                handle,
                start: svgPoint(event),
                origin: {x: wall.x, y: wall.y},
                originStart: {x: start.x, y: start.y},
                originEnd: {x: end.x, y: end.y},
            };
            window.addEventListener('pointermove', dragElement);
            window.addEventListener('pointerup', finishElementDrag, {once: true});
        };

        visible.addEventListener('pointerdown', (event) => activateWall(event, null));
        hit.addEventListener('pointerdown', (event) => activateWall(event, null));
        startHandle.addEventListener('pointerdown', (event) => activateWall(event, 'start'));
        endHandle.addEventListener('pointerdown', (event) => activateWall(event, 'end'));
        group.addEventListener('click', (event) => { event.stopPropagation(); selectElement(wall, 'walls', 'Wall'); });
        parent.appendChild(group);
    }

    function renderStructuredDimension(parent, dimension, margin) {
        const x = dimension.x + margin, y = dimension.y + margin;
        if (dimension.orientation === 'vertical') {
            renderDimension(parent, x, y, x, y + dimension.length, dimension.label, true);
        } else {
            renderDimension(parent, x, y, x + dimension.length, y, dimension.label, false);
        }
    }

    function renderStairs(parent, stair) {
        const group = element('g', {class: 'plan-stairs editable-element', id: `stairs-${stair.id}`});
        addRect(group, stair.x, stair.y, stair.width, stair.height, 'stairs-outline');
        addRect(group, stair.x, stair.y, stair.width, stair.height, 'stair-hit-target');
        const stepHeight = stair.height / Math.max(1, stair.steps || 10);
        for (let index = 1; index < (stair.steps || 10); index += 1) {
            addFurnLine(group, stair.x, stair.y + index * stepHeight, stair.x + stair.width, stair.y + index * stepHeight, 'stair-step');
        }
        addText(group, stair.x + stair.width / 2, stair.y + stair.height / 2, 'UP', 'stair-label');
        group.addEventListener('pointerdown', (event) => startElementDrag(event, stair, 'stairs', 'Stair'));
        parent.appendChild(group);
    }

    function renderCar(parent, cx, cy, bayWidth, bayHeight) {
        const carW = bayWidth * 0.72, carH = bayHeight * 0.42;
        addRect(parent, cx - carW / 2, cy - carH / 2, carW, carH, 'furn-car', 0.6);
        addRect(parent, cx - carW * 0.26, cy - carH / 2 - carH * 0.32, carW * 0.52, carH * 0.5, 'furn-car-cab', 0.35);
    }

    function renderDimension(parent, x1, y1, x2, y2, label, vertical) {
        const group = element('g', {class: 'dimension-line'});
        group.appendChild(element('line', {x1, y1, x2, y2}));
        if (vertical) {
            group.appendChild(element('line', {class: 'extension-line', x1: x1 + 3, y1, x2, y2: y1}));
            group.appendChild(element('line', {class: 'extension-line', x1: x2 + 3, y1: y2, x2, y2}));
            group.appendChild(element('line', {x1: x1 - 0.8, y1, x2: x1 + 0.8, y2: y1}));
            group.appendChild(element('line', {x1: x2 - 0.8, y1: y2, x2: x2 + 0.8, y2}));
            addText(group, x1 - 1.5, (y1 + y2) / 2, label, 'dimension-label', 'middle');
        } else {
            group.appendChild(element('line', {class: 'extension-line', x1, y1: y1 + 3, x2: x1, y2}));
            group.appendChild(element('line', {class: 'extension-line', x1: x2, y1: y2 + 3, x2, y2}));
            group.appendChild(element('line', {x1, y1: y1 - 0.8, x2: x1, y2: y1 + 0.8}));
            group.appendChild(element('line', {x1: x2, y1: y2 - 0.8, x2, y2: y2 + 0.8}));
            addText(group, (x1 + x2) / 2, y1 - 1.5, label, 'dimension-label', 'middle');
        }
        parent.appendChild(group);
    }

    function renderSpace(parent, space, className) {
        const collection = space.type === 'parking' ? 'parking' : 'open_spaces';
        const group = element('g', {id: `space-${space.id}`, class: `${className} editable-element`, 'data-space-id': space.id});
        group.appendChild(element('rect', {x: space.x, y: space.y, width: space.width, height: space.height, rx: 0.25}));
        if (space.type === 'parking') {
            const bayCount = Math.max(1, Math.round(space.width / 10));
            const bayWidth = space.width / bayCount;
            for (let x = space.x + bayWidth; x < space.x + space.width - 0.1; x += bayWidth) {
                group.appendChild(element('line', {class: 'parking-marking', x1: x, y1: space.y + 0.8, x2: x, y2: space.y + space.height - 0.8}));
            }
            for (let i = 0; i < bayCount; i++) {
                renderCar(group, space.x + bayWidth * (i + 0.5), space.y + space.height * 0.42, bayWidth, space.height);
            }
            addText(group, space.x + space.width / 2, space.y + space.height * 0.9, 'PARKING', 'space-label');
        } else {
            addText(group, space.x + space.width / 2, space.y + space.height / 2, 'GARDEN / OPEN SPACE', 'space-label');
        }
        group.addEventListener('pointerdown', (event) => startElementDrag(event, space, collection, space.type === 'parking' ? 'Parking' : 'Garden'));
        parent.appendChild(group);
    }

    function renderRoom(parent, room) {
        const group = element('g', {id: `room-${room.id}`, class: 'plan-room', 'data-room-id': room.id, tabindex: '0'});
        group.appendChild(element('rect', {class: 'room-fill', x: room.x, y: room.y, width: room.width, height: room.height, rx: 0.25}));
        renderFurniture(group, room);
        (room.furniture || []).forEach((item) => {
            const hit = element('rect', {x: item.x, y: item.y, width: item.width, height: item.height, class: 'furniture-hit-target'});
            hit.addEventListener('pointerdown', (event) => startElementDrag(event, item, 'furniture', item.type.replaceAll('_', ' ')));
            hit.addEventListener('click', (event) => { event.stopPropagation(); selectElement(item, 'furniture', item.type.replaceAll('_', ' ')); });
            group.appendChild(hit);
        });
        addRoomLabel(group, room);
        group.addEventListener('click', (event) => {
            if (eventTargetIsFurniture(event)) return;
            selectedRoomId = room.id;
            document.querySelectorAll('.plan-room.is-selected').forEach((node) => node.classList.remove('is-selected'));
            group.classList.add('is-selected');
            document.querySelectorAll('.room-list-item.is-selected').forEach((node) => node.classList.remove('is-selected'));
            const item = document.querySelector(`[data-list-room="${room.id}"]`);
            if (item) item.classList.add('is-selected');
            showRoomInspector(room);
        });
        group.addEventListener('pointerdown', (event) => startDrag(event, room));
        parent.appendChild(group);
    }

    function eventTargetIsFurniture(event) {
        return event?.target?.classList?.contains('furniture-hit-target');
    }

    function resolveItemCollection(item, fallbackCollection) {
        if (item && item.type === 'garden') return 'open_spaces';
        if (item && item.type === 'parking') return 'parking';
        if (item && item.type === 'wall') return 'walls';
        if (item && item.type === 'door') return 'doors';
        if (item && item.type === 'window') return 'windows';
        if (item && item.type === 'stair') return 'stairs';
        if (item && item.type === 'furniture') return 'furniture';
        return fallbackCollection || 'rooms';
    }

    function resolveObjectType(item, fallbackCollection) {
        if (!item) return 'room';
        if (item.type === 'plot' || fallbackCollection === 'plot') return 'plot';
        if (item.type === 'corridor') return 'corridor';
        if (item.type === 'garden') return 'garden';
        if (item.type === 'parking') return 'parking';
        if (item.type === 'door') return 'door';
        if (item.type === 'window') return 'window';
        if (item.type === 'stair') return 'stair';
        if (item.type === 'wall') return 'wall';
        if (item.type === 'furniture' || item.room_id) return 'furniture';
        if (fallbackCollection === 'open_spaces' || item.type === 'open_space') return 'garden';
        if (fallbackCollection === 'parking') return 'parking';
        if (fallbackCollection === 'corridors') return 'corridor';
        if (fallbackCollection === 'walls') return 'wall';
        if (fallbackCollection === 'doors') return 'door';
        if (fallbackCollection === 'windows') return 'window';
        if (fallbackCollection === 'stairs') return 'stair';
        if (fallbackCollection === 'furniture') return 'furniture';
        return 'room';
    }

    function getSelectedItem() {
        if (!selectedObject) return null;
        const {type, id} = selectedObject;
        if (type === 'plot') return currentLayout.plot || null;
        if (type === 'room') return (currentLayout.rooms || []).find((room) => room.id === id) || null;
        if (type === 'corridor') return (currentLayout.circulation?.corridors || []).find((item) => item.id === id) || null;
        if (type === 'garden') return (currentLayout.open_spaces || []).find((item) => item.id === id) || null;
        if (type === 'parking') return (currentLayout.parking || []).find((item) => item.id === id) || null;
        if (type === 'wall') return (currentLayout.walls || []).find((item) => item.id === id) || null;
        if (type === 'door') return (currentLayout.doors || []).find((item) => item.id === id) || null;
        if (type === 'window') return (currentLayout.windows || []).find((item) => item.id === id) || null;
        if (type === 'stair') return [...(currentLayout.stairs || []), ...(currentLayout.stair_arrivals || [])].find((item) => item.id === id) || null;
        if (type === 'furniture') {
            const direct = (currentLayout.furniture || []).find((item) => item.id === id);
            if (direct) return direct;
            for (const room of currentLayout.rooms || []) {
                const nested = (room.furniture || []).find((item) => item.id === id);
                if (nested) return nested;
            }
        }
        return null;
    }

    function selectElement(item, collection, label) {
        const effectiveType = resolveObjectType(item, collection);
        selectedObject = {type: effectiveType, id: item.id || 'plot'};
        selectedRoomId = effectiveType === 'room' ? item.id : null;
        selectedElement = {item, collection, label, type: effectiveType};
        document.querySelectorAll('.editable-element.is-selected, .plan-wall.is-selected, .furniture-hit-target.is-selected').forEach((node) => node.classList.remove('is-selected'));
        const prefix = collection === 'open_spaces' || collection === 'parking' ? 'space' : collection === 'furniture' ? null : collection.slice(0, -1);
        const node = prefix && prefix !== 'plot' ? document.getElementById(`${prefix}-${item.id}`) : null;
        if (node) node.classList.add('is-selected');
        const inspector = document.getElementById('room-inspector');
        if (!inspector) return;
        inspector.hidden = false;
        document.getElementById('inspector-title').textContent = `Selected ${label}`;
        document.getElementById('selected-room-name').textContent = item.name || item.id || 'Plot';
        document.getElementById('element-x').value = Number.isFinite(item.x) ? item.x : 0;
        document.getElementById('element-y').value = Number.isFinite(item.y) ? item.y : 0;
        document.getElementById('element-width').value = item.width || item.length || 1;
        document.getElementById('element-height').value = item.height || item.length || 0.25;
        document.getElementById('element-orientation').value = item.orientation || 'horizontal';
        document.getElementById('element-swing').value = item.swing || 'right';
        const isPlot = effectiveType === 'plot';
        const fixedOpening = collection === 'doors' || collection === 'windows';
        document.getElementById('element-width-label').hidden = isPlot || fixedOpening || effectiveType === 'door' || effectiveType === 'window';
        document.getElementById('element-height-label').hidden = isPlot || fixedOpening || collection === 'walls' || effectiveType === 'door' || effectiveType === 'window';
        document.getElementById('element-orientation-label').hidden = isPlot || !['door', 'window', 'wall'].includes(effectiveType) && !['doors', 'windows', 'walls'].includes(collection);
        document.getElementById('element-swing-label').hidden = effectiveType !== 'door';
        document.getElementById('selected-room-meta').textContent = isPlot ? `Plot boundary · ${item.width} × ${item.height} ${currentLayout.plot.unit || 'ft'}` : `${label} · floor ${item.floor || 1} · drag to move, then apply changes.`;
    }

    function showRoomInspector(room) {
        if (!room) return;
        selectedObject = {type: 'room', id: room.id};
        selectedRoomId = room.id;
        selectedElement = null;
        const inspector = document.getElementById('room-inspector');
        inspector.hidden = false;
        document.getElementById('selected-room-name').textContent = room.name || room.id;
        document.getElementById('element-x').value = room.x;
        document.getElementById('element-y').value = room.y;
        document.getElementById('element-width').value = room.width;
        document.getElementById('element-height').value = room.height;
        document.getElementById('element-width-label').hidden = false;
        document.getElementById('element-height-label').hidden = false;
        document.getElementById('element-orientation-label').hidden = true;
        document.getElementById('element-swing-label').hidden = true;
        document.getElementById('selected-room-meta').textContent = `${room.type || 'Room'} · floor ${room.floor || 1} · ${room.zone || 'unclassified'}`;
    }

    function svgPoint(event) {
        const svg = viewport.querySelector('svg');
        const point = new DOMPoint(event.clientX, event.clientY).matrixTransform(svg.getScreenCTM().inverse());
        const margin = 8;
        return {x: point.x - margin, y: point.y - margin};
    }

    function startDrag(event, room) {
        if (event.button !== 0) return;
        event.preventDefault();
        snapshot();
        selectElement(room, 'rooms', 'Room');
        dragState = {item: room, collection: 'rooms', roomId: room.id, start: svgPoint(event), origin: {x: room.x, y: room.y}};
        window.addEventListener('pointermove', dragRoom);
        window.addEventListener('pointerup', finishDrag, {once: true});
    }

    function dragRoom(event) {
        if (!dragState) return;
        const room = currentLayout.rooms.find((item) => item.id === dragState.roomId);
        const point = svgPoint(event);
        const nextX = Math.round((dragState.origin.x + point.x - dragState.start.x) * 2) / 2;
        const nextY = Math.round((dragState.origin.y + point.y - dragState.start.y) * 2) / 2;
        const deltaX = nextX - room.x, deltaY = nextY - room.y;
        room.x = nextX; room.y = nextY;
        moveAttachedElements(room.id, deltaX, deltaY);
        renderLayout(currentLayout);
    }

    function moveAttachedElements(roomId, deltaX, deltaY) {
        const related = [
            ...(currentLayout.furniture || []),
            ...(currentLayout.doors || []),
            ...(currentLayout.windows || []),
        ];
        related.forEach((item) => {
            if (item.room_id === roomId || item.connects_to === roomId) {
                item.x = Math.round((item.x + deltaX) * 2) / 2;
                item.y = Math.round((item.y + deltaY) * 2) / 2;
            }
        });
        const nested = currentLayout.rooms.find((room) => room.id === roomId)?.furniture || [];
        nested.forEach((item) => {
            item.x = Math.round((item.x + deltaX) * 2) / 2;
            item.y = Math.round((item.y + deltaY) * 2) / 2;
        });
    }

    function moveEntireLayout(deltaX, deltaY) {
        if (!currentLayout.plot) currentLayout.plot = {id: 'plot', x: 0, y: 0, width: 0, length: 0, unit: 'ft'};
        currentLayout.plot.x = Math.round((currentLayout.plot.x + deltaX) * 2) / 2;
        currentLayout.plot.y = Math.round((currentLayout.plot.y + deltaY) * 2) / 2;
    }

    function startElementDrag(event, item, collection, label) {
        if (event.button !== 0) return;
        event.preventDefault();
        event.stopPropagation();
        snapshot();
        selectElement(item, collection, label);
        dragState = {item, collection, start: svgPoint(event), origin: {x: item.x, y: item.y}};
        window.addEventListener('pointermove', dragElement);
        window.addEventListener('pointerup', finishElementDrag, {once: true});
    }

    function dragElement(event) {
        if (!dragState) return;
        const point = svgPoint(event);
        const item = dragState.item;
        const origin = dragState.origin || {x: item?.x ?? 0, y: item?.y ?? 0};
        const start = dragState.start || {x: point.x, y: point.y};
        const nextX = Math.round((origin.x + point.x - start.x) * 2) / 2;
        const nextY = Math.round((origin.y + point.y - start.y) * 2) / 2;
        if (dragState.collection === 'walls') {
            if (dragState.mode === 'endpoint') {
                const startPoint = dragState.originStart || {x: item.x, y: item.y};
                const endPoint = dragState.originEnd || {x: item.x + (item.length || 0), y: item.y};
                if (dragState.handle === 'start') {
                    const nextStart = {x: startPoint.x + point.x - start.x, y: startPoint.y + point.y - start.y};
                    if (item.orientation === 'vertical') {
                        nextStart.x = item.x;
                    } else {
                        nextStart.y = item.y;
                    }
                    setWallFromEndpoints(item, nextStart, endPoint);
                } else {
                    const nextEnd = {x: endPoint.x + point.x - start.x, y: endPoint.y + point.y - start.y};
                    if (item.orientation === 'vertical') {
                        nextEnd.x = item.x;
                    } else {
                        nextEnd.y = item.y;
                    }
                    setWallFromEndpoints(item, startPoint, nextEnd);
                }
            } else {
                moveWall(item, nextX - item.x, nextY - item.y);
            }
        } else if (dragState.collection === 'stairs') {
            moveStair(item, nextX - item.x, nextY - item.y);
        } else {
            item.x = nextX;
            item.y = nextY;
            if (dragState.collection === 'doors' || dragState.collection === 'windows') snapToRoomBoundary(item);
        }
        if (dragState.collection === 'rooms') currentLayout._recalculate_circulation = true;
        renderLayout(currentLayout);
    }

    function moveWall(wall, deltaX, deltaY) {
        if (!wall) return;
        if (wall.orientation === 'vertical') {
            wall.x += deltaX;
            wall.y += deltaY;
            if (wall.x < 0) wall.x = 0;
            if (wall.y < 0) wall.y = 0;
        } else {
            wall.x += deltaX;
            wall.y += deltaY;
            if (wall.x < 0) wall.x = 0;
            if (wall.y < 0) wall.y = 0;
        }
        (wall.rooms || []).forEach((roomId) => {
            const room = currentLayout.rooms.find((candidate) => candidate.id === roomId);
            if (!room) return;
            if (wall.orientation === 'vertical') {
                const oldEdge = wall.x - deltaX;
                if (Math.abs(room.x + room.width - oldEdge) < 0.1) room.width = Math.max(3, room.width + deltaX);
                else if (Math.abs(room.x - oldEdge) < 0.1) { room.x += deltaX; room.width = Math.max(3, room.width - deltaX); }
            } else {
                const oldEdge = wall.y - deltaY;
                if (Math.abs(room.y + room.height - oldEdge) < 0.1) room.height = Math.max(3, room.height + deltaY);
                else if (Math.abs(room.y - oldEdge) < 0.1) { room.y += deltaY; room.height = Math.max(3, room.height - deltaY); }
            }
            room.area = Math.round(room.width * room.height * 100) / 100;
        });
        (currentLayout.doors || []).filter((door) => (wall.rooms || []).includes(door.room_id) || (wall.rooms || []).includes(door.connects_to)).forEach((door) => snapToRoomBoundary(door));
        (currentLayout.windows || []).filter((windowData) => (wall.rooms || []).includes(windowData.room_id)).forEach((windowData) => snapToRoomBoundary(windowData));
    }

    function moveStair(stair, deltaX, deltaY) {
        [...(currentLayout.stairs || []), ...(currentLayout.stair_arrivals || [])].forEach((candidate) => {
            candidate.x = Math.round((candidate.x + deltaX) * 2) / 2;
            candidate.y = Math.round((candidate.y + deltaY) * 2) / 2;
        });
    }

    function snapToRoomBoundary(item) {
        const room = currentLayout.rooms.find((candidate) => candidate.id === (item.room_id || item.connects_to));
        if (!room) return;
        const length = item.width || 1;
        const horizontalDistance = Math.min(Math.abs(item.y - room.y), Math.abs(item.y - (room.y + room.height)));
        const verticalDistance = Math.min(Math.abs(item.x - room.x), Math.abs(item.x - (room.x + room.width)));
        if (horizontalDistance <= verticalDistance) {
            item.orientation = 'horizontal';
            item.y = Math.abs(item.y - room.y) <= Math.abs(item.y - (room.y + room.height)) ? room.y : room.y + room.height;
            item.x = Math.min(Math.max(room.x, item.x), room.x + room.width - length);
        } else {
            item.orientation = 'vertical';
            item.x = Math.abs(item.x - room.x) <= Math.abs(item.x - (room.x + room.width)) ? room.x : room.x + room.width;
            item.y = Math.min(Math.max(room.y, item.y), room.y + room.height - length);
        }
    }

    async function finishElementDrag() {
        window.removeEventListener('pointermove', dragElement);
        const valid = await requestEvaluation();
        if (!valid) {
            setStatus('Drag committed to the current layout. Validation reported issues for review.', 'warning');
        } else {
            setStatus('Drag committed successfully.', 'success');
        }
        renderLayout(currentLayout);
        dragState = null;
    }

    async function finishDrag() {
        window.removeEventListener('pointermove', dragRoom);
        const result = validateLocal(currentLayout);
        if (!result.valid) {
            setStatus(result.errors.join(' '), 'error');
        } else {
            await requestEvaluation();
            setStatus('Room move committed successfully.', 'success');
        }
        renderLayout(currentLayout);
        dragState = null;
    }

    function renderDoor(parent, door) {
        if (!door || !Number.isFinite(door.x) || !Number.isFinite(door.y)) return;
        const width = door.width || 3;
        const direction = door.swing === 'left' ? -1 : 1;
        const group = element('g', {id: `door-${door.id || `${door.x}-${door.y}`}`, class: door.type === 'main' ? 'plan-door plan-entrance' : 'plan-door'});
        const hingeX = door.x;
        const hingeY = door.y;
        const opening = element('line', {class: 'door-opening'});
        if (door.orientation === 'vertical') {
            opening.setAttribute('x1', hingeX); opening.setAttribute('y1', hingeY);
            opening.setAttribute('x2', hingeX); opening.setAttribute('y2', hingeY + width);
        } else {
            opening.setAttribute('x1', hingeX); opening.setAttribute('y1', hingeY);
            opening.setAttribute('x2', hingeX + width); opening.setAttribute('y2', hingeY);
        }
        group.appendChild(opening);
        if (door.orientation === 'vertical') {
            group.appendChild(element('line', {x1: hingeX, y1: hingeY, x2: hingeX + width * direction, y2: hingeY}));
            group.appendChild(element('path', {d: `M ${hingeX + width * direction} ${hingeY} A ${width} ${width} 0 0 ${direction > 0 ? 1 : 0} ${hingeX} ${hingeY + width}`}));
        } else {
            group.appendChild(element('line', {x1: hingeX, y1: hingeY, x2: hingeX, y2: hingeY + width * direction}));
            group.appendChild(element('path', {d: `M ${hingeX} ${hingeY + width * direction} A ${width} ${width} 0 0 ${direction > 0 ? 0 : 1} ${hingeX + width} ${hingeY}`}));
        }
        const hitWidth = door.orientation === 'vertical' ? 0.8 : width;
        const hitHeight = door.orientation === 'vertical' ? width : 0.8;
        group.appendChild(element('rect', {x: hingeX - 0.4, y: hingeY - 0.4, width: hitWidth + 0.8, height: hitHeight + 0.8, class: 'opening-hit-target'}));
        group.addEventListener('pointerdown', (event) => startElementDrag(event, door, 'doors', 'Door'));
        parent.appendChild(group);
    }

    function renderCirculation(parent, circulation, floor) {
        (circulation?.corridors || []).filter((corridor) => (corridor.floor || 1) === floor).forEach((corridor) => {
            const group = element('g', {id: `corridor-${corridor.id}`, class: 'editable-element plan-corridor'});
            group.appendChild(element('rect', {
                class: 'circulation-band', x: corridor.x, y: corridor.y,
                width: corridor.width, height: corridor.height,
            }));
            group.appendChild(element('rect', {
                class: 'corridor-hit-target', x: corridor.x, y: corridor.y,
                width: corridor.width, height: corridor.height,
            }));
            addText(group, corridor.x + corridor.width / 2, corridor.y + corridor.height / 2, 'MAIN CIRCULATION', 'circulation-label');
            group.addEventListener('click', (event) => { event.stopPropagation(); selectElement(corridor, 'corridors', 'Walk'); });
            group.addEventListener('pointerdown', (event) => startElementDrag(event, corridor, 'corridors', 'Circulation'));
            parent.appendChild(group);
        });
    }

    function renderWindow(parent, windowData) {
        if (!windowData || !Number.isFinite(windowData.x) || !Number.isFinite(windowData.y)) return;
        const length = windowData.width || windowData.length || 4;
        const group = element('g', {id: `window-${windowData.id || `${windowData.x}-${windowData.y}`}`, class: 'plan-window'});
        if (windowData.orientation === 'vertical') {
            group.appendChild(element('line', {x1: windowData.x, y1: windowData.y, x2: windowData.x, y2: windowData.y + length}));
            group.appendChild(element('line', {x1: windowData.x + 0.45, y1: windowData.y, x2: windowData.x + 0.45, y2: windowData.y + length}));
        } else {
            group.appendChild(element('line', {x1: windowData.x, y1: windowData.y, x2: windowData.x + length, y2: windowData.y}));
            group.appendChild(element('line', {x1: windowData.x, y1: windowData.y + 0.45, x2: windowData.x + length, y2: windowData.y + 0.45}));
        }
        const hitWidth = windowData.orientation === 'vertical' ? 0.8 : length;
        const hitHeight = windowData.orientation === 'vertical' ? length : 0.8;
        group.appendChild(element('rect', {x: windowData.x - 0.4, y: windowData.y - 0.4, width: hitWidth + 0.8, height: hitHeight + 0.8, class: 'opening-hit-target'}));
        group.addEventListener('pointerdown', (event) => startElementDrag(event, windowData, 'windows', 'Window'));
        parent.appendChild(group);
    }

    function renderScaleBar(parent, plot, margin) {
        const length = Math.min(10, plot.width / 3);
        const x = margin;
        const y = plot.length + margin + 5;
        parent.appendChild(element('line', {class: 'scale-line', x1: x, y1: y, x2: x + length, y2: y}));
        parent.appendChild(element('line', {class: 'scale-tick', x1: x, y1: y - 1, x2: x, y2: y + 1}));
        parent.appendChild(element('line', {class: 'scale-tick', x1: x + length, y1: y - 1, x2: x + length, y2: y + 1}));
        addText(parent, x + length / 2, y + 3, `Scale bar: ${length} ${plot.unit}`, 'scale-label');
    }

    function renderLayout(current) {
        viewport.innerHTML = '';
        const plot = current.plot;
        const margin = 8;
        const width = plot.width + margin * 2 + Math.abs(plot.x || 0) + 10;
        const height = plot.length + margin * 2 + Math.abs(plot.y || 0) + 10;
        const svg = element('svg', {viewBox: `0 0 ${width} ${height}`, role: 'img', 'aria-label': 'Structured 2D floor plan'});
        const defs = element('defs');
        const pattern = element('pattern', {id: 'plot-grid', width: 2, height: 2, patternUnits: 'userSpaceOnUse'});
        pattern.appendChild(element('path', {d: 'M 2 0 L 0 0 0 2', fill: 'none'}));
        defs.appendChild(pattern);
        const hatch = element('pattern', {id: 'garden-hatch', width: 2, height: 2, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(35)'});
        hatch.appendChild(element('line', {x1: 0, y1: 0, x2: 0, y2: 2, class: 'garden-hatch-line'}));
        defs.appendChild(hatch);
        svg.appendChild(defs);

        const plotGroup = element('g', {id: 'plot', transform: `translate(${margin} ${margin})`});
        plotGroup.appendChild(element('rect', {class: 'plot-fill', x: 0, y: 0, width: plot.width, height: plot.length}));
        plotGroup.appendChild(element('rect', {class: 'plot-grid', x: 0, y: 0, width: plot.width, height: plot.length, fill: 'url(#plot-grid)'}));
        svg.appendChild(plotGroup);

        const spaces = element('g', {id: 'open-spaces', transform: `translate(${margin} ${margin})`});
        if (currentFloor === 0 || currentFloor === 1) {
            (current.parking || []).forEach((space) => renderSpace(spaces, space, 'parking-space'));
            (current.open_spaces || []).forEach((space) => renderSpace(spaces, space, 'open-space'));
        }
        svg.appendChild(spaces);

        if (currentFloor === 0) {
            addText(plotGroup, plot.width / 2, plot.length / 2, 'SITE CONTEXT', 'floor-caption');
            viewport.appendChild(svg);
            updateInfo(current);
            return;
        }

        const plotOriginX = margin + (current.plot?.x || 0);
        const plotOriginY = margin + (current.plot?.y || 0);

        const circulation = element('g', {id: 'circulation', transform: `translate(${plotOriginX} ${plotOriginY})`});
        renderCirculation(circulation, current.circulation, currentFloor);
        svg.appendChild(circulation);

        const plotBoundary = element('g', {id: 'plot-boundary-layer', transform: `translate(${plotOriginX} ${plotOriginY})`});
        renderPlotBoundary(plotBoundary, current.plot);
        svg.appendChild(plotBoundary);

        const rooms = element('g', {id: 'rooms', transform: `translate(${plotOriginX} ${plotOriginY})`});
        (current.rooms || []).filter((room) => (room.floor || 1) === currentFloor).forEach((room) => renderRoom(rooms, room));
        svg.appendChild(rooms);

        const walls = element('g', {id: 'walls', transform: `translate(${plotOriginX} ${plotOriginY})`});
        (current.walls || []).filter((wall) => (wall.floor || 1) === currentFloor).forEach((wall) => renderWall(walls, wall));
        if (!(current.walls || []).length) walls.appendChild(element('rect', {class: 'exterior-wall', x: 0, y: 0, width: plot.width, height: plot.length}));
        svg.appendChild(walls);

        const doors = element('g', {id: 'doors', transform: `translate(${plotOriginX} ${plotOriginY})`});
        (current.doors || []).filter((door) => (door.floor || 1) === currentFloor).forEach((door) => renderDoor(doors, door));
        svg.appendChild(doors);
        const windows = element('g', {id: 'windows', transform: `translate(${plotOriginX} ${plotOriginY})`});
        (current.windows || []).filter((windowData) => (windowData.floor || 1) === currentFloor).forEach((windowData) => renderWindow(windows, windowData));
        svg.appendChild(windows);
        const stairs = element('g', {id: 'stairs', transform: `translate(${plotOriginX} ${plotOriginY})`});
        [...(current.stairs || []), ...(current.stair_arrivals || [])].filter((stair) => (stair.floor || 1) === currentFloor).forEach((stair) => renderStairs(stairs, stair));
        svg.appendChild(stairs);

        const dimensions = element('g', {id: 'dimensions'});
        const floorDimensions = (current.dimensions || []).filter((dimension) => !dimension.floor || dimension.floor === currentFloor);
        if (floorDimensions.length) floorDimensions.forEach((dimension) => renderStructuredDimension(dimensions, dimension, margin));
        else {
            renderDimension(dimensions, margin, margin - 3, margin + plot.width, margin - 3, `${plot.width} ${plot.unit}`, false);
            renderDimension(dimensions, margin - 3, margin, margin - 3, margin + plot.length, `${plot.length} ${plot.unit}`, true);
        }
        svg.appendChild(dimensions);

        const annotations = element('g', {id: 'annotations'});
        addText(annotations, width - 4, 4, 'N', 'north-letter');
        annotations.appendChild(element('path', {class: 'north-arrow', d: `M ${width - 4} 5 L ${width - 5.5} 8 L ${width - 4} 7.2 L ${width - 2.5} 8 Z`}));
        addText(annotations, width - 4, 10, 'diagrammatic', 'north-caption');
        renderScaleBar(annotations, plot, margin);
        addText(annotations, margin, 4, currentFloor === 1 ? 'GROUND FLOOR' : `FLOOR ${currentFloor}`, 'floor-caption', 'start');
        svg.appendChild(annotations);
        viewport.appendChild(svg);
        updateInfo(current);
    }

    function updateInfo(current) {
        const plot = current.plot;
        document.getElementById('plot-summary').textContent = `${plot.width} × ${plot.length} ${plot.unit}`;
        const floorLabel = currentFloor === 1 ? 'ground floor' : `floor ${currentFloor}`;
        document.getElementById('room-count').textContent = `${(current.rooms || []).filter((room) => (room.floor || 1) === currentFloor).length} rooms · ${floorLabel}`;
        document.getElementById('layout-score').textContent = current.score ? current.score.total : '-';
        document.getElementById('scale-summary').textContent = '1 SVG unit = 1 ft';
        document.getElementById('validation-message').textContent = current.validation && current.validation.valid ? 'All hard constraints pass.' : 'This layout requires review.';
        const breakdown = document.getElementById('score-breakdown');
        breakdown.innerHTML = '';
        if (current.score && current.score.breakdown) {
            Object.entries(current.score.breakdown).forEach(([label, value]) => {
                const row = document.createElement('div');
                row.innerHTML = `<span>${label.replaceAll('_', ' ')}</span><strong>${value}</strong><i><b style="width:${Math.min(100, Math.max(0, value))}%"></b></i>`;
                breakdown.appendChild(row);
            });
        }
        const warnings = document.getElementById('warning-list');
        warnings.innerHTML = '';
        (current.validation && current.validation.warnings || []).forEach((warning) => {
            const item = document.createElement('li'); item.textContent = warning; warnings.appendChild(item);
        });
        const list = document.getElementById('room-list');
        list.innerHTML = '';
        (current.rooms || []).filter((room) => (room.floor || 1) === currentFloor).forEach((room) => {
            const item = document.createElement('button');
            item.type = 'button'; item.className = 'room-list-item'; item.dataset.listRoom = room.id;
            item.textContent = `${room.name} · ${room.area} sq ft`;
            item.addEventListener('click', () => document.getElementById(`room-${room.id}`)?.dispatchEvent(new MouseEvent('click')));
            list.appendChild(item);
        });
        const selected = getSelectedItem();
        if (selected) {
            const collection = selectedObject?.type === 'corridor' ? 'corridors' : selectedObject?.type === 'garden' ? 'open_spaces' : selectedObject?.type === 'parking' ? 'parking' : selectedObject?.type === 'wall' ? 'walls' : selectedObject?.type === 'door' ? 'doors' : selectedObject?.type === 'window' ? 'windows' : selectedObject?.type === 'stair' ? 'stairs' : selectedObject?.type === 'furniture' ? 'furniture' : 'rooms';
            if (selectedObject && selectedObject.type === 'room') showRoomInspector(selected);
            else if (selectedObject && selectedObject.type === 'corridor') selectElement(selected, 'corridors', 'Walk');
            else if (selectedElement && selectedElement.item && selectedElement.item.id === selected.id) selectElement(selected, collection, selectedElement.label || selectedObject?.type || 'Object');
            else if (collection === 'open_spaces' || collection === 'parking') selectElement(selected, collection, collection === 'parking' ? 'Parking' : 'Garden');
            else if (collection === 'corridors') selectElement(selected, collection, 'Walk');
            else if (collection === 'walls') selectElement(selected, collection, 'Wall');
            else if (collection === 'doors') selectElement(selected, collection, 'Door');
            else if (collection === 'windows') selectElement(selected, collection, 'Window');
            else if (collection === 'stairs') selectElement(selected, collection, 'Stair');
            else if (collection === 'furniture') selectElement(selected, collection, 'Furniture');
        }
        document.getElementById('candidate-name').textContent = current.candidate_id || 'Recommended';
        document.querySelectorAll('[data-floor]').forEach((button) => button.classList.toggle('is-active', Number(button.dataset.floor) === currentFloor));
    }

    async function applyRoomSize() {
        const room = currentLayout.rooms.find((item) => item.id === selectedRoomId);
        if (!room) return;
        snapshot();
        const previousGeometry = {x: room.x, y: room.y, width: room.width, height: room.height};
        room.x = Number(document.getElementById('element-x').value);
        room.y = Number(document.getElementById('element-y').value);
        room.width = Number(document.getElementById('element-width').value);
        room.height = Number(document.getElementById('element-height').value);
        room.area = Math.round(room.width * room.height * 100) / 100;
        resizeAttachedOpenings(room, previousGeometry);
        const result = validateLocal(currentLayout);
        if (!result.valid) {
            setStatus(result.errors.join(' '), 'error');
        } else {
            await requestEvaluation();
            setStatus('Room geometry updated.', 'success');
        }
        renderLayout(currentLayout);
    }

    function resizeAttachedOpenings(room, previousGeometry) {
        (currentLayout.doors || []).concat(currentLayout.windows || []).forEach((opening) => {
            if (opening.room_id !== room.id && opening.connects_to !== room.id) return;
            const length = opening.width || 1;
            const wasHorizontal = opening.orientation !== 'vertical';
            const oldTop = Math.abs(opening.y - previousGeometry.y) < 0.1;
            const oldBottom = Math.abs(opening.y - (previousGeometry.y + previousGeometry.height)) < 0.1;
            const oldLeft = Math.abs(opening.x - previousGeometry.x) < 0.1;
            const oldRight = Math.abs(opening.x - (previousGeometry.x + previousGeometry.width)) < 0.1;
            if (wasHorizontal && (oldTop || oldBottom)) {
                opening.orientation = 'horizontal';
                opening.y = oldBottom ? room.y + room.height : room.y;
                opening.x = Math.min(Math.max(room.x, opening.x), room.x + room.width - length);
            } else if (!wasHorizontal && (oldLeft || oldRight)) {
                opening.orientation = 'vertical';
                opening.x = oldRight ? room.x + room.width : room.x;
                opening.y = Math.min(Math.max(room.y, opening.y), room.y + room.height - length);
            } else {
                snapToRoomBoundary(opening);
            }
        });
    }

    async function applyElementChanges() {
        if (selectedObject?.type === 'room') {
            await applyRoomSize();
            return;
        }
        if (!selectedElement) return;
        const {item, collection} = selectedElement;
        snapshot();
        item.x = Number(document.getElementById('element-x').value);
        item.y = Number(document.getElementById('element-y').value);
        if (collection !== 'doors' && collection !== 'windows') {
            if (collection === 'walls') item.length = Number(document.getElementById('element-width').value);
            else {
                item.width = Number(document.getElementById('element-width').value);
                item.height = Number(document.getElementById('element-height').value);
                if (item.area !== undefined) item.area = Math.round(item.width * item.height * 100) / 100;
            }
        }
        if (['doors', 'windows', 'walls'].includes(collection)) item.orientation = document.getElementById('element-orientation').value;
        if (collection === 'doors') item.swing = document.getElementById('element-swing').value;
        if (collection === 'doors' || collection === 'windows') snapToRoomBoundary(item);
        if (collection === 'rooms') currentLayout._recalculate_circulation = true;
        renderLayout(currentLayout);
        const valid = await requestEvaluation();
        if (!valid) {
            setStatus('The edited object remains in place, but validation still requires review.', 'warning');
        } else {
            setStatus('Object changes applied and saved in the current layout.', 'success');
        }
    }

    function deleteSelectedElement() {
        if (!selectedElement || selectedElement.collection === 'rooms') {
            setStatus('Rooms are required by the generated program and cannot be deleted here.', 'error');
            return;
        }
        snapshot();
        const {item, collection} = selectedElement;
        if (collection === 'furniture') {
            (currentLayout.rooms || []).forEach((room) => { room.furniture = (room.furniture || []).filter((entry) => entry.id !== item.id); });
            currentLayout.furniture = (currentLayout.furniture || []).filter((entry) => entry.id !== item.id);
        } else if (collection === 'corridors') {
            if (currentLayout.circulation) currentLayout.circulation.corridors = (currentLayout.circulation.corridors || []).filter((entry) => entry.id !== item.id);
        } else {
            currentLayout[collection] = (currentLayout[collection] || []).filter((entry) => entry.id !== item.id);
        }
        selectedElement = null;
        document.getElementById('room-inspector').hidden = true;
        renderLayout(currentLayout);
        requestEvaluation();
    }

    function nextId(prefix, collection) {
        const ids = collection.map((item) => item.id);
        let index = 1;
        while (ids.includes(`${prefix}_${index}`)) index += 1;
        return `${prefix}_${index}`;
    }

    function editingRoom() {
        return currentLayout.rooms.find((room) => (room.floor || 1) === currentFloor) || currentLayout.rooms[0];
    }

    function addOpening(kind) {
        const room = editingRoom();
        if (!room) return;
        snapshot();
        const isDoor = kind === 'door';
        const collection = isDoor ? 'doors' : 'windows';
        const item = {
            id: nextId(kind, currentLayout[collection] || []), type: kind, room_id: room.id,
            floor: room.floor || 1, x: room.x + room.width / 2 - (isDoor ? 1.25 : 1.5),
            y: room.y, width: isDoor ? 2.5 : 3, orientation: 'horizontal',
            ...(isDoor ? {swing: 'right', connects_from: 'exterior', connects_to: room.id, exterior: true} : {wall: 'north', wall_side: 'north'}),
        };
        currentLayout[collection] = [...(currentLayout[collection] || []), item];
        selectElement(item, collection, isDoor ? 'Door' : 'Window');
        renderLayout(currentLayout);
        requestEvaluation();
    }

    function addWall() {
        const room = editingRoom();
        if (!room) return;
        snapshot();
        const wall = {id: nextId('wall', currentLayout.walls || []), type: 'interior', floor: room.floor || 1, orientation: 'vertical', x: room.x, y: room.y, length: room.height, thickness: 0.25, rooms: [room.id]};
        currentLayout.walls = [...(currentLayout.walls || []), wall];
        selectElement(wall, 'walls', 'Wall');
        renderLayout(currentLayout);
        requestEvaluation();
    }

    function addWalk() {
        const room = editingRoom();
        if (!room) return;
        snapshot();
        if (!currentLayout.circulation) currentLayout.circulation = {corridors: []};
        const corridor = {
            id: nextId('walk', currentLayout.circulation.corridors || []),
            type: 'corridor',
            floor: room.floor || 1,
            x: Math.max(0, room.x - 4),
            y: room.y + room.height + 1,
            width: Math.min(4, room.x),
            height: Math.min(room.height, currentLayout.plot.length - (room.y + room.height + 1)),
            area: 0,
            width_clear: 4,
            spine: true,
        };
        corridor.area = corridor.width * corridor.height;
        currentLayout.circulation.corridors = [...(currentLayout.circulation.corridors || []), corridor];
        selectElement(corridor, 'corridors', 'Walk');
        renderLayout(currentLayout);
        requestEvaluation();
    }

    function addFurniture() {
        const room = editingRoom();
        if (!room) return;
        snapshot();
        const item = {id: nextId(`${room.id}_sofa`, currentLayout.furniture || []), type: 'sofa', room_id: room.id, floor: room.floor || 1, x: room.x + 1, y: room.y + 1, width: 4, height: 1.5};
        room.furniture = [...(room.furniture || []), item];
        currentLayout.furniture = [...(currentLayout.furniture || []), item];
        selectElement(item, 'furniture', 'sofa');
        renderLayout(currentLayout);
        requestEvaluation();
    }

    function undo() {
        if (!undoStack.length) return;
        redoStack.push(clone(currentLayout));
        currentLayout = undoStack.pop();
        renderLayout(currentLayout);
        requestEvaluation();
    }

    function redo() {
        if (!redoStack.length) return;
        undoStack.push(clone(currentLayout));
        currentLayout = redoStack.pop();
        renderLayout(currentLayout);
        requestEvaluation();
    }

    async function save() {
        const saveButton = document.querySelector('[data-editor-action="save"]');
        if (saveButton) {
            saveButton.disabled = true;
            saveButton.classList.add('is-saving');
            saveButton.textContent = 'Saving…';
        }
        setStatus('Saving your customized floor plan…', 'info');
        try {
            const evaluation = await requestEvaluation();
            const response = await fetch(`${designRoot()}/save-layout/`, {method: 'POST', headers: {'Content-Type': 'application/json', 'X-CSRFToken': csrfToken()}, body: JSON.stringify({layout: currentLayout})});
            const result = await response.json();
            if (result.success && result.layout) {
                currentLayout = result.layout;
            }
            const warningText = result.saved_with_warnings || result.warnings?.length ? ` Changes saved successfully, but validation reported issues: ${[...(result.errors || []), ...(result.warnings || [])].join(' ')}` : 'Changes saved successfully.';
            setStatus(result.success ? (result.saved_with_warnings ? warningText : 'Changes saved successfully.') : (result.errors || ['The design could not be saved.']).join(' '), result.success ? (result.saved_with_warnings ? 'warning' : 'success') : 'error');
            return result;
        } finally {
            if (saveButton) {
                saveButton.disabled = false;
                saveButton.classList.remove('is-saving');
                saveButton.textContent = 'Save';
            }
        }
    }

    async function regenerate() {
        const response = await fetch(`${designRoot()}/regenerate/`, {method: 'POST', headers: {'X-CSRFToken': csrfToken()}});
        const result = await response.json();
        if (!result.success) { setStatus((result.errors || ['Regeneration failed.']).join(' '), 'error'); return; }
        snapshot();
        currentLayout = result.layout;
        selectedRoomId = null;
        renderLayout(currentLayout);
        setStatus('A new layout was generated from the original requirements.', 'success');
    }

    document.querySelectorAll('.plan-control[data-zoom]').forEach((button) => button.addEventListener('click', () => {
        const action = button.dataset.zoom;
        if (action === 'in') zoom = Math.min(zoom + 0.15, 2.5);
        if (action === 'out') zoom = Math.max(zoom - 0.15, 0.65);
        if (action === 'reset') zoom = 1;
        viewport.style.setProperty('--plan-zoom', zoom);
    }));

    bindIfExists('[data-editor-action="undo"]', undo);
    bindIfExists('[data-editor-action="redo"]', redo);
    bindIfExists('[data-editor-action="delete"]', deleteSelectedElement);
    bindIfExists('[data-editor-action="add-door"]', () => addOpening('door'));
    bindIfExists('[data-editor-action="add-window"]', () => addOpening('window'));
    bindIfExists('[data-editor-action="add-wall"]', addWall);
    bindIfExists('[data-editor-action="add-walk"]', addWalk);
    bindIfExists('[data-editor-action="add-furniture"]', addFurniture);
    bindIfExists('[data-editor-action="reset"]', () => { snapshot(); currentLayout = clone(originalLayout); renderLayout(currentLayout); requestEvaluation(); setStatus('Reset to generated design.', 'success'); });
    bindIfExists('[data-editor-action="save"]', save);

    const exportLink = document.querySelector('a[href$="/export.svg"]');
    if (exportLink) {
        exportLink.addEventListener('click', async (event) => {
            event.preventDefault();
            const exportButton = exportLink.closest('button') || exportLink;
            if (exportButton) {
                exportButton.disabled = true;
                exportButton.classList.add('is-exporting');
                exportButton.textContent = 'Exporting…';
            }
            setStatus('Saving the latest customization before export…', 'info');
            const result = await save();
            if (!result || !result.success) {
                if (exportButton) {
                    exportButton.disabled = false;
                    exportButton.classList.remove('is-exporting');
                    exportButton.textContent = 'Export SVG';
                }
                setStatus('The customized floor plan could not be exported.', 'error');
                return;
            }
            setStatus('Generating the customized SVG export…', 'info');
            try {
                const response = await fetch(exportLink.href, {method: 'GET', headers: {'X-CSRFToken': csrfToken()}});
                if (!response.ok) throw new Error('Export failed');
                const blob = await response.blob();
                const url = URL.createObjectURL(blob);
                const filename = response.headers.get('Content-Disposition')?.match(/filename="?([^";]+)"?/)?.[1] || 'dream-home-customized.svg';
                const anchor = document.createElement('a');
                anchor.href = url;
                anchor.download = filename;
                document.body.appendChild(anchor);
                anchor.click();
                anchor.remove();
                URL.revokeObjectURL(url);
                setStatus('Customized floor plan exported successfully.', 'success');
            } catch (error) {
                setStatus('The customized floor plan could not be exported.', 'error');
            } finally {
                if (exportButton) {
                    exportButton.disabled = false;
                    exportButton.classList.remove('is-exporting');
                    exportButton.textContent = 'Export SVG';
                }
            }
        });
    }

    document.querySelectorAll('.toolbar-tool[data-tool]').forEach((button) => {
        button.addEventListener('click', () => {
            const tool = button.dataset.tool;
            document.querySelectorAll('.toolbar-tool[data-tool]').forEach((candidate) => {
                const active = candidate === button;
                candidate.setAttribute('aria-pressed', String(active));
                candidate.classList.toggle('is-active', active);
            });
            if (tool === 'delete') {
                deleteSelectedElement();
                return;
            }
            setStatus(`Tool selected: ${tool}.`, 'info');
        });
    });

    const applyButton = document.getElementById('apply-element-changes');
    if (applyButton) applyButton.addEventListener('click', applyElementChanges);
    const deleteButton = document.getElementById('delete-selected-element');
    if (deleteButton) deleteButton.addEventListener('click', deleteSelectedElement);

    const availableFloors = [...new Set((currentLayout.rooms || []).map((room) => room.floor || 1))].sort((a, b) => a - b);
    const floorTabs = document.getElementById('floor-tabs');
    if (floorTabs && availableFloors.length) {
        const siteButton = document.createElement('button');
        siteButton.type = 'button'; siteButton.className = 'btn btn-outline floor-tab'; siteButton.dataset.floor = 0;
        siteButton.textContent = 'Site';
        siteButton.addEventListener('click', () => { currentFloor = 0; renderLayout(currentLayout); });
        floorTabs.appendChild(siteButton);
        availableFloors.forEach((floor) => {
            const button = document.createElement('button');
            button.type = 'button'; button.className = 'btn btn-outline floor-tab'; button.dataset.floor = floor;
            button.textContent = floor === 1 ? 'Ground floor' : `Floor ${floor}`;
            button.addEventListener('click', () => { currentFloor = floor; renderLayout(currentLayout); });
            floorTabs.appendChild(button);
        });
    }
    renderLayout(currentLayout);
}());
