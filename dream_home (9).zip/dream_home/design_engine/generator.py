"""Deterministic candidate layout generation."""

from copy import deepcopy
from typing import Any

from .analyzer import PlanningSpec
from .architectural_elements import generate_architectural_elements
from .bathroom_planner import apply_bathroom_relationships, assign_bathrooms
from .circulation import plan_circulation
from .constraints import validate_layout
from .rules import ROOM_RULES, ROOM_ZONES
from .scorer import adjacency_score, score_layout


class GenerationError(ValueError):
    """Raised when no candidate can be generated for the requirements."""


# Visual/structural gap inserted between rooms that share a row, so two rooms of the
# same type (e.g. two bathrooms) never render as a single flush, unlabelled block.
WALL_GAP = 0.15

# Circulation gap inserted between the public/semi-private/service zone and the private
# zone, so the plan reads as "front rooms -> corridor -> bedrooms" instead of one
# undifferentiated grid.
CORRIDOR_WIDTH = 4.0


def _geometry(room_id: str, name: str, room_type: str, x: float, y: float, width: float, height: float, floor: int = 1) -> dict[str, Any]:
    normalized_width = round(width, 2)
    normalized_height = round(height, 2)
    return {
        'id': room_id, 'name': name, 'type': room_type,
        'x': round(x, 2), 'y': round(y, 2),
        'width': normalized_width, 'height': normalized_height,
        'area': normalized_width * normalized_height, 'floor': floor,
        'zone': ROOM_ZONES.get(room_type, 'semi_private'),
        'doors': [], 'windows': [], 'furniture': [], 'adjacency': [],
    }


def _reserved_spaces(spec: PlanningSpec, site_variant: str = 'front_left') -> tuple[list[dict[str, Any]], list[dict[str, Any]], float]:
    parking = []
    parking_width = ROOM_RULES['parking']['min_width']
    parking_height = ROOM_RULES['parking']['min_height']
    if spec.parking_count * parking_width > spec.plot_width:
        raise GenerationError('The requested parking spaces cannot fit within the supplied plot.')
    parking_origin = 0.0
    if site_variant == 'front_right':
        parking_origin = spec.plot_width - spec.parking_count * parking_width
    for index in range(spec.parking_count):
        x = parking_origin + index * parking_width
        parking.append({
            'id': f'parking_{index + 1}', 'type': 'parking', 'x': x, 'y': 0.0,
            'width': parking_width, 'height': parking_height, 'area': parking_width * parking_height,
        })
    open_spaces = []
    if spec.features.get('garden_open_space'):
        garden_x = spec.parking_count * parking_width if site_variant != 'front_right' else 0.0
        garden_width = spec.plot_width - spec.parking_count * parking_width
        garden_height = min(ROOM_RULES['garden']['min_height'], spec.plot_length)
        if garden_width < ROOM_RULES['garden']['min_width'] or garden_height < ROOM_RULES['garden']['min_height']:
            raise GenerationError('The requested garden/open space cannot fit within the supplied plot.')
        open_spaces.append({
            'id': 'garden_1', 'type': 'garden', 'x': garden_x, 'y': 0.0,
            'width': garden_width, 'height': garden_height, 'area': garden_width * garden_height,
        })
    reserved_depth = max([item['height'] for item in [*parking, *open_spaces]] or [0.0])
    return parking, open_spaces, reserved_depth


def _target_dimensions(requirement: Any, available_width: float, swap: bool = False) -> tuple[float, float]:
    rule = ROOM_RULES[requirement.room_type]
    area = rule.get('preferred_area', rule['min_width'] * rule['min_height'])
    aspect = max(rule.get('preferred_aspect', 1.0), 1 / rule.get('preferred_aspect', 1.0))
    width = max(rule['min_width'], (area * aspect) ** 0.5)
    height = max(rule['min_height'], area / width)
    if width > available_width:
        width = available_width
        height = max(rule['min_height'], area / width)
    if swap:
        width, height = height, width
    return round(width, 2), round(height, 2)


def _pack_zone(spec: PlanningSpec, requirements: list[Any], swap: bool, start_y: float) -> tuple[list[dict[str, Any]], float]:
    """Allocate target-sized rooms in bounded rows beside a real circulation spine."""
    usable_width = spec.plot_width - CORRIDOR_WIDTH
    if usable_width <= 0:
        raise GenerationError('The plot is too narrow for a circulation spine.')
    row_plan: list[tuple[list[dict[str, Any]], float]] = []
    current_row: list[dict[str, Any]] = []
    current_row_width = 0.0
    row_height = 0.0
    y = start_y

    for requirement in requirements:
        width, height = _target_dimensions(requirement, usable_width, swap)
        if width > usable_width:
            raise GenerationError(f'{requirement.name} cannot fit within the plot width.')
        gap = WALL_GAP if current_row else 0.0
        if current_row and current_row_width + gap + width > usable_width:
            row_plan.append((current_row, row_height))
            current_row, current_row_width, row_height = [], 0.0, 0.0
            gap = 0.0
        x_offset = CORRIDOR_WIDTH + current_row_width + gap
        current_row.append({'requirement': requirement, 'x': x_offset, 'width': width, 'height': height})
        current_row_width += gap + width
        row_height = max(row_height, height)
    if current_row:
        row_plan.append((current_row, row_height))

    rooms: list[dict[str, Any]] = []
    for row_items, r_height in row_plan:
        if row_items:
            row_items[-1]['x'] = spec.plot_width - row_items[-1]['width']
        for item in row_items:
            requirement = item['requirement']
            room = _geometry(requirement.id, requirement.name, requirement.room_type, item['x'], y, item['width'], r_height)
            rooms.append(room)
        y += r_height + WALL_GAP

    end_y = y - WALL_GAP if rooms else start_y
    return rooms, end_y


def _interleave_balconies(requirements: list[Any]) -> list[Any]:
    """Move each balcony so it sits immediately after the bedroom it serves. Because
    _pack_zone places consecutive items in a row touching one another, this makes the
    balcony attach directly to its bedroom's wall instead of landing in an unrelated
    leftover gap."""
    balconies = [r for r in requirements if r.room_type == 'balcony']
    if not balconies:
        return requirements
    ordered: list[Any] = []
    balcony_iter = iter(balconies)
    index = 0
    while index < len(requirements):
        requirement = requirements[index]
        if requirement.room_type == 'balcony':
            index += 1
            continue
        ordered.append(requirement)
        if requirement.room_type == 'bedroom':
            index += 1
            while index < len(requirements) and requirements[index].room_type == 'bathroom':
                ordered.append(requirements[index])
                index += 1
            balcony = next(balcony_iter, None)
            if balcony is not None:
                ordered.append(balcony)
            continue
        index += 1
    ordered.extend(balcony_iter)
    return ordered


def _compact_rooms_to_fit(rooms: list[dict[str, Any]], spec: PlanningSpec, reserved_depth: float) -> list[dict[str, Any]]:
    """Shrink the generated room block proportionally when the rigid row stacking exceeds the plot depth."""
    if not rooms:
        return rooms
    max_x = max(room['x'] + room['width'] for room in rooms)
    max_y = max(room['y'] + room['height'] for room in rooms)
    scaling = 1.0
    if max_x > spec.plot_width:
        scaling = min(scaling, spec.plot_width / max_x)
    if max_y > spec.plot_length:
        available_height = max(0.0, spec.plot_length - reserved_depth)
        used_height = max(0.0, max_y - reserved_depth)
        scaling = min(scaling, available_height / used_height if used_height > 0 else 1.0)
    if scaling >= 1.0:
        return rooms
    for room in rooms:
        room['x'] = round(room['x'] * scaling, 2)
        room['y'] = round(reserved_depth + (room['y'] - reserved_depth) * scaling, 2)
        room['width'] = round(room['width'] * scaling, 2)
        room['height'] = round(room['height'] * scaling, 2)
        room['area'] = round(room['width'] * room['height'], 2)
    return rooms


def _pack_rooms(
    spec: PlanningSpec,
    order: list[Any],
    swap: bool,
    reserved_depth: float,
    floor: int = 1,
    bathroom_assignments: dict[str, dict[str, Any]] | None = None,
    zone_blocks: tuple[tuple[str, ...], ...] | None = None,
    room_priority: tuple[str, ...] = (),
) -> list[dict[str, Any]]:
    """Allocate a residential program using explicit strategy zone blocks."""
    zones: dict[str, list[Any]] = {'public': [], 'semi_private': [], 'service': [], 'private': []}
    for requirement in order:
        relationship = (bathroom_assignments or {}).get(requirement.id, {})
        zone = 'private' if relationship.get('kind') == 'attached' else ROOM_ZONES.get(requirement.room_type, 'semi_private')
        zones.setdefault(zone, []).append(requirement)

    priority = {room_type: index for index, room_type in enumerate(room_priority)}

    def ordered(items: list[Any]) -> list[Any]:
        return sorted(items, key=lambda item: priority.get(item.room_type, len(priority)))

    rooms: list[dict[str, Any]] = []
    y = reserved_depth
    blocks = zone_blocks or (('public', 'semi_private', 'service'), ('private',))
    for block_index, block in enumerate(blocks):
        block_items = ordered([item for zone in block for item in zones.get(zone, [])])
        if not block_items:
            continue
        if 'private' in block:
            bedrooms = [item for item in block_items if item.room_type == 'bedroom']
            attached = [item for item in block_items if item.room_type == 'bathroom']
            private = []
            for bedroom in bedrooms:
                private.append(bedroom)
                private.extend(item for item in attached if (bathroom_assignments or {}).get(item.id, {}).get('attached_to') == bedroom.id)
            private.extend(item for item in block_items if item not in private)
            block_items = _interleave_balconies(private)
        packed, y = _pack_zone(spec, block_items, swap, y + (WALL_GAP if block_index else 0.0))
        rooms.extend(packed)

    for room in rooms:
        room['floor'] = floor

    if y > spec.plot_length:
        rooms = _compact_rooms_to_fit(rooms, spec, reserved_depth)
        if any(room['x'] + room['width'] > spec.plot_width or room['y'] + room['height'] > spec.plot_length for room in rooms):
            raise GenerationError('The requested rooms cannot fit within the supplied plot.')

    return rooms


def _floor_orders(
    spec: PlanningSpec,
    order: list[Any],
    reserved_depth: float = 0.0,
    bathroom_assignments: dict[str, dict[str, Any]] | None = None,
) -> list[list[Any]]:
    """Keep the public house base on ground level and distribute private rooms above it."""
    if spec.floors == 1:
        return [order]
    floors = [[] for _ in range(spec.floors)]
    ground_types = {'public', 'semi_private', 'service'}
    assignments = bathroom_assignments or {}
    ground = [
        item for item in order
        if ROOM_ZONES.get(item.room_type) in ground_types
        and not assignments.get(item.id, {}).get('attached_to')
    ]
    private = [
        item for item in order
        if ROOM_ZONES.get(item.room_type) == 'private'
        or assignments.get(item.id, {}).get('attached_to')
    ]
    floors[0].extend(ground)
    floor_loads = [0.0] * spec.floors
    for item in ground:
        floor_loads[0] += ROOM_RULES[item.room_type]['min_width'] * ROOM_RULES[item.room_type]['min_height']
    by_id = {item.id: item for item in private}
    groups = []
    grouped_ids = set()
    for requirement in private:
        if requirement.id in grouped_ids or assignments.get(requirement.id, {}).get('attached_to'):
            continue
        group = [requirement]
        attached = by_id.get(next((item_id for item_id, relation in assignments.items() if relation.get('attached_to') == requirement.id), ''))
        if attached:
            group.append(attached)
        grouped_ids.update(item.id for item in group)
        groups.append(group)
    for group in sorted(
        groups,
        key=lambda items: sum(ROOM_RULES[item.room_type]['min_width'] * ROOM_RULES[item.room_type]['min_height'] for item in items),
        reverse=True,
    ):
        floor_index = min(range(spec.floors), key=lambda index: floor_loads[index] if index else float('inf'))
        if floor_index == 0:
            floor_index = 1
        floors[floor_index].extend(group)
        floor_loads[floor_index] += sum(
            ROOM_RULES[item.room_type]['min_width'] * ROOM_RULES[item.room_type]['min_height']
            for item in group
        )
    if not private and not ground:
        floors[0].extend(order)
    return floors


def _balanced_floor_orders(spec: PlanningSpec, order: list[Any], reserved_depth: float = 0.0) -> list[list[Any]]:
    """Compatibility fallback for compact plots where the coordinated base cannot fit."""
    floors = [[] for _ in range(spec.floors)]
    floor_loads = [reserved_depth * spec.plot_width * 0.25] + [0.0] * (spec.floors - 1)
    requirements = sorted(
        order,
        key=lambda item: ROOM_RULES[item.room_type]['min_width'] * ROOM_RULES[item.room_type]['min_height'],
        reverse=True,
    )
    for requirement in requirements:
        floor_index = min(range(spec.floors), key=lambda index: floor_loads[index])
        floors[floor_index].append(requirement)
        floor_loads[floor_index] += ROOM_RULES[requirement.room_type]['min_width'] * ROOM_RULES[requirement.room_type]['min_height']
    return floors


def _attach_bathrooms(
    rooms: list[dict[str, Any]],
    assignments: dict[str, dict[str, Any]],
    plot_width: float | None = None,
    plot_length: float | None = None,
) -> None:
    by_id = {room['id']: room for room in rooms}
    for bathroom_id, relationship in assignments.items():
        target = by_id.get(relationship.get('attached_to'))
        bathroom = by_id.get(bathroom_id)
        if not target or not bathroom or target.get('floor', 1) != bathroom.get('floor', 1):
            continue
        right_x = target['x'] + target['width']
        candidates = [
            (right_x, target['y']),
            (target['x'] - bathroom['width'], target['y']),
            (target['x'], target['y'] + target['height']),
            (target['x'], target['y'] - bathroom['height']),
        ]
        for candidate_x, candidate_y in candidates:
            overlaps_other = any(
                room is not bathroom and room is not target
                and room.get('floor', 1) == target.get('floor', 1)
                and candidate_x < room['x'] + room['width']
                and candidate_x + bathroom['width'] > room['x']
                and candidate_y < room['y'] + room['height']
                and candidate_y + bathroom['height'] > room['y']
                for room in rooms
            )
            if (
                candidate_x >= 0 and candidate_y >= 0
                and (plot_width is None or candidate_x + bathroom['width'] <= plot_width)
                and (plot_length is None or candidate_y + bathroom['height'] <= plot_length)
                and not overlaps_other
            ):
                bathroom['x'] = round(candidate_x, 2)
                bathroom['y'] = round(candidate_y, 2)
                break


STRATEGY_DEFINITIONS = (
    {
        'id': 'central_living_core', 'name': 'Central Living / Common Core',
        'blocks': (('public', 'semi_private'), ('service',), ('private',)),
        'priority': ('living', 'dining', 'kitchen', 'bathroom', 'utility', 'storage', 'bedroom', 'study', 'prayer', 'balcony'),
        'site': 'front_left', 'corridor': 'central_common',
    },
    {
        'id': 'side_corridor', 'name': 'Side Corridor Plan',
        'blocks': (('public', 'semi_private', 'service'), ('private',)),
        'priority': ('kitchen', 'utility', 'bathroom', 'living', 'dining', 'bedroom', 'study', 'prayer', 'storage', 'balcony'),
        'site': 'front_right', 'corridor': 'side', 'swap': False,
    },
    {
        'id': 'front_public_rear_private', 'name': 'Front Public / Rear Private',
        'blocks': (('public',), ('semi_private', 'service'), ('private',)),
        'priority': ('living', 'dining', 'kitchen', 'bathroom', 'utility', 'storage', 'bedroom', 'study', 'prayer', 'balcony'),
        'site': 'front_left', 'corridor': 'front_rear', 'swap': False,
    },
    {
        'id': 'split_zoned', 'name': 'Split Zoned Plan',
        'blocks': (('public',), ('private',), ('semi_private', 'service')),
        'priority': ('living', 'dining', 'bedroom', 'study', 'prayer', 'balcony', 'kitchen', 'bathroom', 'utility', 'storage'),
        'site': 'front_right', 'corridor': 'split_zone', 'swap': False,
    },
    {
        'id': 'courtyard_oriented', 'name': 'Courtyard / Open-Space Oriented',
        'blocks': (('public',), ('semi_private',), ('private',), ('service',)),
        'priority': ('living', 'dining', 'kitchen', 'bedroom', 'bathroom', 'utility', 'storage', 'study', 'prayer', 'balcony'),
        'site': 'front_left', 'corridor': 'courtyard', 'swap': False,
    },
    {
        'id': 'reverse_entry', 'name': 'Reverse / Alternate Entry',
        'blocks': (('private',), ('service', 'semi_private'), ('public',)),
        'priority': ('bedroom', 'study', 'prayer', 'balcony', 'bathroom', 'utility', 'storage', 'living', 'dining', 'kitchen'),
        'site': 'front_right', 'corridor': 'reverse_entry', 'swap': False,
    },
)


def _strategy_orders(spec: PlanningSpec, architectural_intent: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    base = list(spec.rooms)
    public = [room for room in base if ROOM_ZONES.get(room.room_type) == 'public']
    semi_private = [room for room in base if ROOM_ZONES.get(room.room_type) == 'semi_private']
    private = [room for room in base if ROOM_ZONES.get(room.room_type) == 'private']
    service = [room for room in base if ROOM_ZONES.get(room.room_type) == 'service']
    by_type = {room_type: [room for room in base if room.room_type == room_type] for room_type in ROOM_RULES}
    strategies = []
    for definition in STRATEGY_DEFINITIONS:
        ordered = [room for room_type in definition['priority'] for room in by_type.get(room_type, [])]
        strategies.append({**definition, 'order': ordered, 'swap': definition.get('swap', False)})
    strategy = (architectural_intent or {}).get('circulation_strategy')
    revision_actions = ' '.join(str(item) for item in (architectural_intent or {}).get('revision_actions', []))
    if 'central circulation' in revision_actions or 'strengthen central' in revision_actions:
        strategy = 'central_corridor'
    elif 'side circulation' in revision_actions:
        strategy = 'side_corridor'
    if strategy == 'side_corridor':
        strategies = [strategies[1], strategies[3], strategies[4], strategies[0], strategies[5], strategies[2]]
    elif strategy == 'public_private_split':
        strategies = [strategies[3], strategies[0], strategies[4], strategies[1], strategies[5], strategies[2]]
    elif strategy == 'front_public_rear_private':
        strategies = [strategies[0], strategies[4], strategies[1], strategies[3], strategies[5], strategies[2]]
    return strategies


def generate_candidates(
    spec: PlanningSpec,
    candidate_count: int = 6,
    seed: int = 0,
    architectural_intent: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    strategies = _strategy_orders(spec, architectural_intent)
    bathroom_assignments = assign_bathrooms(list(spec.rooms))
    candidates = []
    for index in range(min(max(candidate_count, 1), len(strategies))):
        strategy = strategies[(index + seed) % len(strategies)]
        order = strategy['order']
        swap = strategy['swap']
        parking, open_spaces, reserved_depth = _reserved_spaces(spec, strategy['site'])
        rooms = []
        allocations = [_floor_orders(spec, order, reserved_depth, bathroom_assignments)]
        if spec.floors > 1:
            allocations.append(_balanced_floor_orders(spec, order, reserved_depth))
        for allocation in allocations:
            rooms = []
            try:
                for floor, floor_order in enumerate(allocation, start=1):
                    if not floor_order:
                        continue
                    floor_reserved_depth = reserved_depth if floor == 1 else 0.0
                    rooms.extend(_pack_rooms(
                        spec,
                        floor_order,
                        swap=swap,
                        reserved_depth=floor_reserved_depth,
                        floor=floor,
                        bathroom_assignments=bathroom_assignments,
                        zone_blocks=strategy['blocks'],
                        room_priority=tuple(strategy['priority']),
                    ))
                break
            except GenerationError:
                rooms = []
        if not rooms and strategies:
            fallback = strategies[0]
            fallback_order = fallback['order']
            try:
                fallback_allocations = _floor_orders(spec, fallback_order, reserved_depth, bathroom_assignments)
                rooms = []
                for floor, floor_order in enumerate(fallback_allocations, start=1):
                    if floor_order:
                        rooms.extend(_pack_rooms(
                            spec, floor_order, False,
                            reserved_depth if floor == 1 else 0.0,
                            floor, bathroom_assignments,
                            fallback['blocks'], tuple(fallback['priority']),
                        ))
            except GenerationError:
                rooms = []
        if not rooms:
            continue
        _attach_bathrooms(rooms, bathroom_assignments, spec.plot_width, spec.plot_length)
        apply_bathroom_relationships(rooms, bathroom_assignments)
        architectural = generate_architectural_elements(rooms, parking, spec.plot, spec.floors)
        circulation = plan_circulation(rooms, spec.plot_width)
        layout = {
            'plot': spec.plot, 'rooms': rooms, **architectural,
            'parking': parking, 'open_spaces': open_spaces, 'adjacency': {},
            'site_analysis': {
                'orientation': 'north_up', 'front_side': 'north', 'road_side': 'north',
                'entrance_side': 'north', 'reserved_depth': reserved_depth,
                'buildable_region': {'x': 0.0, 'y': reserved_depth, 'width': spec.plot_width, 'length': spec.plot_length - reserved_depth},
                'parking_ids': [item['id'] for item in parking],
                'open_space_ids': [item['id'] for item in open_spaces],
            },
            'circulation': circulation,
            'architectural_intent': architectural_intent or {},
            'score': None, 'validation': None, 'candidate_id': f'candidate_{index + 1}',
            'strategy': strategy['id'], 'strategy_name': strategy['name'],
            'strategy_metadata': {
                'zone_blocks': strategy['blocks'], 'corridor_strategy': strategy['corridor'],
                'site_variant': strategy['site'],
            },
        }
        _, adjacency = adjacency_score(layout)
        layout['adjacency'] = adjacency
        validation = validate_layout(layout, spec)
        layout['validation'] = validation
        if validation['valid']:
            total, breakdown = score_layout(layout, spec)
            layout['score'] = {'total': total, 'breakdown': breakdown}
        candidates.append(layout)
    return candidates
