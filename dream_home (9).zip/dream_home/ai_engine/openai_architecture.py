"""Optional OpenAI architectural planner and reviewer using structured JSON only."""

import json
import os
from json import JSONDecodeError
from typing import Any, Callable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from django.conf import settings

from .architectural_intent import ArchitecturalIntent, IntentError, normalize_intent


class OpenAIArchitectureError(ValueError):
    """Raised when the configured OpenAI architecture layer fails safely."""


PLANNER_SYSTEM_PROMPT = '''You are an architectural planning assistant for DREAM HOME.
Return exactly one JSON object and no Markdown. Do not output SVG, coordinates, pixels, or geometry.
Convert the user's requirements into structured architectural intent.
The root object must contain: requirements, room_priorities, zoning, adjacency_preferences,
privacy_requirements, circulation_strategy, bathroom_relationships, staircase_requirements,
natural_light_requirements, outdoor_space_relationships, style_intent.
requirements must use the DREAM HOME house-requirements schema with plot, rooms, parking, floors,
features, style, style_other, budget, and additional_requirements.
Use only supported room and feature fields. Preserve explicit values and use schema defaults only
where required. Supported circulation strategies are central_corridor, side_corridor,
public_private_split, front_public_rear_private, courtyard_oriented, compact_service_core.
Describe relationships and priorities symbolically; the deterministic geometry engine owns all coordinates.'''

REVIEWER_SYSTEM_PROMPT = '''You are an architectural reviewer for DREAM HOME.
Review structured plan metadata, not images. Return exactly one JSON object with:
issues (array of objects with type, room, severity, message) and revision_actions (array of
short symbolic actions). Do not invent coordinates or geometry. Focus on proportions, circulation,
accessibility, adjacency, bathroom relationships, zoning, privacy, floor connectivity, furniture,
doors, windows, efficiency, and architectural coherence.'''


def _setting(name: str, default: Any) -> Any:
    try:
        return getattr(settings, name, os.getenv(name, default))
    except Exception:
        return os.getenv(name, default)


def openai_configured() -> bool:
    return bool(_setting('OPENAI_API_KEY', os.getenv('OPENAI_API_KEY', '')))


class OpenAIArchitectureClient:
    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
        endpoint: str | None = None,
        timeout: float = 60,
        opener: Callable[..., Any] | None = None,
    ):
        self.api_key = api_key or _setting('OPENAI_API_KEY', '')
        self.model = model or _setting('OPENAI_ARCHITECTURE_MODEL', 'gpt-4o-mini')
        self.endpoint = endpoint or _setting('OPENAI_API_ENDPOINT', 'https://api.openai.com/v1/chat/completions')
        self.timeout = timeout
        self.opener = opener or urlopen
        if not self.api_key:
            raise OpenAIArchitectureError('OpenAI architecture service is not configured.')

    def _json_call(self, system_prompt: str, user_payload: Any) -> dict[str, Any]:
        payload = json.dumps({
            'model': self.model,
            'temperature': 0,
            'response_format': {'type': 'json_object'},
            'messages': [
                {'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': json.dumps(user_payload)},
            ],
        }).encode('utf-8')
        request = Request(self.endpoint, data=payload, headers={
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
        }, method='POST')
        try:
            with self.opener(request, timeout=self.timeout) as response:
                body = json.loads(response.read().decode('utf-8'))
        except HTTPError as error:
            raise OpenAIArchitectureError(f'OpenAI architecture service returned HTTP {error.code}.') from error
        except (OSError, URLError, TimeoutError) as error:
            raise OpenAIArchitectureError('OpenAI architecture service is unavailable.') from error
        except (JSONDecodeError, UnicodeDecodeError) as error:
            raise OpenAIArchitectureError('OpenAI architecture service returned invalid JSON.') from error
        try:
            content = body['choices'][0]['message']['content']
            result = json.loads(content)
        except (KeyError, IndexError, TypeError, JSONDecodeError) as error:
            raise OpenAIArchitectureError('OpenAI architecture service returned an invalid structured response.') from error
        if not isinstance(result, dict):
            raise OpenAIArchitectureError('OpenAI architecture response must be an object.')
        return result

    def plan(self, requirements_text: str) -> ArchitecturalIntent:
        if not isinstance(requirements_text, str) or not requirements_text.strip():
            raise OpenAIArchitectureError('House requirements text is required.')
        try:
            return normalize_intent(self._json_call(PLANNER_SYSTEM_PROMPT, {'requirements_text': requirements_text.strip()}))
        except IntentError as error:
            raise OpenAIArchitectureError(str(error)) from error

    def review(self, intent: ArchitecturalIntent, layout: dict[str, Any]) -> dict[str, Any]:
        result = self._json_call(REVIEWER_SYSTEM_PROMPT, {
            'architectural_intent': intent,
            'layout_metadata': {
                'plot': layout.get('plot'),
                'rooms': layout.get('rooms'),
                'circulation': layout.get('circulation'),
                'doors': layout.get('doors'),
                'windows': layout.get('windows'),
                'furniture': layout.get('furniture'),
                'stairs': layout.get('stairs'),
                'validation': layout.get('validation'),
                'score': layout.get('score'),
            },
        })
        if not isinstance(result.get('issues', []), list) or not isinstance(result.get('revision_actions', []), list):
            raise OpenAIArchitectureError('OpenAI reviewer returned invalid issue data.')
        return {'issues': result.get('issues', []), 'revision_actions': result.get('revision_actions', [])}
