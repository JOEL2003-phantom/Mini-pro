from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.urls import reverse
from django.test import TestCase, override_settings


User = get_user_model()


@override_settings(PASSWORD_HASHERS=['django.contrib.auth.hashers.MD5PasswordHasher'])
class AuthenticationFlowTests(TestCase):
	def setUp(self):
		self.password = 'StrongPassword!123'
		self.user = User.objects.create_user(
			username='planner',
			email='planner@example.com',
			password=self.password,
		)

	def test_registration_page_loads(self):
		response = self.client.get(reverse('accounts:register'))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Create your DREAM HOME account.')

	def test_valid_registration_creates_hashed_user_and_logs_in(self):
		response = self.client.post(
			reverse('accounts:register'),
			{
				'username': 'new-planner',
				'email': 'new@example.com',
				'password1': self.password,
				'password2': self.password,
			},
		)

		new_user = User.objects.get(username='new-planner')
		self.assertRedirects(response, reverse('dashboard'))
		self.assertTrue(new_user.check_password(self.password))
		self.assertNotEqual(new_user.password, self.password)
		self.assertEqual(int(self.client.session['_auth_user_id']), new_user.pk)

	def test_duplicate_username_is_rejected(self):
		response = self.client.post(
			reverse('accounts:register'),
			{
				'username': self.user.username,
				'email': 'different@example.com',
				'password1': self.password,
				'password2': self.password,
			},
		)

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'A user with that username already exists.')
		self.assertEqual(User.objects.filter(username=self.user.username).count(), 1)

	def test_invalid_email_is_rejected(self):
		response = self.client.post(
			reverse('accounts:register'),
			{
				'username': 'invalid-email',
				'email': 'not-an-email',
				'password1': self.password,
				'password2': self.password,
			},
		)

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Enter a valid email address.')

	def test_mismatched_passwords_are_rejected(self):
		response = self.client.post(
			reverse('accounts:register'),
			{
				'username': 'mismatch',
				'email': 'mismatch@example.com',
				'password1': self.password,
				'password2': 'DifferentPassword!123',
			},
		)

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, "The two password fields didn’t match.")

	def test_login_page_loads(self):
		response = self.client.get(reverse('accounts:login'))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Continue your home planning journey.')

	def test_valid_login_creates_session_and_redirects(self):
		response = self.client.post(
			reverse('accounts:login'),
			{'username': self.user.username, 'password': self.password},
		)

		self.assertRedirects(response, reverse('dashboard'))
		self.assertTrue(response.wsgi_request.user.is_authenticated)

	def test_invalid_login_is_rejected_without_user_detail(self):
		response = self.client.post(
			reverse('accounts:login'),
			{'username': self.user.username, 'password': 'wrong-password'},
		)

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Please enter a correct username and password.')
		self.assertNotContains(response, self.user.email)

	def test_logout_requires_post_and_invalidates_session(self):
		self.client.login(username=self.user.username, password=self.password)

		get_response = self.client.get(reverse('accounts:logout'))
		self.assertRedirects(get_response, reverse('dashboard'))
		self.assertTrue(self.client.session.get('_auth_user_id'))

		post_response = self.client.post(reverse('accounts:logout'))
		self.assertRedirects(post_response, reverse('home'))
		self.assertNotIn('_auth_user_id', self.client.session)

	def test_dashboard_redirects_anonymous_users_to_login(self):
		response = self.client.get(reverse('dashboard'))

		self.assertRedirects(
			response,
			f'{reverse("accounts:login")}?next={reverse("dashboard")}',
		)

	@patch('designs.persistence.DesignPersistenceService')
	def test_authenticated_user_can_access_dashboard(self, service_class):
		service_class.return_value.list_designs.return_value = []
		self.client.force_login(self.user)

		response = self.client.get(reverse('dashboard'))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Open design library')
		self.assertNotContains(response, 'premium-design-card')
		self.assertContains(response, self.user.username)

	def test_root_is_public_home_for_authenticated_users(self):
		self.client.force_login(self.user)

		response = self.client.get(reverse('home'))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Structured Home Planning')

	def test_root_is_public_home_for_anonymous_users(self):
		response = self.client.get(reverse('home'))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, 'Structured Home Planning')

	def test_profile_redirects_anonymous_users_to_login(self):
		response = self.client.get(reverse('accounts:profile'))

		self.assertRedirects(
			response,
			f'{reverse("accounts:login")}?next={reverse("accounts:profile")}',
		)

	def test_authenticated_user_can_access_profile(self):
		self.client.force_login(self.user)

		response = self.client.get(reverse('accounts:profile'))

		self.assertEqual(response.status_code, 200)
		self.assertContains(response, self.user.email)
		self.assertContains(response, self.user.date_joined.strftime('%B'))

	def test_authenticated_identity_is_ready_for_design_ownership(self):
		self.client.force_login(self.user)

		self.assertEqual(str(self.client.session['_auth_user_id']), str(self.user.pk))
