from django.apps import AppConfig


class DesignEngineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'design_engine'
