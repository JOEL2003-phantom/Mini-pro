from django import forms


def preferences_to_initial(preferences, design_name=''):
    rooms = preferences.get('rooms', {})
    features = preferences.get('features', {})
    plot = preferences.get('plot', {})
    return {
        'design_name': design_name,
        'plot_width': plot.get('width'),
        'plot_length': plot.get('length'),
        'unit': plot.get('unit', 'ft'),
        **{field: rooms.get(field, 0) for field in ('bedrooms', 'bathrooms', 'kitchen', 'living_room', 'dining_room')},
        'parking': preferences.get('parking', 0),
        'floors': preferences.get('floors', 1),
        **{field: features.get(field, False) for field in (
            'balcony', 'utility_room', 'work_study_room', 'prayer_room', 'storage_room', 'garden_open_space'
        )},
        'style': preferences.get('style', 'modern'),
        'style_other': preferences.get('style_other', ''),
        'budget': preferences.get('budget'),
        'additional_requirements': preferences.get('additional_requirements', ''),
    }


class HouseRequirementsForm(forms.Form):
    design_name = forms.CharField(
        required=False,
        max_length=120,
        label='Design name',
        widget=forms.TextInput(attrs={'placeholder': 'My 3 Bedroom Dream Home'}),
    )
    plot_width = forms.DecimalField(
        min_value=0.01,
        max_value=100000,
        label='Plot width',
        widget=forms.NumberInput(attrs={'min': '0.01', 'step': '0.01'}),
    )
    plot_length = forms.DecimalField(
        min_value=0.01,
        max_value=100000,
        label='Plot length',
        widget=forms.NumberInput(attrs={'min': '0.01', 'step': '0.01'}),
    )
    unit = forms.ChoiceField(
        choices=(('ft', 'Feet (ft)'),),
        initial='ft',
        label='Unit',
    )
    bedrooms = forms.IntegerField(min_value=0, max_value=100, initial=3)
    bathrooms = forms.IntegerField(min_value=0, max_value=100, initial=2)
    kitchen = forms.IntegerField(min_value=0, max_value=10, initial=1)
    living_room = forms.IntegerField(min_value=0, max_value=10, initial=1, label='Living rooms')
    dining_room = forms.IntegerField(min_value=0, max_value=10, initial=1, label='Dining rooms')
    parking = forms.IntegerField(min_value=0, max_value=100, initial=1)
    floors = forms.IntegerField(min_value=1, max_value=50, initial=1)
    balcony = forms.BooleanField(required=False)
    utility_room = forms.BooleanField(required=False)
    work_study_room = forms.BooleanField(required=False, label='Work/study room')
    prayer_room = forms.BooleanField(required=False)
    storage_room = forms.BooleanField(required=False)
    garden_open_space = forms.BooleanField(required=False, label='Garden/open space')
    style = forms.ChoiceField(
        choices=(
            ('modern', 'Modern'),
            ('traditional', 'Traditional'),
            ('minimalist', 'Minimalist'),
            ('contemporary', 'Contemporary'),
            ('other', 'Other'),
        ),
        widget=forms.RadioSelect,
        initial='modern',
    )
    style_other = forms.CharField(required=False, max_length=80, label='Your preferred style')
    budget = forms.DecimalField(
        required=False,
        min_value=0,
        max_value=100000000000,
        label='Approximate budget',
        widget=forms.NumberInput(attrs={'min': '0', 'step': '1', 'placeholder': '3000000'}),
    )
    additional_requirements = forms.CharField(
        required=False,
        max_length=2000,
        label='Additional requirements',
        widget=forms.Textarea(attrs={'rows': 5, 'placeholder': 'More natural light, open kitchen...'}),
    )

    def clean(self):
        cleaned_data = super().clean()
        if cleaned_data.get('style') == 'other' and not cleaned_data.get('style_other', '').strip():
            self.add_error('style_other', 'Please describe your preferred style.')
        if cleaned_data.get('style') != 'other':
            cleaned_data['style_other'] = ''
        return cleaned_data

    def to_preferences(self):
        data = self.cleaned_data
        return {
            'plot': {
                'width': float(data['plot_width']),
                'length': float(data['plot_length']),
                'unit': data['unit'],
            },
            'rooms': {
                'bedrooms': data['bedrooms'],
                'bathrooms': data['bathrooms'],
                'kitchen': data['kitchen'],
                'living_room': data['living_room'],
                'dining_room': data['dining_room'],
            },
            'parking': data['parking'],
            'floors': data['floors'],
            'features': {
                'balcony': data['balcony'],
                'utility_room': data['utility_room'],
                'work_study_room': data['work_study_room'],
                'prayer_room': data['prayer_room'],
                'storage_room': data['storage_room'],
                'garden_open_space': data['garden_open_space'],
            },
            'style': data['style'],
            'style_other': data['style_other'],
            'budget': float(data['budget']) if data.get('budget') is not None else None,
            'additional_requirements': data['additional_requirements'].strip(),
        }


class PlotDimensionsForm(forms.Form):
    plot_width = forms.DecimalField(
        min_value=0.01,
        max_value=100000,
        label='Plot width',
        widget=forms.NumberInput(attrs={'min': '0.01', 'step': '0.01'}),
    )
    plot_length = forms.DecimalField(
        min_value=0.01,
        max_value=100000,
        label='Plot length',
        widget=forms.NumberInput(attrs={'min': '0.01', 'step': '0.01'}),
    )

    def to_plot(self, current_preferences):
        return {
            **current_preferences,
            'plot': {
                **current_preferences.get('plot', {}),
                'width': float(self.cleaned_data['plot_width']),
                'length': float(self.cleaned_data['plot_length']),
            },
        }
