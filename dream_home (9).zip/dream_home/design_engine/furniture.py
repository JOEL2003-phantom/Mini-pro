"""Room-type-aware conceptual furniture placement."""

from typing import Any


def _inside(room: dict[str, Any], x: float, y: float, width: float, height: float, inset: float = 0.25) -> bool:
    return (
        x >= room['x'] + inset and y >= room['y'] + inset
        and x + width <= room['x'] + room['width'] - inset
        and y + height <= room['y'] + room['height'] - inset
    )


def _item(room: dict[str, Any], kind: str, x: float, y: float, width: float, height: float, **extra: Any) -> dict[str, Any] | None:
    if not _inside(room, x, y, width, height):
        return None
    return {
        'id': f"{room['id']}_{kind}", 'type': kind, 'room_id': room['id'],
        'floor': room.get('floor', 1), 'x': round(x, 2), 'y': round(y, 2),
        'width': round(width, 2), 'height': round(height, 2), **extra,
    }


def _overlaps_clearance(item: dict[str, Any], door: dict[str, Any]) -> bool:
    depth = door.get('clearance', {}).get('depth', door.get('width', 0))
    if door.get('orientation') == 'vertical':
        clearance = {'x': door['x'], 'y': door['y'], 'width': depth, 'height': door['width']}
    else:
        clearance = {'x': door['x'], 'y': door['y'], 'width': door['width'], 'height': depth}
    return (
        item['x'] < clearance['x'] + clearance['width']
        and item['x'] + item['width'] > clearance['x']
        and item['y'] < clearance['y'] + clearance['height']
        and item['y'] + item['height'] > clearance['y']
    )


def generate_furniture(rooms: list[dict[str, Any]], doors: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    furniture = []
    doors = doors or []
    for room in rooms:
        room['furniture'] = []
        x, y = room['x'] + 0.7, room['y'] + 0.7
        width, height = room['width'] - 1.4, room['height'] - 1.4
        candidates: list[tuple[str, float, float, float, float, dict[str, Any]]] = []
        if room['type'] == 'bedroom':
            candidates = [('bed', x, y, min(6.0, width * .58), min(6.5, height * .58), {}), ('wardrobe', room['x'] + room['width'] - 1.6, y, 1.0, min(4.0, height), {})]
        elif room['type'] == 'living':
            candidates = [('sofa', x, y, min(6.5, width * .58), 1.6, {}), ('coffee_table', x + .6, y + 2.5, min(3.0, width * .3), 1.4, {})]
        elif room['type'] == 'dining':
            candidates = [('dining_table', room['x'] + room['width'] / 2 - min(4.5, width) / 2, room['y'] + room['height'] / 2 - min(3.0, height) / 2, min(4.5, width), min(3.0, height), {'seats': 6})]
        elif room['type'] == 'kitchen':
            candidates = [('counter', x, y, width, min(2.0, height), {}), ('sink', x + min(3.0, max(width - 1.4, 0)), y + .35, 1.4, 1.3, {}), ('cooktop', x + max(0.5, width - 3.0), y + .45, 1.5, 1.0, {})]
        elif room['type'] == 'bathroom':
            candidates = [('toilet', x, y, 1.4, 1.9, {}), ('basin', room['x'] + room['width'] - 2.1, y, 1.6, .9, {}), ('shower', x, room['y'] + room['height'] - 2.0, min(2.0, width), 1.4, {})]
        elif room['type'] == 'balcony':
            candidates = [('balcony_seat', x, y, min(3.0, width), min(1.5, height), {})]
        room_doors = [door for door in doors if door.get('connects_to') == room['id'] and door.get('clearance')]
        for kind, item_x, item_y, item_width, item_height, extra in candidates:
            item = None
            for offset_x, offset_y in ((0, 0), (0, 2), (2, 0), (-2, 0), (0, -2)):
                candidate = _item(room, kind, item_x + offset_x, item_y + offset_y, item_width, item_height, **extra)
                if candidate and not any(_overlaps_clearance(candidate, door) for door in room_doors):
                    item = candidate
                    break
            if item:
                room['furniture'].append(item)
                furniture.append(item)
    return furniture
