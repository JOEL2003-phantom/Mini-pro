"""Boundary-safe conceptual door planning."""

from typing import Any


def _touching(first: dict[str, Any], second: dict[str, Any]) -> tuple[str, float, float] | None:
    first_right = first['x'] + first['width']
    second_right = second['x'] + second['width']
    first_bottom = first['y'] + first['height']
    second_bottom = second['y'] + second['height']
    vertical = max(first['y'], second['y']) < min(first_bottom, second_bottom)
    horizontal = max(first['x'], second['x']) < min(first_right, second_right)
    if abs(first_right - second['x']) < 0.01 and vertical:
        return 'vertical', (max(first['y'], second['y']) + min(first_bottom, second_bottom)) / 2, min(first_bottom, second_bottom) - max(first['y'], second['y'])
    if abs(first_bottom - second['y']) < 0.01 and horizontal:
        return 'horizontal', (max(first['x'], second['x']) + min(first_right, second_right)) / 2, min(first_right, second_right) - max(first['x'], second['x'])
    if abs(second_right - first['x']) < 0.01 and vertical:
        return 'vertical', (max(first['y'], second['y']) + min(first_bottom, second_bottom)) / 2, min(first_bottom, second_bottom) - max(first['y'], second['y'])
    if abs(second_bottom - first['y']) < 0.01 and horizontal:
        return 'horizontal', (max(first['x'], second['x']) + min(first_right, second_right)) / 2, min(first_right, second_right) - max(first['x'], second['x'])
    return None


def _door(room: dict[str, Any], x: float, y: float, width: float, orientation: str, connects_from: str, kind: str, index: int) -> dict[str, Any]:
    return {
        'id': f"door_{room['id']}_{index}", 'type': kind, 'room_id': room['id'],
        'floor': room.get('floor', 1), 'x': round(x, 2), 'y': round(y, 2),
        'width': round(width, 2), 'orientation': orientation, 'swing': 'right',
        'swing_direction': 'inward', 'opening': {'width': round(width, 2)},
        'leaf': {'hinge': 'right', 'width': round(width, 2)},
        'swing_arc': {'radius': round(width, 2), 'degrees': 90},
        'clearance': {'width': round(width, 2), 'depth': round(width, 2)},
        'connects_from': connects_from, 'connects_to': room['id'],
        'exterior': connects_from == 'exterior',
    }


def plan_doors(rooms: list[dict[str, Any]], circulation: dict[str, Any], parking: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    by_id = {room['id']: room for room in rooms}
    entry_id = circulation.get('entry_room')
    entry = by_id.get(entry_id) or (rooms[0] if rooms else None)
    doors: list[dict[str, Any]] = []
    entrances: list[dict[str, Any]] = []
    if entry:
        width = min(3.0, entry['width'] * .3)
        entrance = _door(entry, entry['x'] + (entry['width'] - width) / 2, entry['y'], width, 'horizontal', 'exterior', 'main', 0)
        entrance['id'] = 'door_main_entrance'
        entrance['connects_from'] = parking[0]['id'] if parking else 'exterior'
        entrance['exterior'] = True
        doors.append(entrance)
        entrances.append({**entrance, 'id': 'main_entrance'})

    index = 1
    for room in rooms:
        if entry and room['id'] == entry['id']:
            continue
        source = 'circulation_floor_' + str(room.get('floor', 1))
        touching = None
        for other in rooms:
            if other['id'] == room['id'] or other.get('floor', 1) != room.get('floor', 1):
                continue
            if room.get('bathroom_kind') == 'attached' and other['id'] == room.get('attached_to'):
                touching = (other, _touching(room, other))
                break
        if touching is None:
            candidates = [other for other in rooms if other['id'] != room['id'] and other.get('floor', 1) == room.get('floor', 1)]
            touching = next(((other, _touching(room, other)) for other in candidates if _touching(room, other)), (None, None))
        other, boundary = touching
        if boundary and boundary[2] >= 2.0:
            orientation, coordinate, overlap = boundary
            width = min(2.8, overlap)
            if orientation == 'vertical':
                x = min(room['x'] + room['width'], other['x'] + other['width'])
                y = coordinate - width / 2
            else:
                x = coordinate - width / 2
                y = min(room['y'] + room['height'], other['y'] + other['height'])
            door = _door(room, x, y, width, orientation, other['id'], 'interior', index)
        else:
            width = min(2.6, room['width'] * .25)
            door = _door(room, room['x'] + (room['width'] - width) / 2, room['y'], width, 'horizontal', source, 'interior', index)
            door['circulation'] = True
        doors.append(door)
        index += 1
    return doors, entrances
