"""MongoDB persistence for structured DREAM HOME design documents."""

from copy import deepcopy
from datetime import datetime, timezone
from typing import Any

from django.conf import settings
from pymongo import MongoClient
from pymongo.collection import Collection


class DesignValidationError(ValueError):
    """Raised when a design document does not meet the storage contract."""


_mongo_client = None


def get_mongodb_client() -> MongoClient:
    """Return the lazily-created application MongoDB client."""
    global _mongo_client
    if _mongo_client is None:
        _mongo_client = MongoClient(
            settings.MONGODB_URI,
            serverSelectionTimeoutMS=settings.MONGODB_SERVER_SELECTION_TIMEOUT_MS,
        )
    return _mongo_client


def get_design_collection() -> Collection:
    """Return the MongoDB collection used for design documents."""
    database = get_mongodb_client()[settings.MONGODB_DB_NAME]
    return database[settings.MONGODB_DESIGNS_COLLECTION]


def verify_mongodb_connection() -> bool:
    """Ping MongoDB and return whether the configured server is reachable."""
    get_mongodb_client().admin.command('ping')
    return True


def _require_text(data: dict[str, Any], field: str) -> None:
    if not isinstance(data.get(field), str) or not data[field].strip():
        raise DesignValidationError(f'{field} is required')


def _validate_non_negative_number(value: Any, field: str) -> None:
    if not isinstance(value, (int, float)) or isinstance(value, bool) or value < 0:
        raise DesignValidationError(f'{field} must be a non-negative number')


def _validate_plot(plot: Any) -> None:
    if not isinstance(plot, dict):
        raise DesignValidationError('plot is required')
    for field in ('width', 'length'):
        if field not in plot:
            raise DesignValidationError(f'plot.{field} is required')
        _validate_non_negative_number(plot[field], f'plot.{field}')
    if not isinstance(plot.get('unit'), str) or not plot['unit'].strip():
        raise DesignValidationError('plot.unit is required')


def _validate_rooms(layout: Any) -> None:
    if layout is None:
        return
    if not isinstance(layout, dict):
        raise DesignValidationError('layout must be an object')
    rooms = layout.get('rooms', [])
    if not isinstance(rooms, list):
        raise DesignValidationError('layout.rooms must be a list')
    for room in rooms:
        if not isinstance(room, dict):
            raise DesignValidationError('each room must be an object')
        _require_text(room, 'id')
        _require_text(room, 'name')
        for field in ('x', 'y', 'width', 'height'):
            if field not in room:
                raise DesignValidationError(f'room.{field} is required')
            _validate_non_negative_number(room[field], f'room.{field}')
        if room['width'] == 0 or room['height'] == 0:
            raise DesignValidationError('room.width and room.height must be greater than zero')


def validate_design_document(document: dict[str, Any]) -> None:
    """Validate storage-level identifiers and basic structured geometry."""
    if not isinstance(document, dict):
        raise DesignValidationError('design must be an object')
    for field in ('user_id', 'design_id', 'design_name'):
        _require_text(document, field)
    _validate_plot(document.get('plot'))
    if 'preferences' in document and not isinstance(document['preferences'], dict):
        raise DesignValidationError('preferences must be an object')
    _validate_rooms(document.get('layout'))


class DesignPersistenceService:
    """CRUD boundary between application code and the MongoDB collection."""

    def __init__(self, collection: Collection | None = None):
        self.collection = collection or get_design_collection()

    def create_design(self, design: dict[str, Any]) -> dict[str, Any]:
        validate_design_document(design)
        now = datetime.now(timezone.utc)
        document = deepcopy(design)
        document['created_at'] = now
        document['updated_at'] = now
        self.collection.insert_one(document)
        return document

    def get_design(self, user_id: str, design_id: str) -> dict[str, Any] | None:
        return self.collection.find_one(
            {'user_id': user_id, 'design_id': design_id},
            {'_id': 0},
        )

    def update_design(
        self,
        user_id: str,
        design_id: str,
        updates: dict[str, Any],
    ) -> dict[str, Any] | None:
        current = self.get_design(user_id, design_id)
        if current is None:
            return None
        candidate = {**current, **deepcopy(updates)}
        candidate.pop('_id', None)
        candidate['user_id'] = user_id
        candidate['design_id'] = design_id
        validate_design_document(candidate)
        candidate['updated_at'] = datetime.now(timezone.utc)
        self.collection.replace_one(
            {'user_id': user_id, 'design_id': design_id},
            candidate,
        )
        return candidate

    def delete_design(self, user_id: str, design_id: str) -> bool:
        result = self.collection.delete_one({'user_id': user_id, 'design_id': design_id})
        return result.deleted_count == 1

    def list_designs(self, user_id: str) -> list[dict[str, Any]]:
        return list(
            self.collection.find(
                {'user_id': user_id},
                {'_id': 0},
            ).sort('updated_at', -1)
        )